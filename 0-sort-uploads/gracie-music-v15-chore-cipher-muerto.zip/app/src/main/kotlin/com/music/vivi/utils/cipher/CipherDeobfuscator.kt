/**
 * vivimusic Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.music.vivi.utils.cipher

import android.content.Context
import timber.log.Timber

/**
 * Holds the app context for the cipher package and loads the player configs at startup.
 */
object CipherDeobfuscator {
    private const val TAG = "vivimusic_CipherDeobfusc"

    lateinit var appContext: Context
        private set

    fun initialize(context: Context) {
        Timber.tag(TAG).d("CipherDeobfuscator initializing...")
        appContext = context.applicationContext
        
        // Initialize player configs (bundled fallback + cached remote configs)
        PlayerConfigStore.initialize(appContext)
        Timber.tag(TAG).d("CipherDeobfuscator initialized")
    }
}

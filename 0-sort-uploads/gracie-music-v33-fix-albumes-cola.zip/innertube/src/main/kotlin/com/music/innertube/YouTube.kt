/**
 * vivimusic Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */
package com.music.innertube

import com.music.innertube.models.AccountInfo
import com.music.innertube.models.ElementRenderer
import com.music.innertube.models.YTItem
import com.music.innertube.models.AlbumItem
import com.music.innertube.models.Artist
import com.music.innertube.models.ArtistItem
import com.music.innertube.pages.RadioChip
import com.music.innertube.models.BrowseEndpoint
import com.music.innertube.models.GridRenderer
import com.music.innertube.models.MediaInfo
import com.music.innertube.models.MusicResponsiveListItemRenderer
import com.music.innertube.models.MusicTwoRowItemRenderer
import com.music.innertube.models.MusicCarouselShelfRenderer
import com.music.innertube.models.MusicShelfRenderer
import com.music.innertube.models.SectionListRenderer
import com.music.innertube.models.PlaylistItem
import com.music.innertube.models.SearchSuggestions
import com.music.innertube.models.Run
import com.music.innertube.models.SongItem
import com.music.innertube.models.WatchEndpoint
import com.music.innertube.models.WatchEndpoint.WatchEndpointMusicSupportedConfigs.WatchEndpointMusicConfig.Companion.MUSIC_VIDEO_TYPE_ATV
import com.music.innertube.models.YouTubeClient
import com.music.innertube.models.YouTubeClient.Companion.WEB
import com.music.innertube.models.YouTubeClient.Companion.WEB_REMIX
import com.music.innertube.models.YouTubeLocale
import com.music.innertube.models.getContinuation
import com.music.innertube.models.getItems
import com.music.innertube.models.oddElements
import com.music.innertube.models.splitBySeparator
import com.music.innertube.models.response.AccountMenuResponse
import com.music.innertube.models.response.BrowseResponse
import com.music.innertube.models.response.CreatePlaylistResponse
import com.music.innertube.models.response.EditPlaylistResponse
import com.music.innertube.models.response.FeedbackResponse
import com.music.innertube.models.response.GetQueueResponse
import com.music.innertube.models.response.GetSearchSuggestionsResponse
import com.music.innertube.models.response.GetTranscriptResponse
import com.music.innertube.models.response.ImageUploadResponse
import com.music.innertube.models.response.NextResponse
import com.music.innertube.models.response.PlayerResponse
import com.music.innertube.models.response.SearchResponse
import com.music.innertube.models.comment.CommentThreadRenderer
import com.music.innertube.models.comment.CommentResponse
import com.music.innertube.pages.AlbumPage
import com.music.innertube.pages.ArtistItemsContinuationPage
import com.music.innertube.pages.ArtistItemsPage
import com.music.innertube.pages.ArtistPage
import com.music.innertube.pages.ChartsPage
import com.music.innertube.pages.BrowseResult
import com.music.innertube.pages.ExplorePage
import com.music.innertube.pages.HistoryPage
import com.music.innertube.pages.HomePage
import com.music.innertube.pages.LibraryContinuationPage
import com.music.innertube.pages.LibraryPage
import com.music.innertube.pages.MoodAndGenres
import com.music.innertube.pages.NewReleaseAlbumPage
import com.music.innertube.pages.NextPage
import com.music.innertube.pages.NextResult
import com.music.innertube.pages.PlaylistContinuationPage
import com.music.innertube.pages.PlaylistPage
import com.music.innertube.pages.RelatedPage
import com.music.innertube.pages.SearchPage
import com.music.innertube.pages.SearchResult
import com.music.innertube.pages.SearchSuggestionPage
import com.music.innertube.pages.SearchSummary
import com.music.innertube.pages.SearchSummaryPage
import io.ktor.client.call.body
import io.ktor.client.statement.bodyAsText
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonPrimitive
import java.net.Proxy
import kotlin.random.Random

/**
 * Parse useful data with [InnerTube] sending requests.
 * Modified from [ViMusic](https://github.com/vfsfitvnm/ViMusic)
 */
object YouTube {
    private val innerTube = InnerTube()

    var locale: YouTubeLocale
        get() = innerTube.locale
        set(value) {
            innerTube.locale = value
        }
    var visitorData: String?
        get() = innerTube.visitorData
        set(value) {
            innerTube.visitorData = value
        }
    var dataSyncId: String?
        get() = innerTube.dataSyncId
        set(value) {
            innerTube.dataSyncId = value
        }
    var cookie: String?
        get() = innerTube.cookie
        set(value) {
            innerTube.cookie = value
        }
    var visitorCookie: String?
        get() = innerTube.visitorCookie
        set(value) {
            innerTube.visitorCookie = value
        }
    var onCookieChanged: ((String) -> Unit)?
        get() = innerTube.onCookieChanged
        set(value) {
            innerTube.onCookieChanged = value
        }
    var onVisitorCookieChanged: ((String) -> Unit)?
        get() = innerTube.onVisitorCookieChanged
        set(value) {
            innerTube.onVisitorCookieChanged = value
        }
    var proxy: Proxy?
        get() = innerTube.proxy
        set(value) {
            innerTube.proxy = value
        }

    var proxyAuth: String?
        get() = innerTube.proxyAuth
        set(value) {
            innerTube.proxyAuth = value
        }
    var useLoginForBrowse: Boolean
        get() = innerTube.useLoginForBrowse
        set(value) {
            innerTube.useLoginForBrowse = value
        }

    var ipVersion: com.music.innertube.models.IpVersion
        get() = innerTube.ipVersion
        set(value) {
            innerTube.ipVersion = value
        }

    suspend fun refreshVisitorData(): Result<String> = visitorData().onSuccess {
        visitorData = it
    }

    fun clearGuestSession() {
        visitorData = null
        dataSyncId = null
        visitorCookie = null
    }

    suspend fun searchSuggestions(query: String): Result<SearchSuggestions> = runCatching {
        val response = innerTube.getSearchSuggestions(WEB_REMIX, query).body<GetSearchSuggestionsResponse>()
        SearchSuggestions(
            queries = response.contents?.getOrNull(0)?.searchSuggestionsSectionRenderer?.contents?.mapNotNull { content ->
                content.searchSuggestionRenderer?.suggestion?.runs?.joinToString(separator = "") { it.text }
            }.orEmpty(),
            recommendedItems = response.contents?.getOrNull(1)?.searchSuggestionsSectionRenderer?.contents?.mapNotNull {
                it.musicResponsiveListItemRenderer?.let { renderer ->
                    SearchSuggestionPage.fromMusicResponsiveListItemRenderer(renderer)
                }
            }.orEmpty()
        )
    }

    suspend fun searchSummary(query: String): Result<SearchSummaryPage> = runCatching {
        val response = innerTube.search(WEB_REMIX, query).body<SearchResponse>()
        val sectionListRenderer = response.contents?.tabbedSearchResultsRenderer?.tabs?.firstOrNull()
            ?.tabRenderer?.content?.sectionListRenderer
            ?: response.contents?.twoColumnSearchResultsRenderer?.primaryContents?.sectionListRenderer
            ?: response.contents?.sectionListRenderer
            
        val contents = sectionListRenderer?.contents.orEmpty()

        val shelfSummaries = contents.mapNotNull { it ->
            if (it.musicCardShelfRenderer != null) {
                val isArtistCard = it.musicCardShelfRenderer.onTap.browseEndpoint?.isArtistEndpoint == true
                val implicitArtist = if (isArtistCard) {
                    Artist(
                        name = it.musicCardShelfRenderer.title.runs?.firstOrNull()?.text ?: "",
                        id = it.musicCardShelfRenderer.onTap.browseEndpoint?.browseId
                    )
                } else null

                SearchSummary(
                    title = it.musicCardShelfRenderer.header?.musicCardShelfHeaderBasicRenderer?.title?.runs?.firstOrNull()?.text ?: YouTubeConstants.DEFAULT_TOP_RESULT,
                    items = listOfNotNull(SearchSummaryPage.fromMusicCardShelfRenderer(it.musicCardShelfRenderer))
                        .plus(
                            it.musicCardShelfRenderer.contents
                                ?.mapNotNull { content -> content.musicResponsiveListItemRenderer }
                                ?.mapNotNull { renderer -> SearchSummaryPage.fromMusicResponsiveListItemRenderer(renderer, implicitArtist) }
                                .orEmpty()
                        )
                        .distinctBy { it.id }
                        .ifEmpty { null } ?: return@mapNotNull null
                )
            } else if (it.musicShelfRenderer != null) {
                SearchSummary(
                    title = it.musicShelfRenderer.title?.runs?.firstOrNull()?.text ?: YouTubeConstants.DEFAULT_OTHER_RESULTS,
                    items = it.musicShelfRenderer.contents?.getItems()
                        ?.mapNotNull {
                            SearchSummaryPage.fromMusicResponsiveListItemRenderer(it)
                        }
                        ?.distinctBy { it.id }
                        ?.ifEmpty { null } ?: return@mapNotNull null
                )
            } else {
                null
            }
        }

        val flatItems = contents
            .mapNotNull { it.itemSectionRenderer }
            .flatMap { it.contents.orEmpty() }
            .mapNotNull { it.musicResponsiveListItemRenderer }
            .mapNotNull { SearchSummaryPage.fromMusicResponsiveListItemRenderer(it) }

        val songsSummary = flatItems.filterIsInstance<SongItem>().filter { !it.isVideoSong }
            .takeIf { it.isNotEmpty() }?.let { SearchSummary(title = "Songs", items = it) }
        val albumsSummary = flatItems.filterIsInstance<AlbumItem>()
            .takeIf { it.isNotEmpty() }?.let { SearchSummary(title = "Albums", items = it) }
        val artistsSummary = flatItems.filterIsInstance<ArtistItem>()
            .takeIf { it.isNotEmpty() }?.let { SearchSummary(title = "Artists", items = it) }
        val playlistsSummary = flatItems.filterIsInstance<PlaylistItem>()
            .takeIf { it.isNotEmpty() }?.let { SearchSummary(title = "Playlists", items = it) }
        val videosSummary = flatItems.filterIsInstance<SongItem>().filter { it.isVideoSong }
            .takeIf { it.isNotEmpty() }?.let { SearchSummary(title = "Videos", items = it) }

        // Respeta el orden de YouTube: la categoría del primer resultado va primero y los videos al final
        val groupedSummaries = when (flatItems.firstOrNull()) {
            is ArtistItem -> listOfNotNull(artistsSummary, songsSummary, albumsSummary, playlistsSummary, videosSummary)
            is AlbumItem -> listOfNotNull(albumsSummary, songsSummary, artistsSummary, playlistsSummary, videosSummary)
            is PlaylistItem -> listOfNotNull(playlistsSummary, songsSummary, albumsSummary, artistsSummary, videosSummary)
            else -> listOfNotNull(songsSummary, albumsSummary, artistsSummary, playlistsSummary, videosSummary)
        }

        SearchSummaryPage(
            summaries = shelfSummaries + groupedSummaries
        )
    }

    suspend fun search(query: String, filter: SearchFilter): Result<SearchResult> = runCatching {
        val response = innerTube.search(WEB_REMIX, query, filter.value).body<SearchResponse>()
        val sectionListRenderer = response.contents?.tabbedSearchResultsRenderer?.tabs?.firstOrNull()
            ?.tabRenderer?.content?.sectionListRenderer
            ?: response.contents?.twoColumnSearchResultsRenderer?.primaryContents?.sectionListRenderer
            ?: response.contents?.sectionListRenderer

        val sectionListContents = sectionListRenderer?.contents.orEmpty()

        val musicShelfRenderer = sectionListContents
            .mapNotNull { it.musicShelfRenderer }
            .firstOrNull()

        val items = if (musicShelfRenderer != null) {
            musicShelfRenderer.contents?.getItems()?.mapNotNull {
                SearchPage.toYTItem(it)
            }
        } else {
            sectionListContents
                .mapNotNull { it.itemSectionRenderer }
                .flatMap { it.contents.orEmpty() }
                .mapNotNull { it.musicResponsiveListItemRenderer }
                .mapNotNull { SearchPage.toYTItem(it) }
        }.orEmpty()
        
        val continuation = musicShelfRenderer?.continuations?.getContinuation()
            ?: sectionListRenderer?.continuations?.getContinuation()

        SearchResult(
            items = items,
            continuation = continuation
        )
    }

    suspend fun searchContinuation(continuation: String): Result<SearchResult> = runCatching {
        val response = innerTube.search(WEB_REMIX, continuation = continuation).body<SearchResponse>()
        val musicShelfContinuation = response.continuationContents?.musicShelfContinuation
        val sectionListContinuation = response.continuationContents?.sectionListContinuation
            
        val items = if (musicShelfContinuation != null) {
            musicShelfContinuation.contents.mapNotNull {
                SearchPage.toYTItem(it.musicResponsiveListItemRenderer)
            }
        } else if (sectionListContinuation != null) {
            sectionListContinuation.contents.mapNotNull { content ->
                content.itemSectionRenderer?.contents?.firstOrNull()?.musicResponsiveListItemRenderer?.let { renderer ->
                    SearchPage.toYTItem(renderer)
                }
            }
        } else emptyList()
            
        SearchResult(
            items = items,
            continuation = if (items.isEmpty()) null else {
                musicShelfContinuation?.continuations?.getContinuation() ?: sectionListContinuation?.continuations?.getContinuation()
            }
        )
    }

    suspend fun album(browseId: String, withSongs: Boolean = true): Result<AlbumPage> = runCatching {
        val response = innerTube.browse(WEB_REMIX, browseId, setLogin = true).body<BrowseResponse>()

        fun mapRuns(runs: List<Run>?): List<Run>? = runs?.map { run ->
            Run(
                text = run.text,
                navigationEndpoint = run.navigationEndpoint
            )
        }

        val descriptionRuns = sequence {
            // Check all tabs in twoColumnBrowseResultsRenderer
            response.contents?.twoColumnBrowseResultsRenderer?.tabs?.forEach { tab ->
                tab?.tabRenderer?.content?.sectionListRenderer?.contents?.forEach { content ->
                    content.musicDescriptionShelfRenderer?.description?.runs?.let { yield(it) }
                }
            }
            // Check all tabs in singleColumnBrowseResultsRenderer
            response.contents?.singleColumnBrowseResultsRenderer?.tabs?.forEach { tab ->
                tab.tabRenderer.content?.sectionListRenderer?.contents?.forEach { content ->
                    content.musicDescriptionShelfRenderer?.description?.runs?.let { yield(it) }
                }
            }
            // Check headers
            response.header?.musicDetailHeaderRenderer?.description?.runs?.let { yield(it) }
            response.header?.musicImmersiveHeaderRenderer?.description?.runs?.let { yield(it) }
            response.header?.musicEditablePlaylistDetailHeaderRenderer?.header?.musicDetailHeaderRenderer?.description?.runs?.let { yield(it) }
            response.header?.musicEditablePlaylistDetailHeaderRenderer?.header?.musicResponsiveHeaderRenderer?.description?.musicDescriptionShelfRenderer?.description?.runs?.let { yield(it) }
            
            // Check musicResponsiveHeaderRenderer in contents
            response.contents?.twoColumnBrowseResultsRenderer?.tabs?.forEach { tab ->
                tab?.tabRenderer?.content?.sectionListRenderer?.contents?.forEach { content ->
                    content.musicResponsiveHeaderRenderer?.description?.musicDescriptionShelfRenderer?.description?.runs?.let { yield(it) }
                }
            }
            response.contents?.singleColumnBrowseResultsRenderer?.tabs?.forEach { tab ->
                tab.tabRenderer.content?.sectionListRenderer?.contents?.forEach { content ->
                    content.musicResponsiveHeaderRenderer?.description?.musicDescriptionShelfRenderer?.description?.runs?.let { yield(it) }
                }
            }
        }.firstOrNull()?.let(::mapRuns)

        val description = descriptionRuns?.joinToString(separator = "") { it.text }

        if (browseId.contains("FEmusic_library_privately_owned_release_detail")) {
            val playlistId =
                response.header?.musicDetailHeaderRenderer?.menu?.menuRenderer?.topLevelButtons?.firstOrNull()?.buttonRenderer?.navigationEndpoint?.watchPlaylistEndpoint?.playlistId
                    ?: AlbumPage.getPlaylistId(response) ?: ""
            val title = response.header?.musicDetailHeaderRenderer?.title?.runs?.firstOrNull()?.text
                ?: AlbumPage.getTitle(response) ?: ""
            val artists = response.header?.musicDetailHeaderRenderer?.subtitle?.runs?.filter { it.navigationEndpoint != null }?.map {
                Artist(
                    name = it.text,
                    id = it.navigationEndpoint?.browseEndpoint?.browseId
                )
            }.orEmpty().ifEmpty { AlbumPage.getArtists(response) }
            val year = response.header?.musicDetailHeaderRenderer?.subtitle?.runs?.lastOrNull()?.text?.toIntOrNull()
                ?: AlbumPage.getYear(response)
            val thumbnail = response.header?.musicDetailHeaderRenderer?.thumbnail?.croppedSquareThumbnailRenderer?.thumbnail?.thumbnails?.lastOrNull()?.url
                ?: AlbumPage.getThumbnail(response) ?: ""
            val albumItem = AlbumItem(
                browseId = browseId,
                playlistId = playlistId,
                title = title,
                artists = artists,
                year = year,
                thumbnail = thumbnail,
                explicit = false,
                description = description
            )
            return@runCatching AlbumPage(
                album = albumItem,
                songs = response.contents?.singleColumnBrowseResultsRenderer?.tabs?.firstOrNull()?.tabRenderer?.content?.sectionListRenderer?.contents?.firstOrNull()?.musicShelfRenderer?.contents?.getItems()?.mapNotNull {
                    AlbumPage.getSong(it, albumItem)
                }?.toMutableList() ?: AlbumPage.getSongs(response, albumItem).toMutableList(),
                otherVersions = emptyList(),
                description = description,
                descriptionRuns = descriptionRuns
            )
        } else {
            val playlistId = AlbumPage.getPlaylistId(response)
                ?: browseId.removePrefix("VL")
            val title = AlbumPage.getTitle(response)
                ?: response.contents?.twoColumnBrowseResultsRenderer?.tabs?.firstOrNull()?.tabRenderer?.content?.sectionListRenderer?.contents?.firstOrNull()?.musicResponsiveHeaderRenderer?.title?.runs?.firstOrNull()?.text
                ?: ""
            val artists = AlbumPage.getArtists(response).ifEmpty {
                response.contents?.twoColumnBrowseResultsRenderer?.tabs?.firstOrNull()?.tabRenderer?.content?.sectionListRenderer?.contents?.firstOrNull()?.musicResponsiveHeaderRenderer?.straplineTextOne?.runs?.oddElements()
                    ?.map {
                        Artist(
                            name = it.text,
                            id = it.navigationEndpoint?.browseEndpoint?.browseId
                        )
                    }.orEmpty()
            }
            val year = AlbumPage.getYear(response)
                ?: response.contents?.twoColumnBrowseResultsRenderer?.tabs?.firstOrNull()?.tabRenderer?.content?.sectionListRenderer?.contents?.firstOrNull()?.musicResponsiveHeaderRenderer?.subtitle?.runs?.lastOrNull()?.text?.toIntOrNull()
            val thumbnail = AlbumPage.getThumbnail(response)
                ?: response.contents?.twoColumnBrowseResultsRenderer?.tabs?.firstOrNull()?.tabRenderer?.content?.sectionListRenderer?.contents?.firstOrNull()?.musicResponsiveHeaderRenderer?.thumbnail?.musicThumbnailRenderer?.thumbnail?.thumbnails?.lastOrNull()?.url
                ?: ""
            val albumItem = AlbumItem(
                browseId = browseId,
                playlistId = playlistId,
                title = title,
                artists = artists,
                year = year,
                thumbnail = thumbnail,
                explicit = false,
                description = description
            )

            val initialSongs = AlbumPage.getSongs(response, albumItem)
            val songs = if (withSongs) {
                if (initialSongs.isNotEmpty()) {
                    initialSongs
                } else if (playlistId.isNotEmpty()) {
                    albumSongs(playlistId, albumItem).getOrDefault(emptyList())
                } else {
                    emptyList()
                }
            } else {
                emptyList()
            }

            return@runCatching AlbumPage(
                album = albumItem,
                songs = songs,
                otherVersions = response.contents?.twoColumnBrowseResultsRenderer?.secondaryContents?.sectionListRenderer?.contents
                    ?.find { it.musicCarouselShelfRenderer?.header?.musicCarouselShelfBasicHeaderRenderer?.title?.runs?.any { it.text.contains("versions", ignoreCase = true) } == true }
                    ?.musicCarouselShelfRenderer?.contents
                    ?.mapNotNull { it.musicTwoRowItemRenderer }
                    ?.mapNotNull(NewReleaseAlbumPage::fromMusicTwoRowItemRenderer)
                    .orEmpty(),
                releasesForYou = response.contents?.twoColumnBrowseResultsRenderer?.secondaryContents?.sectionListRenderer?.contents
                    ?.find { it.musicCarouselShelfRenderer?.header?.musicCarouselShelfBasicHeaderRenderer?.title?.runs?.any { it.text.contains("releases", ignoreCase = true) || it.text.contains("more from", ignoreCase = true) } == true }
                    ?.musicCarouselShelfRenderer?.contents
                    ?.mapNotNull { it.musicTwoRowItemRenderer }
                    ?.mapNotNull(NewReleaseAlbumPage::fromMusicTwoRowItemRenderer)
                    .orEmpty(),
                description = description,
                descriptionRuns = descriptionRuns
            )
        }
    }

    suspend fun albumSongs(playlistId: String, album: AlbumItem? = null): Result<List<SongItem>> = runCatching {
        val cleanPlaylistId = if (playlistId.startsWith("VL")) playlistId else "VL$playlistId"
        var response = innerTube.browse(WEB_REMIX, cleanPlaylistId).body<BrowseResponse>()
        val songs = mutableListOf<SongItem>()

        val initialItems = response.contents?.twoColumnBrowseResultsRenderer
            ?.secondaryContents?.sectionListRenderer
            ?.contents?.firstNotNullOfOrNull {
                it.musicPlaylistShelfRenderer?.contents?.getItems()
                    ?: it.musicShelfRenderer?.contents?.getItems()
            }
            ?: response.contents?.singleColumnBrowseResultsRenderer?.tabs?.firstOrNull()?.tabRenderer?.content?.sectionListRenderer?.contents?.firstNotNullOfOrNull {
                it.musicPlaylistShelfRenderer?.contents?.getItems()
                    ?: it.musicShelfRenderer?.contents?.getItems()
            }
            ?: emptyList()

        songs.addAll(initialItems.mapNotNull { AlbumPage.getSong(it, album) })

        var continuation = response.contents?.twoColumnBrowseResultsRenderer?.secondaryContents?.sectionListRenderer
            ?.contents?.firstNotNullOfOrNull { it.musicPlaylistShelfRenderer?.contents?.getContinuation() ?: it.musicShelfRenderer?.contents?.getContinuation() }
            ?: response.contents?.singleColumnBrowseResultsRenderer?.tabs?.firstOrNull()?.tabRenderer?.content?.sectionListRenderer?.contents?.firstNotNullOfOrNull {
                it.musicPlaylistShelfRenderer?.contents?.getContinuation() ?: it.musicShelfRenderer?.contents?.getContinuation()
            }

        val seenContinuations = mutableSetOf<String>()
        var requestCount = 0
        val maxRequests = 50 // Prevent excessive API calls

        while (continuation != null && requestCount < maxRequests) {
            // Prevent infinite loops by tracking seen continuations
            if (continuation in seenContinuations) {
                break
            }
            seenContinuations.add(continuation)
            requestCount++

            response = innerTube.browse(
                client = WEB_REMIX,
                continuation = continuation,
            ).body<BrowseResponse>()
            songs += response.onResponseReceivedActions?.firstOrNull()?.appendContinuationItemsAction?.continuationItems?.getItems()?.mapNotNull {
                AlbumPage.getSong(it, album)
            }.orEmpty()
            continuation = response.continuationContents?.musicPlaylistShelfContinuation?.continuations?.getContinuation()
                ?: response.continuationContents?.musicShelfContinuation?.continuations?.getContinuation()
        }
        songs
    }

    suspend fun artist(browseId: String): Result<ArtistPage> = runCatching {
        val response = innerTube.browse(WEB_REMIX, browseId).body<BrowseResponse>()

        fun mapRuns(runs: List<Run>?): List<Run>? = runs?.map { run ->
            Run(
                text = run.text,
                navigationEndpoint = run.navigationEndpoint
            )
        }

        val descriptionRuns = response.contents?.sectionListRenderer?.contents
            ?.firstOrNull { it.musicDescriptionShelfRenderer != null }
            ?.musicDescriptionShelfRenderer?.description?.runs
            ?.let(::mapRuns)
            ?: response.header?.musicImmersiveHeaderRenderer?.description?.runs?.let(::mapRuns)

        ArtistPage(
            artist = ArtistItem(
                id = browseId,
                title = response.header?.musicImmersiveHeaderRenderer?.title?.runs?.firstOrNull()?.text
                    ?: response.header?.musicVisualHeaderRenderer?.title?.runs?.firstOrNull()?.text
                    ?: response.header?.musicHeaderRenderer?.title?.runs?.firstOrNull()?.text!!,
                thumbnail = response.header?.musicImmersiveHeaderRenderer?.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl()
                    ?: response.header?.musicVisualHeaderRenderer?.foregroundThumbnail?.musicThumbnailRenderer?.getThumbnailUrl()
                    ?: response.header?.musicDetailHeaderRenderer?.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl(),
                channelId = response.header?.musicImmersiveHeaderRenderer?.subscriptionButton?.subscribeButtonRenderer?.channelId,
                playEndpoint = response.contents?.singleColumnBrowseResultsRenderer?.tabs?.firstOrNull()
                    ?.tabRenderer?.content?.sectionListRenderer?.contents?.firstOrNull()?.musicShelfRenderer
                    ?.contents?.firstOrNull()?.musicResponsiveListItemRenderer?.overlay?.musicItemThumbnailOverlayRenderer
                    ?.content?.musicPlayButtonRenderer?.playNavigationEndpoint?.watchEndpoint,
                shuffleEndpoint = response.header?.musicImmersiveHeaderRenderer?.playButton?.buttonRenderer?.navigationEndpoint?.watchEndpoint
                    ?: response.contents?.singleColumnBrowseResultsRenderer?.tabs?.firstOrNull()?.tabRenderer?.content?.sectionListRenderer
                        ?.contents?.firstOrNull()?.musicShelfRenderer?.contents?.firstOrNull()?.musicResponsiveListItemRenderer?.navigationEndpoint?.watchPlaylistEndpoint,
                radioEndpoint = response.header?.musicImmersiveHeaderRenderer?.startRadioButton?.buttonRenderer?.navigationEndpoint?.watchEndpoint
            ),
            sections = response.contents?.singleColumnBrowseResultsRenderer?.tabs?.firstOrNull()
                ?.tabRenderer?.content?.sectionListRenderer?.contents
                ?.mapNotNull(ArtistPage::fromSectionListRendererContent)!!,
            description = descriptionRuns?.joinToString(separator = "") { it.text },
                subscriberCountText = response.header?.musicImmersiveHeaderRenderer?.subscriptionButton2
                    ?.subscribeButtonRenderer?.subscriberCountWithSubscribeText?.runs?.firstOrNull()?.text
                    ?: response.header?.musicImmersiveHeaderRenderer?.subscriptionButton?.subscribeButtonRenderer
                        ?.longSubscriberCountText?.runs?.firstOrNull()?.text
                    ?: response.header?.musicImmersiveHeaderRenderer?.subscriptionButton?.subscribeButtonRenderer
                        ?.shortSubscriberCountText?.runs?.firstOrNull()?.text,
            monthlyListenerCount = response.header?.musicImmersiveHeaderRenderer?.monthlyListenerCount?.runs?.firstOrNull()?.text,
            descriptionRuns = descriptionRuns
        )
    }

    suspend fun artistItems(endpoint: BrowseEndpoint): Result<ArtistItemsPage> = runCatching {
        val response = innerTube.browse(WEB_REMIX, endpoint.browseId, endpoint.params).body<BrowseResponse>()
        val sectionContent = response.contents?.singleColumnBrowseResultsRenderer?.tabs?.firstOrNull()
            ?.tabRenderer?.content?.sectionListRenderer?.contents?.firstOrNull()
        
        val gridRenderer = sectionContent?.gridRenderer
        val musicCarouselShelfRenderer = sectionContent?.musicCarouselShelfRenderer
        val musicPlaylistShelfRenderer = sectionContent?.musicPlaylistShelfRenderer
        val musicShelfRenderer = sectionContent?.musicShelfRenderer
        
        when {
            gridRenderer != null -> {
                ArtistItemsPage(
                    title = gridRenderer.header?.gridHeaderRenderer?.title?.runs?.firstOrNull()?.text.orEmpty(),
                    items = gridRenderer.items.mapNotNull {
                        it.musicTwoRowItemRenderer?.let { renderer ->
                            ArtistItemsPage.fromMusicTwoRowItemRenderer(renderer)
                        }
                    },
                    continuation = gridRenderer.continuations?.getContinuation()
                )
            }
            musicCarouselShelfRenderer != null -> {
                ArtistItemsPage(
                    title = musicCarouselShelfRenderer.header?.musicCarouselShelfBasicHeaderRenderer?.title?.runs?.firstOrNull()?.text.orEmpty(),
                    items = musicCarouselShelfRenderer.contents.mapNotNull { content ->
                        content.musicTwoRowItemRenderer?.let { renderer ->
                            ArtistItemsPage.fromMusicTwoRowItemRenderer(renderer)
                        } ?: content.musicResponsiveListItemRenderer?.let { renderer ->
                            ArtistItemsPage.fromMusicResponsiveListItemRenderer(renderer)
                        }
                    },
                    continuation = null
                )
            }
            musicShelfRenderer != null -> {
                ArtistItemsPage(
                    title = musicShelfRenderer.title?.runs?.firstOrNull()?.text 
                        ?: response.header?.musicHeaderRenderer?.title?.runs?.firstOrNull()?.text 
                        ?: "",
                    items = musicShelfRenderer.contents?.getItems()?.mapNotNull {
                        ArtistItemsPage.fromMusicResponsiveListItemRenderer(it)
                    } ?: emptyList(),
                    continuation = musicShelfRenderer.continuations?.getContinuation()
                )
            }
            else -> {
                ArtistItemsPage(
                    title = response.header?.musicHeaderRenderer?.title?.runs?.firstOrNull()?.text ?: "",
                    items = musicPlaylistShelfRenderer?.contents?.getItems()?.mapNotNull {
                        ArtistItemsPage.fromMusicResponsiveListItemRenderer(it)
                    } ?: emptyList(),
                    continuation = musicPlaylistShelfRenderer?.contents?.getContinuation()
                )
            }
        }
    }

    suspend fun artistItemsContinuation(continuation: String): Result<ArtistItemsContinuationPage> = runCatching {
        val response = innerTube.browse(WEB_REMIX, continuation = continuation).body<BrowseResponse>()

        when {
            response.continuationContents?.gridContinuation != null -> {
                val gridContinuation = response.continuationContents.gridContinuation
                val items = gridContinuation.items.mapNotNull {
                    it.musicTwoRowItemRenderer?.let { renderer ->
                        ArtistItemsPage.fromMusicTwoRowItemRenderer(renderer)
                    }
                }
                ArtistItemsContinuationPage(
                    items = items,
                    continuation = if (items.isEmpty()) null else gridContinuation.continuations?.getContinuation()
                )
            }

            response.continuationContents?.musicPlaylistShelfContinuation != null -> {
                val musicPlaylistShelfContinuation = response.continuationContents.musicPlaylistShelfContinuation
                val items = musicPlaylistShelfContinuation.contents.getItems().mapNotNull {
                    ArtistItemsPage.fromMusicResponsiveListItemRenderer(it)
                }
                ArtistItemsContinuationPage(
                    items = items,
                    continuation = if (items.isEmpty()) null else musicPlaylistShelfContinuation.continuations?.getContinuation()
                )
            }

            else -> {
                val continuationItems = response.onResponseReceivedActions?.firstOrNull()
                    ?.appendContinuationItemsAction?.continuationItems
                val items = continuationItems?.getItems()?.mapNotNull {
                    ArtistItemsPage.fromMusicResponsiveListItemRenderer(it)
                } ?: emptyList()
                ArtistItemsContinuationPage(
                    items = items,
                    continuation = if (items.isEmpty()) null else continuationItems?.getContinuation()
                )
            }
        }
    }

    suspend fun playlist(playlistId: String): Result<PlaylistPage> = runCatching {
        val response = innerTube.browse(
            client = WEB_REMIX,
            browseId = "VL$playlistId",
            setLogin = true
        ).body<BrowseResponse>()
        val base = response.contents?.twoColumnBrowseResultsRenderer?.tabs?.firstOrNull()?.tabRenderer?.content?.sectionListRenderer?.contents?.firstOrNull()
        val header = base?.musicResponsiveHeaderRenderer ?: base?.musicEditablePlaylistDetailHeaderRenderer?.header?.musicResponsiveHeaderRenderer

        val editable = base?.musicEditablePlaylistDetailHeaderRenderer != null
        val secondarySectionList = response.contents?.twoColumnBrowseResultsRenderer?.secondaryContents?.sectionListRenderer

        var relatedTitle: String? = null
        var related = secondarySectionList?.contents?.let {
            val title = parseRelatedTitle(it.drop(1))
            if (title != null) relatedTitle = title
            parseRelatedItems(it.drop(1))
        }

        if (related.isNullOrEmpty()) {
            secondarySectionList?.continuations?.getContinuation()?.let { continuationToken ->
                val continuationResponse = innerTube.browse(
                    client = WEB_REMIX,
                    continuation = continuationToken,
                    setLogin = true
                ).body<BrowseResponse>()

                continuationResponse.continuationContents?.sectionListContinuation?.contents?.let {
                    val title = parseRelatedTitle(it)
                    if (title != null) relatedTitle = title
                    val parsed = parseRelatedItems(it)
                    if (parsed.isNotEmpty()) {
                        related = parsed
                    }
                }
            }
        }

        // Safely extract header title — null means the API response is unrecognisable
        val title = header?.title?.runs?.firstOrNull()?.text
            ?: throw IllegalStateException("Playlist title not found for id=$playlistId (header=${header != null})")

        // Thumbnail is optional — fall back to empty string rather than crashing
        val thumbnailUrl = header.thumbnail?.musicThumbnailRenderer?.thumbnail?.thumbnails?.lastOrNull()?.url
            ?: ""

        // shuffleEndpoint is NOT guaranteed — remove !! to avoid NPE
        val shuffleEndpoint = header.buttons.lastOrNull()?.menuRenderer?.items?.firstOrNull()
            ?.menuNavigationItemRenderer?.navigationEndpoint?.watchPlaylistEndpoint

        val sectionListContents = response.contents?.twoColumnBrowseResultsRenderer
            ?.tabs?.firstOrNull()?.tabRenderer?.content?.sectionListRenderer?.contents

        // Also check secondary contents (right column - song list area)
        val secondarySectionListContents = response.contents?.twoColumnBrowseResultsRenderer
            ?.secondaryContents?.sectionListRenderer?.contents

        // Debug: log what each source returns
        val descFromShelf = sectionListContents?.firstNotNullOfOrNull {
            it.musicDescriptionShelfRenderer?.description?.runs?.joinToString("") { run -> run.text }
        }
        val descFromSecondaryShelf = secondarySectionListContents?.firstNotNullOfOrNull {
            it.musicDescriptionShelfRenderer?.description?.runs?.joinToString("") { run -> run.text }
        }
        val descFromHeader = header.description?.musicDescriptionShelfRenderer?.description?.runs?.joinToString("") { it.text }
        val descFromEditable = base?.musicEditablePlaylistDetailHeaderRenderer
            ?.header?.musicDetailHeaderRenderer
            ?.description?.runs?.joinToString("") { it.text }
        val descFromTopLevel = response.header?.musicDetailHeaderRenderer
            ?.description?.runs?.joinToString("") { it.text }
        val descFromMicroformat = response.microformat?.microformatDataRenderer?.description

        val description: String? = descFromShelf ?: descFromSecondaryShelf ?: descFromHeader ?: descFromEditable ?: descFromTopLevel ?: descFromMicroformat
        val facepileAuthor = header.facepile?.getAuthorName()?.let { authorName ->
            Artist(
                name = authorName,
                id = header.facepile.getAuthorBrowseId()
            )
        }
        val straplineAuthor = header.straplineTextOne?.runs?.firstOrNull()?.let {
            Artist(
                name = it.text,
                id = it.navigationEndpoint?.browseEndpoint?.browseId
            )
        }
        val subtitleAuthor = header.subtitle.runs?.let { runs ->
            runs.find { it.navigationEndpoint?.browseEndpoint?.browseId != null }?.let {
                Artist(
                    name = it.text,
                    id = it.navigationEndpoint?.browseEndpoint?.browseId
                )
            } ?: runs.splitBySeparator().let { parts ->
                if (parts.size >= 3) {
                    parts[1].firstOrNull()?.let {
                        Artist(
                            name = it.text,
                            id = it.navigationEndpoint?.browseEndpoint?.browseId
                        )
                    }
                } else if (parts.size == 2 && parts[1].firstOrNull()?.text?.toIntOrNull() == null) {
                    parts[1].firstOrNull()?.let {
                        Artist(
                            name = it.text,
                            id = it.navigationEndpoint?.browseEndpoint?.browseId
                        )
                    }
                } else null
            }
        }
        val author = facepileAuthor ?: straplineAuthor ?: subtitleAuthor

        val authorThumbnailUrl = header.facepile?.getAuthorThumbnailUrl()
            ?: header.straplineThumbnail?.musicThumbnailRenderer?.getThumbnailUrl()
            ?: header.straplineThumbnail?.croppedSquareThumbnailRenderer?.getThumbnailUrl()

        PlaylistPage(
            playlist = PlaylistItem(
                id = playlistId,
                title = title,
                author = author,
                songCountText = header.secondSubtitle?.runs?.firstOrNull()?.text,
                thumbnail = thumbnailUrl,
                playEndpoint = null,
                shuffleEndpoint = shuffleEndpoint,
                radioEndpoint = header.buttons.getOrNull(2)?.menuRenderer?.items?.find {
                    it.menuNavigationItemRenderer?.icon?.iconType == "MIX"
                }?.menuNavigationItemRenderer?.navigationEndpoint?.watchPlaylistEndpoint,
                isEditable = editable,
                description = description,
                authorThumbnail = authorThumbnailUrl,
            ),
            songs = response.contents?.twoColumnBrowseResultsRenderer?.secondaryContents?.sectionListRenderer
                ?.contents?.firstOrNull()?.musicPlaylistShelfRenderer?.contents?.getItems()?.mapNotNull {
                    PlaylistPage.fromMusicResponsiveListItemRenderer(it)
                } ?: emptyList(),
            songsContinuation = response.contents?.twoColumnBrowseResultsRenderer?.secondaryContents?.sectionListRenderer
                ?.contents?.firstOrNull()?.musicPlaylistShelfRenderer?.contents?.getContinuation()
                ?: response.contents?.twoColumnBrowseResultsRenderer?.secondaryContents?.sectionListRenderer
                    ?.contents?.firstOrNull()?.musicPlaylistShelfRenderer?.continuations?.getContinuation(),
            continuation = response.contents?.twoColumnBrowseResultsRenderer?.secondaryContents?.sectionListRenderer
                ?.continuations?.getContinuation(),
            related = related?.ifEmpty { null },
            relatedTitle = relatedTitle
        )
    }

    private fun parseRelatedTitle(contents: List<SectionListRenderer.Content>): String? {
        return contents.firstNotNullOfOrNull {
            it.musicCarouselShelfRenderer?.header?.musicCarouselShelfBasicHeaderRenderer?.title?.runs?.firstOrNull()?.text
                ?: it.musicShelfRenderer?.title?.runs?.firstOrNull()?.text
        }
    }

    private fun parseRelatedItems(contents: List<SectionListRenderer.Content>): List<YTItem> {
        return contents.mapNotNull { content ->
            content.musicCarouselShelfRenderer?.let { renderer ->
                renderer.contents.mapNotNull { it.musicTwoRowItemRenderer }.mapNotNull { RelatedPage.fromMusicTwoRowItemRenderer(it) }
            } ?: content.musicShelfRenderer?.let { renderer ->
                renderer.contents?.getItems()?.mapNotNull { SearchSummaryPage.fromMusicResponsiveListItemRenderer(it) }
            }
        }.flatten()
    }

    suspend fun playlistContinuation(continuation: String): Result<PlaylistContinuationPage> = runCatching {
        val response = innerTube.browse(
            client = WEB_REMIX,
            continuation = continuation,
            setLogin = true
        ).body<BrowseResponse>()

        val mainContents: List<MusicShelfRenderer.Content> = response.continuationContents?.sectionListContinuation?.contents
            ?.mapNotNull { content: SectionListRenderer.Content -> content.musicPlaylistShelfRenderer?.contents }
            ?.flatten()
            ?: emptyList()

        val shelfContents: List<MusicShelfRenderer.Content> =
            response.continuationContents?.musicPlaylistShelfContinuation?.contents ?: emptyList()

        val appendedContents: List<MusicShelfRenderer.Content> = response.onResponseReceivedActions
            ?.firstOrNull()
            ?.appendContinuationItemsAction
            ?.continuationItems
            .orEmpty()

        val allContents = mainContents + shelfContents + appendedContents

        val songs = allContents
            .mapNotNull { content: MusicShelfRenderer.Content -> content.musicResponsiveListItemRenderer }
            .mapNotNull { renderer -> PlaylistPage.fromMusicResponsiveListItemRenderer(renderer) }

        val nextContinuation = if (songs.isEmpty()) null else {
            response.continuationContents
                ?.sectionListContinuation
                ?.continuations
                ?.getContinuation()
                ?: response.continuationContents
                    ?.musicPlaylistShelfContinuation
                    ?.continuations
                    ?.getContinuation()
                ?: response.continuationContents
                    ?.musicShelfContinuation
                    ?.continuations
                    ?.getContinuation()
                ?: response.onResponseReceivedActions
                    ?.firstOrNull()
                    ?.appendContinuationItemsAction
                    ?.continuationItems
                    ?.getContinuation()
        }

        PlaylistContinuationPage(
            songs = songs,
            continuation = nextContinuation
        )
    }

    suspend fun home(continuation: String? = null, params: String? = null): Result<HomePage> = runCatching {
        if (continuation != null) {
            return@runCatching homeContinuation(continuation).getOrThrow()
        }

        val useHtmlScraping = params == null
        val response = if (useHtmlScraping) {
            try {
                android.util.Log.d("QP_DEBUG", "home: Starting HTML scraping")
                val html = innerTube.getWebPage("https://music.youtube.com/")
                android.util.Log.d("QP_DEBUG", "home: HTML fetched successfully, length: ${html.length}")
                
                var parsedJson: String? = null
                
                var rawData: String? = null
                
                val searchPattern = "'\\/browse'"
                var index = 0
                while(true) {
                    index = html.indexOf(searchPattern, index)
                    if (index == -1) break
                    
                    val nextData = html.indexOf("data: '", index)
                    if (nextData == -1) break
                    
                    val checkArea = html.substring(index, nextData)
                    if (checkArea.contains("FEmusic_home") || checkArea.contains("584D657375635F686F6D65")) { // hex encoded FEmusic_home is \x46\x45\x6D\x75\x73\x69\x63\x5F\x68\x6F\x6D\x65 but usually it's plain text in JSON.parse
                        val jsonStart = nextData + 7
                        val jsonEnd = html.indexOf("'", jsonStart)
                        if (jsonEnd != -1) {
                            rawData = html.substring(jsonStart, jsonEnd)
                            break
                        }
                    }
                    index = nextData
                }

                if (rawData != null) {
                    android.util.Log.d("QP_DEBUG", "home: FEmusic_home match found, rawData length: ${rawData.length}")
                    
                    val builder = java.lang.StringBuilder(rawData.length)
                    var i = 0
                    while (i < rawData.length) {
                        if (rawData[i] == '\\' && i + 3 < rawData.length && rawData[i + 1] == 'x') {
                            try {
                                val hexChar = rawData.substring(i + 2, i + 4).toInt(16).toChar()
                                builder.append(hexChar)
                                i += 4
                                continue
                            } catch (e: Exception) {
                                builder.append(rawData[i])
                                i++
                                continue
                            }
                        } else {
                            builder.append(rawData[i])
                            i++
                        }
                    }
                    parsedJson = builder.toString().replace("\\\\", "\\")
                    android.util.Log.d("QP_DEBUG", "home: Decoded hex strings (fast), parsedJson length: ${parsedJson.length}")
                } else {
                    android.util.Log.d("QP_DEBUG", "home: Regex match FAILED. Fallback to var ytInitialData")
                    val searchPattern = "var ytInitialData = "
                    var startIndex = html.indexOf(searchPattern)
                    if (startIndex == -1) startIndex = html.indexOf("window[\"ytInitialData\"] = ")
                    android.util.Log.d("QP_DEBUG", "home: Fallback startIndex: $startIndex")
                    
                    if (startIndex != -1) {
                        val jsonStart = html.indexOf("{", startIndex)
                        val jsonEndPattern = "};</script>"
                        val jsonEnd = html.indexOf(jsonEndPattern, jsonStart)
                        if (jsonStart != -1 && jsonEnd != -1) {
                            parsedJson = html.substring(jsonStart, jsonEnd + 1)
                            android.util.Log.d("QP_DEBUG", "home: Legacy fallback parsed snippet, length: ${parsedJson.length}")
                        } else {
                            android.util.Log.d("QP_DEBUG", "home: Legacy fallback failed to find closing brace/script")
                        }
                    }
                }

                if (parsedJson != null) {
                    android.util.Log.d("QP_DEBUG", "home: Proceeding to decode lenientJson for BrowseResponse")
                    val lenientJson = Json { ignoreUnknownKeys = true; explicitNulls = false; encodeDefaults = true }
                    lenientJson.decodeFromString<BrowseResponse>(parsedJson)
                } else {
                    android.util.Log.d("QP_DEBUG", "home: parsedJson is null! Falling back to InnerTube API browse(...)")
                    innerTube.browse(WEB_REMIX, browseId = "FEmusic_home", params = params).body<BrowseResponse>()
                }
            } catch (e: Exception) {
                android.util.Log.e("QP_DEBUG", "home: Exception during HTML scraping: ${e.message}", e)
                e.printStackTrace()
                innerTube.browse(WEB_REMIX, browseId = "FEmusic_home", params = params).body<BrowseResponse>()
            }
        } else {
            android.util.Log.d("QP_DEBUG", "home: useHtmlScraping is false. Using InnerTube API browse(...)")
            innerTube.browse(WEB_REMIX, browseId = "FEmusic_home", params = params).body<BrowseResponse>()
        }

        val continuation = response.contents?.singleColumnBrowseResultsRenderer?.tabs?.firstOrNull()
            ?.tabRenderer?.content?.sectionListRenderer?.continuations?.getContinuation()
        val sectionListRender = response.contents?.singleColumnBrowseResultsRenderer?.tabs?.firstOrNull()
            ?.tabRenderer?.content?.sectionListRenderer
        val sections = sectionListRender?.contents!!
            .mapNotNull { it.musicCarouselShelfRenderer }
            .mapNotNull {
                HomePage.Section.fromMusicCarouselShelfRenderer(it)
            }.toMutableList()
        val chips = sectionListRender.header?.chipCloudRenderer?.chips?.mapNotNull { HomePage.Chip.fromChipCloudChipRenderer(it) }
        HomePage(chips, sections, continuation)
    }

    private suspend fun homeContinuation(continuation: String): Result<HomePage> = runCatching {
        val response =
            innerTube.browse(WEB_REMIX, continuation = continuation).body<BrowseResponse>()
        val continuation =
            response.continuationContents?.sectionListContinuation?.continuations?.getContinuation()
        HomePage(
            null,
            response.continuationContents?.sectionListContinuation?.contents
            ?.mapNotNull { it.musicCarouselShelfRenderer }
            ?.mapNotNull {
                HomePage.Section.fromMusicCarouselShelfRenderer(it)
            }.orEmpty(), continuation
        )
    }

    suspend fun explore(): Result<ExplorePage> = runCatching {
        val response = innerTube.browse(WEB_REMIX, browseId = "FEmusic_explore").body<BrowseResponse>()
        ExplorePage(
            newReleaseAlbums = response.contents?.singleColumnBrowseResultsRenderer?.tabs?.firstOrNull()?.tabRenderer?.content?.sectionListRenderer?.contents?.find {
                it.musicCarouselShelfRenderer?.header?.musicCarouselShelfBasicHeaderRenderer?.moreContentButton?.buttonRenderer?.navigationEndpoint?.browseEndpoint?.browseId == "FEmusic_new_releases_albums"
            }?.musicCarouselShelfRenderer?.contents
                ?.mapNotNull { it.musicTwoRowItemRenderer }
                ?.mapNotNull(NewReleaseAlbumPage::fromMusicTwoRowItemRenderer).orEmpty(),
            moodAndGenres = response.contents?.singleColumnBrowseResultsRenderer?.tabs?.firstOrNull()?.tabRenderer?.content?.sectionListRenderer?.contents?.find {
                it.musicCarouselShelfRenderer?.header?.musicCarouselShelfBasicHeaderRenderer?.moreContentButton?.buttonRenderer?.navigationEndpoint?.browseEndpoint?.browseId == "FEmusic_moods_and_genres"
            }?.musicCarouselShelfRenderer?.contents
                ?.mapNotNull { it.musicNavigationButtonRenderer }
                ?.mapNotNull(MoodAndGenres.Companion::fromMusicNavigationButtonRenderer)
                .orEmpty()
        )
    }

    suspend fun newReleaseAlbums(): Result<List<AlbumItem>> = runCatching {
        val response = innerTube.browse(WEB_REMIX, browseId = "FEmusic_new_releases_albums").body<BrowseResponse>()
        response.contents?.singleColumnBrowseResultsRenderer?.tabs?.firstOrNull()?.tabRenderer?.content?.sectionListRenderer?.contents?.firstOrNull()?.gridRenderer?.items
            ?.mapNotNull { it.musicTwoRowItemRenderer }
            ?.mapNotNull(NewReleaseAlbumPage::fromMusicTwoRowItemRenderer)
            .orEmpty()
    }

    suspend fun moodAndGenres(): Result<List<MoodAndGenres>> = runCatching {
        val response = innerTube.browse(WEB_REMIX, browseId = "FEmusic_moods_and_genres").body<BrowseResponse>()
        response.contents?.singleColumnBrowseResultsRenderer?.tabs?.firstOrNull()?.tabRenderer?.content?.sectionListRenderer?.contents!!
            .mapNotNull(MoodAndGenres.Companion::fromSectionListRendererContent)
    }

    suspend fun browse(browseId: String, params: String?): Result<BrowseResult> = runCatching {
        val response = innerTube.browse(WEB_REMIX, browseId = browseId, params = params).body<BrowseResponse>()
        BrowseResult(
            title = response.header?.musicHeaderRenderer?.title?.runs?.firstOrNull()?.text,
            items = response.contents?.singleColumnBrowseResultsRenderer?.tabs?.firstOrNull()?.tabRenderer?.content?.sectionListRenderer?.contents?.mapNotNull { content ->
                when {
                    content.gridRenderer != null -> {
                        BrowseResult.Item(
                            title = content.gridRenderer.header?.gridHeaderRenderer?.title?.runs?.firstOrNull()?.text,
                            items = content.gridRenderer.items
                                .mapNotNull(GridRenderer.Item::musicTwoRowItemRenderer)
                                .mapNotNull(RelatedPage.Companion::fromMusicTwoRowItemRenderer)
                        )
                    }

                    content.musicCarouselShelfRenderer != null -> {
                        BrowseResult.Item(
                            title = content.musicCarouselShelfRenderer.header?.musicCarouselShelfBasicHeaderRenderer?.title?.runs?.firstOrNull()?.text,
                            items = content.musicCarouselShelfRenderer.contents
                                .mapNotNull(MusicCarouselShelfRenderer.Content::musicTwoRowItemRenderer)
                                .mapNotNull(RelatedPage.Companion::fromMusicTwoRowItemRenderer)
                        )
                    }

                    else -> null
                }
            }.orEmpty()
        )
    }

    suspend fun library(browseId: String, tabIndex: Int = 0): Result<LibraryPage> {
        println("[UPLOAD_DEBUG] library() called with browseId=$browseId, tabIndex=$tabIndex")
        return runCatching {
            val response = innerTube.browse(
                client = WEB_REMIX,
                browseId = browseId,
                setLogin = true
            ).body<BrowseResponse>()

            val tabs = response.contents?.singleColumnBrowseResultsRenderer?.tabs
            println("[UPLOAD_DEBUG] tabs count: ${tabs?.size ?: 0}")

            // Debug: log the structure for uploaded songs browseId
            if (browseId == "FEmusic_library_privately_owned_tracks") {
                println("[UPLOAD_DEBUG] Raw response.contents: ${response.contents}")
                tabs?.forEachIndexed { idx, tab ->
                    println("[UPLOAD_DEBUG] Tab $idx: tabRenderer.content null? ${tab.tabRenderer.content == null}")
                    println("[UPLOAD_DEBUG] Tab $idx: sectionListRenderer null? ${tab.tabRenderer.content?.sectionListRenderer == null}")
                    println("[UPLOAD_DEBUG] Tab $idx: sectionListRenderer.contents size: ${tab.tabRenderer.content?.sectionListRenderer?.contents?.size ?: 0}")
                    tab.tabRenderer.content?.sectionListRenderer?.contents?.forEachIndexed { cIdx, content ->
                        println("[UPLOAD_DEBUG] Tab $idx Content $cIdx: gridRenderer=${content.gridRenderer != null}, musicShelfRenderer=${content.musicShelfRenderer != null}")
                    }
                }
            }

            val contents = if (tabs != null && tabs.size >= tabIndex) {
                tabs[tabIndex].tabRenderer.content?.sectionListRenderer?.contents?.firstOrNull()
            }
            else {
                println("[UPLOAD_DEBUG] No tabs or tabIndex out of range")
                null
            }

            println("[UPLOAD_DEBUG] contents null? ${contents == null}")
            println("[UPLOAD_DEBUG] gridRenderer null? ${contents?.gridRenderer == null}")
            println("[UPLOAD_DEBUG] musicShelfRenderer null? ${contents?.musicShelfRenderer == null}")

            when {
                contents?.gridRenderer != null -> {
                    val gridItems = contents.gridRenderer.items
                    println("[UPLOAD_DEBUG] gridRenderer items count: ${gridItems.size}")
                    val twoRowItems = gridItems.mapNotNull(GridRenderer.Item::musicTwoRowItemRenderer)
                    println("[UPLOAD_DEBUG] musicTwoRowItemRenderer count: ${twoRowItems.size}")
                    val parsedItems = twoRowItems.mapNotNull { LibraryPage.fromMusicTwoRowItemRenderer(it) }
                    println("[UPLOAD_DEBUG] Successfully parsed items: ${parsedItems.size}")
                    LibraryPage(
                        items = parsedItems,
                        continuation = contents.gridRenderer.continuations?.getContinuation()
                    )
                }

                else -> { // contents?.musicShelfRenderer != null
                    val shelfContents = contents?.musicShelfRenderer?.contents
                    println("[UPLOAD_DEBUG] musicShelfRenderer contents count: ${shelfContents?.size ?: 0}")
                    if (shelfContents == null) {
                        // API response format may have changed (e.g. Google updated response structure).
                        // Return an empty page gracefully instead of crashing the entire library fetch,
                        // which would keep accountPlaylists null and hide the homescreen playlists section.
                        println("[UPLOAD_DEBUG] WARNING: No gridRenderer or musicShelfRenderer found for browseId=$browseId. API format may have changed. contents=$contents")
                        return@runCatching LibraryPage(items = emptyList(), continuation = null)
                    }
                    val listItemRenderers = shelfContents.mapNotNull(MusicShelfRenderer.Content::musicResponsiveListItemRenderer)
                    println("[UPLOAD_DEBUG] musicResponsiveListItemRenderer count: ${listItemRenderers.size}")

                    listItemRenderers.forEachIndexed { index, renderer ->
                        println("[UPLOAD_DEBUG] Item $index: isSong=${renderer.isSong}, isArtist=${renderer.isArtist}, isAlbum=${renderer.isAlbum}, isPlaylist=${renderer.isPlaylist}")
                        println("[UPLOAD_DEBUG] Item $index: playlistItemData=${renderer.playlistItemData}")
                        println("[UPLOAD_DEBUG] Item $index: flexColumns count=${renderer.flexColumns.size}")
                        renderer.flexColumns.forEachIndexed { colIdx, col ->
                            println("[UPLOAD_DEBUG] Item $index flexColumn $colIdx: ${col.musicResponsiveListItemFlexColumnRenderer.text?.runs?.map { it.text }}")
                        }
                        println("[UPLOAD_DEBUG] Item $index: thumbnail=${renderer.thumbnail?.musicThumbnailRenderer?.thumbnail}")
                    }

                    val parsedItems = listItemRenderers.mapNotNull { renderer ->
                        val result = LibraryPage.fromMusicResponsiveListItemRenderer(renderer)
                        if (result == null) {
                            println("[UPLOAD_DEBUG] Failed to parse renderer: videoId=${renderer.playlistItemData?.videoId}")
                        }
                        result
                    }
                    println("[UPLOAD_DEBUG] Successfully parsed items: ${parsedItems.size}")
                    parsedItems.filterIsInstance<SongItem>().forEach { song ->
                        println("[UPLOAD_DEBUG] Parsed song: id=${song.id}, title=${song.title}, artists=${song.artists.map { it.name }}")
                    }
                    LibraryPage(
                        items = parsedItems,
                        continuation = contents.musicShelfRenderer.continuations?.getContinuation()
                    )
                }
            }
        }.onFailure { e ->
            println("[UPLOAD_DEBUG] library() EXCEPTION for browseId=$browseId: ${e::class.simpleName}: ${e.message}")
            e.printStackTrace()
        }
    }

    suspend fun libraryContinuation(continuation: String) = runCatching {
        val response = innerTube.browse(
            client = WEB_REMIX,
            continuation = continuation,
            setLogin = true
        ).body<BrowseResponse>()

        val contents = response.continuationContents

        when {
            contents?.gridContinuation != null -> {
                LibraryContinuationPage(
                    items = contents.gridContinuation.items
                        .mapNotNull (GridRenderer.Item::musicTwoRowItemRenderer)
                        .mapNotNull { LibraryPage.fromMusicTwoRowItemRenderer(it) },
                    continuation = contents.gridContinuation.continuations?.getContinuation()
                )
            }

            else -> { // contents?.musicShelfContinuation != null
                LibraryContinuationPage(
                    items = contents?.musicShelfContinuation?.contents!!
                        .mapNotNull (MusicShelfRenderer.Content::musicResponsiveListItemRenderer)
                        .mapNotNull { LibraryPage.fromMusicResponsiveListItemRenderer(it) },
                    continuation = contents.musicShelfContinuation.continuations?.getContinuation()
                )
            }
        }
    }

    suspend fun libraryRecentActivity(): Result<LibraryPage> = runCatching {
        val continuation = LibraryFilter.FILTER_RECENT_ACTIVITY.value

        val response = innerTube.browse(
            client = WEB_REMIX,
            continuation = continuation,
            setLogin = true
        ).body<BrowseResponse>()

        val gridItems = response.continuationContents?.sectionListContinuation?.contents?.firstOrNull()
            ?.gridRenderer?.items
        
        if (gridItems == null) {
            return@runCatching LibraryPage(
                items = emptyList(),
                continuation = null
            )
        }
        
        val items = gridItems.mapNotNull {
            it.musicTwoRowItemRenderer?.let { renderer ->
                LibraryPage.fromMusicTwoRowItemRenderer(renderer)
            }
        }.toMutableList()

        /*
         * We need to fetch the artist page when accessing the library because it allows to have
         * a proper playEndpoint, which is needed to correctly report the playing indicator in
         * the home page.
         *
         * Despite this, we need to use the old thumbnail because it's the proper format for a
         * square picture, which is what we need.
         */
        items.forEachIndexed { index, item ->
            if (item is ArtistItem) {
                artist(item.id).getOrNull()?.artist?.let { fetchedArtist ->
                    items[index] = fetchedArtist.copy(thumbnail = item.thumbnail)
                }
            }
        }

        LibraryPage(
            items = items,
            continuation = null
        )
    }

    suspend fun getChartsPage(continuation: String? = null): Result<ChartsPage> = runCatching {
        val response = innerTube.browse(
            client = WEB_REMIX,
            browseId = "FEmusic_charts",
            params = "ggMGCgQIgAQ%3D",
            continuation = continuation
        ).body<BrowseResponse>()

        val sections = mutableListOf<ChartsPage.ChartSection>()
    
        response.contents?.singleColumnBrowseResultsRenderer?.tabs?.firstOrNull()
            ?.tabRenderer?.content?.sectionListRenderer?.contents?.forEach { content ->
            
                content.musicCarouselShelfRenderer?.let { renderer ->
                    val title = renderer.header?.musicCarouselShelfBasicHeaderRenderer?.title?.runs?.firstOrNull()?.text
                        ?: return@forEach
                
                    val items = renderer.contents.mapNotNull { item ->
                        when {
                            item.musicResponsiveListItemRenderer != null -> 
                                convertToChartItem(item.musicResponsiveListItemRenderer)
                            item.musicTwoRowItemRenderer != null -> 
                                convertMusicTwoRowItem(item.musicTwoRowItemRenderer)
                            else -> null
                        }
                    }.filterNotNull()
                
                    if (items.isNotEmpty()) {
                        sections.add(
                            ChartsPage.ChartSection(
                                title = title,
                                items = items,
                                chartType = determineChartType(title)
                            )
                        )
                    }
                }
            
                content.gridRenderer?.let { renderer ->
                    val title = renderer.header?.gridHeaderRenderer?.title?.runs?.firstOrNull()?.text
                        ?: return@let
                
                    val items = renderer.items.mapNotNull { item ->
                        item.musicTwoRowItemRenderer?.let { renderer ->
                            convertMusicTwoRowItem(renderer)
                        }
                    }.filterNotNull()
                
                    if (items.isNotEmpty()) {
                        sections.add(
                            ChartsPage.ChartSection(
                                title = title,
                                items = items,
                                chartType = ChartsPage.ChartType.NEW_RELEASES
                            )
                        )
                    }
                }
            }

        ChartsPage(
            sections = sections,
            continuation = response.continuationContents?.sectionListContinuation?.continuations?.getContinuation()
        )
    }

    private fun determineChartType(title: String): ChartsPage.ChartType {
        return when {
            title.contains("Trending", ignoreCase = true) -> ChartsPage.ChartType.TRENDING
            title.contains("Top", ignoreCase = true) -> ChartsPage.ChartType.TOP
            else -> ChartsPage.ChartType.GENRE
        }
    }

    private fun convertToChartItem(renderer: MusicResponsiveListItemRenderer): YTItem? {
        return try {
            when {
                renderer.flexColumns.size >= 3 && renderer.playlistItemData?.videoId != null -> {
                    val firstColumn = renderer.flexColumns.getOrNull(0)
                        ?.musicResponsiveListItemFlexColumnRenderer
                        ?.text ?: return null
                
                    val secondColumn = renderer.flexColumns.getOrNull(1)
                        ?.musicResponsiveListItemFlexColumnRenderer
                        ?.text ?: return null

                    val titleRun = firstColumn.runs?.firstOrNull() ?: return null
                    val title = titleRun.text.takeIf { it.isNotBlank() } ?: return null

                    val artists = secondColumn.runs?.mapNotNull { run ->
                        run.text.takeIf { it.isNotBlank() }?.let { name ->
                            Artist(
                                name = name,
                                id = run.navigationEndpoint?.browseEndpoint?.browseId
                            )
                        }
                    } ?: emptyList()

                    val thirdColumn = renderer.flexColumns.getOrNull(2)
                        ?.musicResponsiveListItemFlexColumnRenderer
                        ?.text

                    SongItem(
                        id = renderer.playlistItemData.videoId,
                        title = title,
                        artists = artists,
                        thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                        musicVideoType = renderer.musicVideoType,
                        explicit = renderer.badges?.any { 
                            it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE" 
                        } == true,
                        chartPosition = thirdColumn?.runs?.firstOrNull()?.text?.toIntOrNull(),
                        chartChange = thirdColumn?.runs?.getOrNull(1)?.text
                    )
                }
                else -> null
            }
        } catch (e: Exception) {
            println("Error converting chart item: ${e.message}\n${Json.encodeToString(renderer)}")
            null
        }
    }

    private fun convertMusicTwoRowItem(renderer: MusicTwoRowItemRenderer): YTItem? {
        return try {
            when {
                renderer.isSong -> {
                    val subtitle = renderer.subtitle?.runs ?: return null
                    SongItem(
                        id = renderer.navigationEndpoint.watchEndpoint?.videoId ?: return null,
                        title = renderer.title.runs?.firstOrNull()?.text ?: return null,
                        artists = subtitle.mapNotNull {
                            it.navigationEndpoint?.browseEndpoint?.browseId?.let { id ->
                                Artist(name = it.text, id = id)
                            }
                        },
                        thumbnail = renderer.thumbnailRenderer.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                        musicVideoType = renderer.musicVideoType,
                        explicit = renderer.subtitleBadges?.any {
                            it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE"
                        } == true
                    )
                }
                renderer.isAlbum -> {
                    AlbumItem(
                        browseId = renderer.navigationEndpoint.browseEndpoint?.browseId ?: return null,
                        playlistId = renderer.thumbnailOverlay?.musicItemThumbnailOverlayRenderer?.content
                            ?.musicPlayButtonRenderer?.playNavigationEndpoint
                            ?.watchPlaylistEndpoint?.playlistId ?: return null,
                        title = renderer.title.runs?.firstOrNull()?.text ?: return null,
                        artists = renderer.subtitle?.runs?.oddElements()?.drop(1)?.mapNotNull {
                            it.navigationEndpoint?.browseEndpoint?.browseId?.let { id ->
                                Artist(name = it.text, id = id)
                            }
                        },
                        year = renderer.subtitle?.runs?.lastOrNull()?.text?.toIntOrNull(),
                        thumbnail = renderer.thumbnailRenderer.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                        explicit = renderer.subtitleBadges?.any {
                            it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE"
                        } == true
                    )
                }
                else -> null
            }
        } catch (e: Exception) {
            println("Error converting two row item: ${e.message}\n${Json.encodeToString(renderer)}")
            null
        }
    }

    suspend fun musicHistory() = runCatching {
        val response = innerTube.browse(
            client = WEB_REMIX,
            browseId = "FEmusic_history",
            setLogin = true
        ).body<BrowseResponse>()

        HistoryPage(
            sections = response.contents?.singleColumnBrowseResultsRenderer?.tabs?.firstOrNull()
                ?.tabRenderer?.content?.sectionListRenderer?.contents
                ?.mapNotNull {
                    it.musicShelfRenderer?.let { musicShelfRenderer ->
                        HistoryPage.fromMusicShelfRenderer(musicShelfRenderer)
                    }
                }
        )
    }

    suspend fun likeVideo(videoId: String, like: Boolean) = runCatching {
        if (like)
            innerTube.likeVideo(WEB_REMIX, videoId)
        else
            innerTube.unlikeVideo(WEB_REMIX, videoId)
    }

    suspend fun likePlaylist(playlistId: String, like: Boolean) = runCatching {
        if (like)
            innerTube.likePlaylist(WEB_REMIX, playlistId)
        else
            innerTube.unlikePlaylist(WEB_REMIX, playlistId)
    }

    suspend fun subscribeChannel(channelId: String, subscribe: Boolean) = runCatching {
        if (subscribe)
            innerTube.subscribeChannel(WEB_REMIX, channelId)
        else
            innerTube.unsubscribeChannel(WEB_REMIX, channelId)
    }

    suspend fun getChannelId(browseId: String): String {
        artist(browseId).onSuccess {
            return it.artist.channelId ?: ""
        }
        return ""
    }

    suspend fun addToPlaylist(playlistId: String, videoId: String) = runCatching {
        innerTube.addToPlaylist(WEB_REMIX, playlistId, videoId)
    }

    suspend fun addPlaylistToPlaylist(playlistId: String, addPlaylistId: String) = runCatching {
        innerTube.addPlaylistToPlaylist(WEB_REMIX, playlistId, addPlaylistId)
    }

    suspend fun removeFromPlaylist(playlistId: String, videoId: String, setVideoId: String) = runCatching {
        innerTube.removeFromPlaylist(WEB_REMIX, playlistId, videoId, setVideoId)
    }

    suspend fun moveSongPlaylist(playlistId: String, setVideoId: String, successorSetVideoId: String?) = runCatching {
        innerTube.moveSongPlaylist(WEB_REMIX, playlistId, setVideoId, successorSetVideoId)
    }

    fun createPlaylist(title: String) = runBlocking {
        innerTube.createPlaylist(WEB_REMIX, title).body<CreatePlaylistResponse>().playlistId
    }

    suspend fun renamePlaylist(playlistId: String, name: String) = runCatching {
        innerTube.renamePlaylist(WEB_REMIX, playlistId, name)
    }

    suspend fun uploadCustomThumbnailLink(playlistId: String, image: ByteArray) = runCatching {
        val uploadUrl = innerTube.getUploadCustomThumbnailLink(WEB_REMIX, image.size).headers["x-guploader-uploadid"]
        val blobReq = innerTube.uploadCustomThumbnail(
            WEB_REMIX,
            uploadUrl!!,
            image
        )
        val blobId = Json.decodeFromString<ImageUploadResponse>(blobReq.bodyAsText()).encryptedBlobId
        innerTube.setThumbnailPlaylist(WEB_REMIX, playlistId, blobId).body<EditPlaylistResponse>().newHeader?.musicEditablePlaylistDetailHeaderRenderer?.header?.musicResponsiveHeaderRenderer?.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl()
    }

    suspend fun removeThumbnailPlaylist(playlistId: String) = runCatching {
        innerTube.removeThumbnailPlaylist(WEB_REMIX, playlistId).body<EditPlaylistResponse>().newHeader?.musicEditablePlaylistDetailHeaderRenderer?.header?.musicResponsiveHeaderRenderer?.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl()
    }

    suspend fun deletePlaylist(playlistId: String) = runCatching {
        innerTube.deletePlaylist(WEB_REMIX, playlistId)
    }

    suspend fun player(videoId: String, playlistId: String? = null, client: YouTubeClient, signatureTimestamp: Int? = null, poToken: String? = null): Result<PlayerResponse> = runCatching {
        innerTube.player(client, videoId, playlistId, signatureTimestamp, poToken).body<PlayerResponse>()
    }




    fun generateCpn(): String = (1..16).map {
        "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_"[Random.Default.nextInt(
            0,
            64
        )]
    }.joinToString("")

    suspend fun registerPlayback(
        url: String,
        playlistId: String? = null,
        cpn: String = generateCpn(),
        cmt: Float? = null,
        st: Float? = null,
        et: Float? = null,
        state: String? = null,
        client: YouTubeClient = WEB_REMIX,
    ) = runCatching {
        innerTube.registerPlayback(
            url = url,
            playlistId = playlistId,
            cpn = cpn,
            cmt = cmt,
            st = st,
            et = et,
            state = state,
            client = client
        )
    }

    suspend fun registerPlayback(playlistId: String? = null, playbackTracking: String) =
        registerPlayback(url = playbackTracking, playlistId = playlistId)

    suspend fun next(endpoint: WatchEndpoint, continuation: String? = null): Result<NextResult> = runCatching {
        val response = innerTube.next(
            WEB_REMIX,
            endpoint.videoId,
            endpoint.playlistId,
            endpoint.playlistSetVideoId,
            endpoint.index,
            endpoint.params,
            continuation).body<NextResponse>()
        val playlistPanelRenderer = response.continuationContents?.playlistPanelContinuation
            ?: response.contents.singleColumnMusicWatchNextResultsRenderer?.tabbedRenderer
                ?.watchNextTabbedResultsRenderer?.tabs?.firstOrNull()?.tabRenderer?.content?.musicQueueRenderer
                ?.content?.playlistPanelRenderer
            ?: throw IllegalStateException("playlistPanelRenderer not found in YouTube response")
        val title = response.contents.singleColumnMusicWatchNextResultsRenderer?.tabbedRenderer
            ?.watchNextTabbedResultsRenderer?.tabs?.get(0)?.tabRenderer?.content?.musicQueueRenderer
            ?.header?.musicQueueHeaderRenderer?.subtitle?.runs?.firstOrNull()?.text

        val chipsData = response.contents.singleColumnMusicWatchNextResultsRenderer?.tabbedRenderer
            ?.watchNextTabbedResultsRenderer?.tabs?.getOrNull(0)?.tabRenderer?.content?.musicQueueRenderer
            ?.subHeaderChipCloud?.chipCloudRenderer?.chips

        // Removed Chippy spam
        // println("Chippy: YouTube API parsed raw chipsData size: ${chipsData?.size}")

        var radioChips = chipsData?.mapNotNull { chip ->
            val renderer = chip.chipCloudChipRenderer ?: return@mapNotNull null
            val text = renderer.text?.runs?.firstOrNull()?.text ?: return@mapNotNull null
            val params = renderer.navigationEndpoint?.watchEndpoint?.params ?: ""
            RadioChip(
                title = text,
                params = params,
                isSelected = renderer.isSelected
            )
        } ?: emptyList()


        val items = playlistPanelRenderer.contents.mapNotNull { content ->
            content.playlistPanelVideoRenderer
                ?.let(NextPage::fromPlaylistPanelVideoRenderer)
                ?.let { it to content.playlistPanelVideoRenderer.selected }
        }
        val songs = items.map { it.first }
        val currentIndex = items.indexOfFirst { it.second }.takeIf { it != -1 }

        // load automix items
        playlistPanelRenderer.contents.lastOrNull()?.automixPreviewVideoRenderer?.content?.automixPlaylistVideoRenderer?.navigationEndpoint?.watchPlaylistEndpoint?.let { watchPlaylistEndpoint ->
            return@runCatching next(watchPlaylistEndpoint).getOrThrow().let { result ->
                result.copy(
                    title = title,
                    items = songs + result.items,
                    lyricsEndpoint = response.contents.singleColumnMusicWatchNextResultsRenderer?.tabbedRenderer?.watchNextTabbedResultsRenderer?.tabs?.getOrNull(1)?.tabRenderer?.endpoint?.browseEndpoint,
                    relatedEndpoint = response.contents.singleColumnMusicWatchNextResultsRenderer?.tabbedRenderer?.watchNextTabbedResultsRenderer?.tabs?.getOrNull(2)?.tabRenderer?.endpoint?.browseEndpoint,
                    currentIndex = currentIndex,
                    endpoint = watchPlaylistEndpoint,
                    radioChips = radioChips
                )
            }
        }
        NextResult(
            title = title,
            items = songs,
            currentIndex = currentIndex,
            lyricsEndpoint = response.contents.singleColumnMusicWatchNextResultsRenderer?.tabbedRenderer?.watchNextTabbedResultsRenderer?.tabs?.getOrNull(1)?.tabRenderer?.endpoint?.browseEndpoint,
            relatedEndpoint = response.contents.singleColumnMusicWatchNextResultsRenderer?.tabbedRenderer?.watchNextTabbedResultsRenderer?.tabs?.getOrNull(2)?.tabRenderer?.endpoint?.browseEndpoint,
            continuation = playlistPanelRenderer.continuations?.getContinuation(),
            endpoint = endpoint,
            radioChips = radioChips
        )
    }

    suspend fun lyrics(endpoint: BrowseEndpoint): Result<String?> = runCatching {
        // 1) Cliente Android de YouTube Music: trae la letra con tiempos por línea (si existe)
        val timedLyrics = runCatching {
            innerTube.browse(
                client = YouTubeClient.ANDROID_MUSIC,
                browseId = endpoint.browseId,
                params = endpoint.params,
                setLogin = true,
            ).body<BrowseResponse>()
        }.getOrNull()
            ?.contents?.elementRenderer?.newElement?.type?.componentType?.model
            ?.timedLyricsModel?.lyricsData?.timedLyricsData

        if (!timedLyrics.isNullOrEmpty()) {
            fun startMs(item: ElementRenderer.NewElement.ElementType.ComponentType.ElementModel.TimedLyricsModel.LyricsData.TimedLyricItem) =
                item.cueRange?.startTimeMilliseconds?.contentOrNull?.toLongOrNull()
            val formatted = if (timedLyrics.any { startMs(it) != null }) {
                timedLyrics.joinToString("\n") { item ->
                    val line = item.lyricLine.orEmpty()
                    val ms = startMs(item)
                    if (ms == null) {
                        line
                    } else {
                        String.format(
                            java.util.Locale.ROOT, "[%02d:%02d.%02d]%s",
                            ms / 60000, (ms / 1000) % 60, (ms % 1000) / 10,
                            if (line.isEmpty()) "" else " $line",
                        )
                    }
                }
            } else {
                timedLyrics.joinToString("\n") { it.lyricLine.orEmpty() }
            }
            if (formatted.isNotBlank()) return@runCatching formatted
        }

        // 2) Si no hay letra con tiempos: la letra normal de siempre (WEB_REMIX)
        val response = innerTube.browse(WEB_REMIX, endpoint.browseId, endpoint.params).body<BrowseResponse>()
        response.contents?.sectionListRenderer?.contents
            ?.firstOrNull { it.musicDescriptionShelfRenderer != null }
            ?.musicDescriptionShelfRenderer?.description?.runs
            ?.joinToString(separator = "") { it.text }
    }

    suspend fun related(endpoint: BrowseEndpoint): Result<RelatedPage> = runCatching {
        val response = innerTube.browse(WEB_REMIX, endpoint.browseId).body<BrowseResponse>()
        val songs = mutableListOf<SongItem>()
        val albums = mutableListOf<AlbumItem>()
        val artists = mutableListOf<ArtistItem>()
        val playlists = mutableListOf<PlaylistItem>()

        fun addItem(item: YTItem, renderer: MusicResponsiveListItemRenderer?) {
            when (item) {
                is SongItem -> songs.add(item)
                is AlbumItem -> albums.add(item)
                is ArtistItem -> artists.add(item)
                is PlaylistItem -> playlists.add(item)
            }
        }

        response.contents?.sectionListRenderer?.contents?.forEach { sectionContent ->
            // Music Carousel
            sectionContent.musicCarouselShelfRenderer?.contents?.forEach { content ->
                val item = content.musicResponsiveListItemRenderer?.let(RelatedPage.Companion::fromMusicResponsiveListItemRenderer)
                    ?: content.musicTwoRowItemRenderer?.let(RelatedPage.Companion::fromMusicTwoRowItemRenderer)
                if (item != null) {
                    addItem(item, content.musicResponsiveListItemRenderer)
                }
            }

            // Music Shelf
            sectionContent.musicShelfRenderer?.contents?.forEach { content ->
                val item = content.musicResponsiveListItemRenderer?.let(RelatedPage.Companion::fromMusicResponsiveListItemRenderer)
                if (item != null) {
                    addItem(item, content.musicResponsiveListItemRenderer)
                }
            }

            // Item Section
            sectionContent.itemSectionRenderer?.contents?.forEach { content ->
                val item = content.musicResponsiveListItemRenderer?.let(RelatedPage.Companion::fromMusicResponsiveListItemRenderer)
                if (item != null) {
                    addItem(item, content.musicResponsiveListItemRenderer)
                }
            }
        }
        RelatedPage(songs, albums, artists, playlists)
    }

    suspend fun queue(videoIds: List<String>? = null, playlistId: String? = null): Result<List<SongItem>> = runCatching {
        if (videoIds != null) {
            assert(videoIds.size <= MAX_GET_QUEUE_SIZE) // Max video limit
        }
        innerTube.getQueue(WEB_REMIX, videoIds, playlistId).body<GetQueueResponse>().queueDatas
            .mapNotNull {
                it.content.playlistPanelVideoRenderer?.let { renderer ->
                    NextPage.fromPlaylistPanelVideoRenderer(renderer)
                }
            }
    }

    suspend fun transcript(videoId: String): Result<String> = runCatching {
        val response = innerTube.getTranscript(WEB, videoId).body<GetTranscriptResponse>()
        response.actions?.firstOrNull()?.updateEngagementPanelAction?.content?.transcriptRenderer?.body?.transcriptBodyRenderer?.cueGroups?.joinToString(separator = "\n") { group ->
            val time = group.transcriptCueGroupRenderer.cues[0].transcriptCueRenderer.startOffsetMs
            val text = group.transcriptCueGroupRenderer.cues[0].transcriptCueRenderer.cue.simpleText
                .trim('♪')
                .trim(' ')
            "[%02d:%02d.%03d]$text".format(time / 60000, (time / 1000) % 60, time % 1000)
        }!!
    }

    suspend fun visitorData(): Result<String> = runCatching {
        Json.parseToJsonElement(innerTube.getSwJsData().bodyAsText().substring(5))
            .jsonArray[0]
            .jsonArray[2]
            .jsonArray.first {
                (it as? JsonPrimitive)?.contentOrNull?.let { candidate ->
                    VISITOR_DATA_REGEX.containsMatchIn(candidate)
                } ?: false
            }
            .jsonPrimitive.content
    }

    suspend fun accountInfo(): Result<AccountInfo> = runCatching {
        innerTube.accountMenu(WEB_REMIX).body<AccountMenuResponse>()
            .actions[0].openPopupAction.popup.multiPageMenuRenderer
            .header?.activeAccountHeaderRenderer
            ?.toAccountInfo()!!
    }

    suspend fun feedback(tokens: List<String>): Result<Boolean> = runCatching {
        innerTube.feedback(WEB_REMIX, tokens).body<FeedbackResponse>().feedbackResponses.all { it.isProcessed }
    }

    /**
     * Add a song to library by fetching fresh feedback tokens from the next endpoint
     * This is more reliable than using cached tokens which might be stale
     */
    suspend fun addSongToLibrary(videoId: String): Result<Boolean> = runCatching {
        // Get fresh song data with menu tokens using next endpoint
        val nextResult = next(WatchEndpoint(videoId = videoId)).getOrThrow()
        val song = nextResult.items.find { it.id == videoId }
            ?: throw Exception("Song not found in next response")
        
        val addToken = song.libraryAddToken
            ?: throw Exception("Add to library token not available")
        
        feedback(listOf(addToken)).getOrThrow()
    }

    /**
     * Remove a song from library by fetching fresh feedback tokens from the next endpoint
     */
    suspend fun removeSongFromLibrary(videoId: String): Result<Boolean> = runCatching {
        // Get fresh song data with menu tokens using next endpoint
        val nextResult = next(WatchEndpoint(videoId = videoId)).getOrThrow()
        val song = nextResult.items.find { it.id == videoId }
            ?: throw Exception("Song not found in next response")
        
        val removeToken = song.libraryRemoveToken
            ?: throw Exception("Remove from library token not available")
        
        feedback(listOf(removeToken)).getOrThrow()
    }

    /**
     * Toggle song library status - adds if not in library, removes if in library
     * Uses fresh tokens fetched from the API for reliability
     */
    suspend fun toggleSongLibrary(videoId: String, addToLibrary: Boolean): Result<Boolean> = runCatching {
        if (addToLibrary) {
            addSongToLibrary(videoId).getOrThrow()
        } else {
            removeSongFromLibrary(videoId).getOrThrow()
        }
    }

    suspend fun getMediaInfo(videoId: String): Result<MediaInfo> = runCatching {
        return innerTube.getMediaInfo(videoId)
    }

    @JvmInline
    value class SearchFilter(val value: String) {
        companion object {
            val FILTER_SONG = SearchFilter("EgWKAQIIAWoKEAkQBRAKEAMQBA%3D%3D")
            val FILTER_VIDEO = SearchFilter("EgWKAQIQAWoKEAkQChAFEAMQBA%3D%3D")
            val FILTER_ALBUM = SearchFilter("EgWKAQIYAWoKEAkQChAFEAMQBA%3D%3D")
            val FILTER_ARTIST = SearchFilter("EgWKAQIgAWoKEAkQChAFEAMQBA%3D%3D")
            val FILTER_FEATURED_PLAYLIST = SearchFilter("EgeKAQQoADgBagwQDhAKEAMQBRAJEAQ%3D")
            val FILTER_COMMUNITY_PLAYLIST = SearchFilter("EgeKAQQoAEABagoQAxAEEAoQCRAF")
        }
    }

    @JvmInline
    value class LibraryFilter(val value: String) {
        companion object {
            val FILTER_RECENT_ACTIVITY = LibraryFilter("4qmFsgIrEhdGRW11c2ljX2xpYnJhcnlfbGFuZGluZxoQZ2dNR0tnUUlCaEFCb0FZQg%3D%3D")
            val FILTER_RECENTLY_PLAYED = LibraryFilter("4qmFsgIrEhdGRW11c2ljX2xpYnJhcnlfbGFuZGluZxoQZ2dNR0tnUUlCUkFCb0FZQg%3D%3D")
            val FILTER_PLAYLISTS_ALPHABETICAL = LibraryFilter("4qmFsgIrEhdGRW11c2ljX2xpa2VkX3BsYXlsaXN0cxoQZ2dNR0tnUUlBUkFBb0FZQg%3D%3D")
            val FILTER_PLAYLISTS_RECENTLY_SAVED = LibraryFilter("4qmFsgIrEhdGRW11c2ljX2xpa2VkX3BsYXlsaXN0cxoQZ2dNR0tnUUlBQkFCb0FZQg%3D%3D")
        }
    }

    const val MAX_GET_QUEUE_SIZE = 1000

    private val VISITOR_DATA_REGEX = Regex("^Cg[t|s]")

    fun getNewPipeStreamUrls(videoId: String): List<Pair<Int, String>> {
        return NewPipeExtractor.newPipePlayer(videoId)
    }

    suspend fun newPipePlayer(
        videoId: String,
        tempRes: PlayerResponse,
    ): PlayerResponse? {
        if (tempRes.playabilityStatus.status != "OK") {
            return null
        }

        val streamsList = getNewPipeStreamUrls(videoId)
        if (streamsList.isEmpty()) return null

        val decodedSigResponse = tempRes.copy(
            streamingData = tempRes.streamingData?.copy(
                formats = tempRes.streamingData.formats?.map { format ->
                    format.copy(
                        url = streamsList.find { it.first == format.itag }?.second ?: format.url,
                    )
                },
                adaptiveFormats = tempRes.streamingData.adaptiveFormats.map { adaptiveFormat ->
                    adaptiveFormat.copy(
                        url = streamsList.find { it.first == adaptiveFormat.itag }?.second ?: adaptiveFormat.url,
                    )
                },
            ),
        )

        val urlList = (
            decodedSigResponse.streamingData?.adaptiveFormats?.mapNotNull { it.url }?.toMutableList() ?: mutableListOf()
        ).apply {
            decodedSigResponse.streamingData?.formats?.mapNotNull { it.url }?.let { addAll(it) }
        }

        return if (urlList.isNotEmpty()) {
            decodedSigResponse
        } else {
            null
        }
    }

    data class CommentsResult(
        val comments: List<CommentThreadRenderer>,
        val nextToken: String?,
        val totalComments: String? = null,
        val topToken: String? = null,
        val newestToken: String? = null,
    )

    fun createCommentsContinuationToken(videoId: String, sortBy: Int = 0): String {
        val vidBytes = videoId.toByteArray(Charsets.UTF_8)
        val vidLen = vidBytes.size.toByte()

        val part1 = byteArrayOf(0x12, (2 + vidBytes.size).toByte(), 0x12, vidLen) +
                vidBytes +
                byteArrayOf(0x18, 0x06)

        val secBytes = "comments-section".toByteArray(Charsets.UTF_8)
        val f4 = byteArrayOf(0x22, (2 + vidBytes.size + 4).toByte(), 0x22, vidLen) +
                vidBytes +
                byteArrayOf(0x30, sortBy.toByte(), 0x78, 0x02)
        val f8 = byteArrayOf(0x42, secBytes.size.toByte()) + secBytes
        val f6Content = f4 + f8
        val part2 = byteArrayOf(0x32, f6Content.size.toByte()) + f6Content

        val proto = part1 + part2
        return java.util.Base64.getEncoder().encodeToString(proto)
    }

    suspend fun comments(videoId: String): Result<CommentsResult> = runCatching {
        // Fast path: Attempt direct continuation using synthesized protobuf token.
        // This eliminates the heavy ~450KB watch-next round trip and speeds up comment load by 70-80%.
        try {
            val directToken = createCommentsContinuationToken(videoId)
            val directResult = commentContinuation(directToken).getOrNull()
            if (directResult != null && (directResult.comments.isNotEmpty() || directResult.totalComments != null)) {
                return@runCatching directResult
            }
        } catch (e: Exception) {
            android.util.Log.w("YouTubeComments", "Direct comment continuation failed for $videoId, falling back to watch-next lookup", e)
        }

        val response = innerTube.next(YouTubeClient.WEB, videoId, null, null, null, null, null).body<NextResponse>()
        
        // Find comment continuation token from engagementPanels (Primary location for YouTube Music/some WEB videos)
        val commentsPanel = response.engagementPanels?.firstOrNull { 
            it.engagementPanelSectionListRenderer?.panelIdentifier == "engagement-panel-comments-section"
        }
        val tokenFromEngagementPanels = commentsPanel?.engagementPanelSectionListRenderer?.content?.sectionListRenderer?.contents
            ?.mapNotNull { it.itemSectionRenderer }
            ?.flatMap { it.contents.orEmpty() }
            ?.mapNotNull { it?.continuationItemRenderer }
            ?.firstOrNull()?.continuationEndpoint?.continuationCommand?.token


        val contentList = response.contents.twoColumnWatchNextResults?.results?.results?.content

        // We MUST prioritize the standard WEB comment section tokenizer to unlock nested replies!
        // Engagement panels are tailored for YouTube Music which natively disables nested replies.
        val token =
            // Path 1: direct continuationItemRenderer in the content list
            contentList?.mapNotNull { it?.continuationItemRenderer }
                ?.firstOrNull()
                ?.continuationEndpoint?.continuationCommand?.token
            // Path 2: fallback — inside an itemSectionRenderer's contents
                ?: contentList?.mapNotNull { it?.itemSectionRenderer }
                    ?.flatMap { it.contents.orEmpty() }
                    ?.mapNotNull { it?.continuationItemRenderer }
                    ?.firstOrNull()
                    ?.continuationEndpoint?.continuationCommand?.token
            // Path 3: Fallback strictly to engagement panels only if WEB fails
                ?: tokenFromEngagementPanels
                ?: throw Exception("No comment continuation token found for videoId=$videoId")


        commentContinuation(token).getOrThrow()
    }

    private val commentJson = Json {
        ignoreUnknownKeys = true
        explicitNulls = false
        encodeDefaults = true
        isLenient = true
        coerceInputValues = true
    }

    private fun extractActionTokensByCommentId(rawText: String): Map<String, String> {
        val actionRegex = Regex(""""performCommentActionEndpoint"\s*:\s*\{\s*"action"\s*:\s*"([^"]+)"""")
        val tokensByCommentId = mutableMapOf<String, String>()

        actionRegex.findAll(rawText).forEach { matchResult ->
            val token = matchResult.groupValues[1]
            try {
                val urlDecoded = java.net.URLDecoder.decode(token, "UTF-8")
                val decodedBytes = android.util.Base64.decode(urlDecoded, android.util.Base64.DEFAULT)
                val decodedString = String(decodedBytes, java.nio.charset.StandardCharsets.ISO_8859_1)

                val idMatch = Regex("""(Ug[a-zA-Z0-9_-]{24,})""").find(decodedString)
                if (idMatch != null) {
                    val foundId = idMatch.groupValues[1]
                    tokensByCommentId[foundId] = token
                    android.util.Log.d("YouTubeComments", "Mapped action token directly from raw payload for commentId=$foundId")
                }
            } catch (e: Exception) {
                android.util.Log.w("YouTubeComments", "Failed to decode action token: $e")
            }
        }

        if (tokensByCommentId.isEmpty()) {
            actionRegex.findAll(rawText).forEach { matchResult ->
                val token = matchResult.groupValues[1]
                val start = maxOf(0, matchResult.range.first - 1000)
                val end = minOf(rawText.length, matchResult.range.last + 1000)
                val window = rawText.substring(start, end)
                val idMatch = Regex("""(Ug[a-zA-Z0-9_-]{24,})""").find(window)
                if (idMatch != null) {
                    val foundId = idMatch.groupValues[1]
                    tokensByCommentId[foundId] = token
                    android.util.Log.d("YouTubeComments", "Mapped action token from raw window for commentId=$foundId")
                }
            }
        }
        return tokensByCommentId
    }

    private fun createSyntheticActionMenu(actionToken: String): com.music.innertube.models.comment.CommentRenderer.ActionMenu {
        return com.music.innertube.models.comment.CommentRenderer.ActionMenu(
            menuRenderer = com.music.innertube.models.comment.CommentRenderer.ActionMenu.MenuRenderer(
                items = listOf(
                    com.music.innertube.models.comment.CommentRenderer.ActionMenu.MenuRenderer.Item(
                        menuServiceItemRenderer = com.music.innertube.models.comment.CommentRenderer.ActionMenu.MenuRenderer.Item.MenuServiceItemRenderer(
                            text = com.music.innertube.models.Runs(runs = listOf(com.music.innertube.models.Run(text = "Delete", navigationEndpoint = null))),
                            serviceEndpoint = com.music.innertube.models.comment.CommentRenderer.ActionMenu.MenuRenderer.Item.MenuServiceItemRenderer.ServiceEndpoint(
                                performCommentActionEndpoint = com.music.innertube.models.comment.CommentRenderer.ActionMenu.MenuRenderer.Item.MenuServiceItemRenderer.ServiceEndpoint.PerformCommentActionEndpoint(
                                    action = actionToken
                                )
                            )
                        )
                    )
                )
            )
        )
    }

    fun buildDeleteActionToken(commentId: String, videoId: String = ""): String {
        val baos = java.io.ByteArrayOutputStream()
        baos.write(0x08); baos.write(0x05)
        baos.write(0x10); baos.write(0x01)
        baos.write(0x1a)
        val cidBytes = commentId.toByteArray(Charsets.UTF_8)
        baos.write(cidBytes.size)
        baos.write(cidBytes)
        if (videoId.isNotBlank()) {
            baos.write(0x2a)
            val vidBytes = videoId.toByteArray(Charsets.UTF_8)
            baos.write(vidBytes.size)
            baos.write(vidBytes)
        }
        baos.write(byteArrayOf(0x30, 0x00, 0x38, 0x00, 0xf0.toByte(), 0x01, 0x00, 0xf8.toByte(), 0x02, 0x01, 0xb0.toByte(), 0x03, 0x00, 0xc0.toByte(), 0x03, 0x02, 0xc8.toByte(), 0x03, 0x00))
        val b64 = android.util.Base64.encodeToString(baos.toByteArray(), android.util.Base64.NO_WRAP)
        return java.net.URLEncoder.encode(b64, "UTF-8")
    }

    fun buildReplyParams(videoId: String, commentId: String): String {
        val vidBytes = videoId.toByteArray(Charsets.UTF_8)
        val cidBytes = commentId.toByteArray(Charsets.UTF_8)
        val buffer = java.io.ByteArrayOutputStream()
        // Field 2 (tag 0x12): videoId
        buffer.write(0x12)
        buffer.write(vidBytes.size)
        buffer.write(vidBytes)
        // Field 4 (tag 0x22): commentId
        buffer.write(0x22)
        buffer.write(cidBytes.size)
        buffer.write(cidBytes)
        return java.util.Base64.getUrlEncoder().withoutPadding().encodeToString(buffer.toByteArray())
    }

    suspend fun commentContinuation(continuationToken: String): Result<CommentsResult> = runCatching {
        val httpResponse = innerTube.next(YouTubeClient.WEB, null, null, null, null, null, continuationToken)
        val rawText = httpResponse.bodyAsText()
        val response = commentJson.decodeFromString<CommentResponse>(rawText)
        val tokensByCommentId = extractActionTokensByCommentId(rawText)

        val actionIdx = rawText.indexOf("performCommentActionEndpoint")
        if (actionIdx != -1) {
            val snippet = rawText.substring(maxOf(0, actionIdx - 150), minOf(rawText.length, actionIdx + 250))
            android.util.Log.d("YouTubeComments", "RAW JSON found performCommentActionEndpoint: $snippet")
        } else {
            val deleteIdx = rawText.indexOf("\"delete\"")
            if (deleteIdx != -1) {
                val snippet = rawText.substring(maxOf(0, deleteIdx - 100), minOf(rawText.length, deleteIdx + 200))
                android.util.Log.d("YouTubeComments", "RAW JSON: performCommentActionEndpoint not found, but found 'delete': $snippet")
            } else {
                android.util.Log.d("YouTubeComments", "RAW JSON: Neither performCommentActionEndpoint nor 'delete' found in response length=${rawText.length}")
            }
        }

        val endpoints = response.onResponseReceivedEndpoints.orEmpty()
        val continuationItems = endpoints.flatMap { endpoint ->
            endpoint.reloadContinuationItemsCommand?.continuationItems.orEmpty() +
            endpoint.appendContinuationItemsAction?.continuationItems.orEmpty()
        }

        val header = continuationItems.mapNotNull { it.commentsHeaderRenderer }.firstOrNull()
        val totalComments = header?.countText?.runs?.joinToString("") { it.text.orEmpty() }?.takeIf { it.isNotBlank() }
        val subMenuItems = header?.sortMenu?.sortFilterSubMenuRenderer?.subMenuItems.orEmpty()
        val topToken = subMenuItems.firstOrNull { it.title?.contains("Top", ignoreCase = true) == true }?.let {
            it.continuation?.reloadContinuationItemsCommand?.token ?: it.serviceEndpoint?.continuationCommand?.token
        }
        val newestToken = subMenuItems.firstOrNull { it.title?.contains("New", ignoreCase = true) == true }?.let {
            it.continuation?.reloadContinuationItemsCommand?.token ?: it.serviceEndpoint?.continuationCommand?.token
        }

        // 1. Extract Legacy comments & ViewModels to map menus and action buttons
        val legacyThreads = continuationItems.mapNotNull { it.commentThreadRenderer }
        val legacyCommentsMap = legacyThreads.associateBy { thread ->
            thread.comment?.commentRenderer?.commentId 
                ?: thread.commentViewModel?.commentViewModel?.commentId
                ?: "legacy-${thread.hashCode()}"
        }

        val menusByCommentId = mutableMapOf<String, com.music.innertube.models.comment.CommentRenderer.ActionMenu>()
        val actionButtonsByCommentId = mutableMapOf<String, com.music.innertube.models.comment.CommentRenderer.ActionButtons>()

        continuationItems.forEach { item ->
            item.commentThreadRenderer?.let { thread ->
                val id = thread.comment?.commentRenderer?.commentId
                    ?: thread.commentViewModel?.commentViewModel?.commentId
                val menu = thread.comment?.commentRenderer?.actionMenu
                    ?: thread.commentViewModel?.commentViewModel?.actionMenu
                    ?: thread.commentViewModel?.commentViewModel?.menu
                    ?: thread.menu
                    ?: thread.actionMenu
                val buttons = thread.comment?.commentRenderer?.actionButtons
                    ?: thread.commentViewModel?.commentViewModel?.actionButtons
                    ?: thread.actionButtons
                if (id != null) {
                    if (menu != null) menusByCommentId[id] = menu
                    if (buttons != null) actionButtonsByCommentId[id] = buttons
                }
            }
            item.commentViewModel?.let { vm ->
                val id = vm.commentId
                val menu = vm.actionMenu ?: vm.menu
                val buttons = vm.actionButtons
                if (id != null) {
                    if (menu != null) menusByCommentId[id] = menu
                    if (buttons != null) actionButtonsByCommentId[id] = buttons
                }
            }
            item.commentRenderer?.let { cr ->
                val id = cr.commentId
                val menu = cr.actionMenu
                val buttons = cr.actionButtons
                if (id != null) {
                    if (menu != null) menusByCommentId[id] = menu
                    if (buttons != null) actionButtonsByCommentId[id] = buttons
                }
            }
        }

        android.util.Log.d("YouTubeComments", "Parsed ${legacyThreads.size} threads. Found ${menusByCommentId.size} menus and ${actionButtonsByCommentId.size} action buttons maps.")
        if (menusByCommentId.isEmpty() && legacyThreads.isNotEmpty()) {
            val sampleThread = legacyThreads.firstOrNull()
            android.util.Log.d("YouTubeComments", "Thread 0 diagnostics: hasComment=${sampleThread?.comment != null}, hasVM=${sampleThread?.commentViewModel != null}, hasReplies=${sampleThread?.replies != null}, menu=${sampleThread?.menu != null}, actionMenu=${sampleThread?.actionMenu != null}")
        }

        // 2. Extract Framework-based comments
        val mutations = response.frameworkUpdates?.entityBatchUpdate?.mutations.orEmpty()
        val toolbarMap = mutations.mapNotNull { it.payload?.engagementToolbarStateEntityPayload }.associateBy { it.key }
        val surfaceMap = mutations.mapNotNull { it.payload?.engagementToolbarSurfaceEntityPayload }.associateBy { it.key }

        val commentsFromFramework = mutations.mapNotNull { mutation ->
            mutation.payload?.commentEntityPayload?.let { payload ->
                val toolbarKey = payload.properties?.toolbarStateKey
                val surfaceKey = payload.properties?.toolbarSurfaceKey
                val toolbarState = toolbarMap[toolbarKey]
                val surface = surfaceMap[surfaceKey]
                val likeCount = payload.toolbar?.likeCountNotliked
                    ?: surface?.toolbar?.likeCountNotliked
                    ?: "0"
                val replyCount = payload.toolbar?.replyCount
                    ?: surface?.toolbar?.replyCount
                    ?: "0"
                    
                val commentId = payload.properties?.commentId ?: "framework-${mutation.hashCode()}"
                val legacyMatch = legacyCommentsMap[commentId]
                val resolvedMenu = menusByCommentId[commentId]
                    ?: legacyMatch?.comment?.commentRenderer?.actionMenu
                    ?: legacyMatch?.commentViewModel?.commentViewModel?.actionMenu
                    ?: legacyMatch?.commentViewModel?.commentViewModel?.menu
                    ?: legacyMatch?.menu
                    ?: legacyMatch?.actionMenu
                val resolvedButtons = actionButtonsByCommentId[commentId]
                    ?: legacyMatch?.comment?.commentRenderer?.actionButtons
                    ?: legacyMatch?.commentViewModel?.commentViewModel?.actionButtons
                    ?: legacyMatch?.actionButtons

                val hasDeleteAction = resolvedMenu?.getDeleteActionToken() != null ||
                    resolvedButtons?.commentActionButtonsRenderer?.deleteButton != null
                val isAuthor = legacyMatch?.comment?.commentRenderer?.isAuthor == true ||
                    payload.author?.isCurrentUser == true ||
                    hasDeleteAction

                val finalMenu = resolvedMenu ?: if (isAuthor) {
                    val rawActionToken = tokensByCommentId[commentId] ?: buildDeleteActionToken(commentId)
                    createSyntheticActionMenu(rawActionToken)
                } else null

                android.util.Log.d("YouTubeComments", "Framework commentId=$commentId: resolvedMenu=${resolvedMenu != null}, hasDeleteAction=${finalMenu?.getDeleteActionToken() != null}, isAuthor=$isAuthor, deleteToken=${finalMenu?.getDeleteActionToken() ?: resolvedButtons?.commentActionButtonsRenderer?.deleteButton?.buttonRenderer?.serviceEndpoint?.performCommentActionEndpoint?.action}")

                CommentThreadRenderer(
                    comment = CommentThreadRenderer.Comment(
                        commentRenderer = com.music.innertube.models.comment.CommentRenderer(
                            authorText = com.music.innertube.models.Runs(
                                runs = listOf(com.music.innertube.models.Run(text = payload.author?.displayName ?: "Unknown", navigationEndpoint = null))
                            ),
                            authorThumbnail = com.music.innertube.models.Thumbnails(
                                thumbnails = listOf(com.music.innertube.models.Thumbnail(url = payload.author?.avatarThumbnailUrl ?: "", width = 0, height = 0))
                            ),
                            contentText = com.music.innertube.models.Runs(
                                runs = listOf(com.music.innertube.models.Run(text = payload.properties?.content?.content ?: "", navigationEndpoint = null))
                            ),
                            publishedTimeText = com.music.innertube.models.Runs(
                                runs = listOf(com.music.innertube.models.Run(text = payload.properties?.publishedTime ?: "", navigationEndpoint = null))
                            ),
                            commentId = commentId,
                            voteCount = com.music.innertube.models.Runs(
                                runs = listOf(com.music.innertube.models.Run(text = likeCount, navigationEndpoint = null))
                            ),
                            voteStatus = when (toolbarState?.likeState) {
                                "TOOLBAR_LIKE_STATE_LIKE" -> "UPVOTE"
                                "TOOLBAR_LIKE_STATE_INDIFFERENT" -> "INDIFFERENT"
                                else -> "INDIFFERENT"
                            },
                            replyCount = replyCount.toIntOrNull() ?: 0,
                            actionButtons = resolvedButtons,
                            actionMenu = finalMenu,
                            isAuthor = isAuthor
                        )
                    ),
                    replies = legacyMatch?.replies
                )
            }
        }

        // 3. Extract Next Token (Exhaustive Search)
        val nextToken = continuationItems.mapNotNull { item ->
            item.continuationItemRenderer?.let { renderer ->
                renderer.continuationEndpoint?.continuationCommand?.token
                    ?: renderer.button?.buttonRenderer?.command?.let { null }
                    ?: renderer.button?.buttonRenderer?.navigationEndpoint?.let { null }
            }
        }.firstOrNull()
            ?: endpoints.mapNotNull { endpoint ->
                endpoint.appendContinuationItemsAction?.continuationItems?.mapNotNull { it.continuationItemRenderer?.continuationEndpoint?.continuationCommand?.token }
            }.flatten().firstOrNull()
        
        // Merge Legacy and Framework comments
        val frameworkCommentsMap = commentsFromFramework.associateBy { it.comment?.commentRenderer?.commentId }
        val allIds = (legacyCommentsMap.keys + frameworkCommentsMap.keys).filterNotNull().distinct()

        val comments = allIds.mapNotNull { id ->
            val legacy = legacyCommentsMap[id]
            val modern = frameworkCommentsMap[id]

            // Always prioritize the modern framework model because YouTube migrated text content exclusively to it.
            // We've already injected `legacy.replies` into `modern` above.
            if (modern != null) {
                modern
            } else {
                legacy
            }
        }.distinctBy { it.comment?.commentRenderer?.commentId ?: it.hashCode() }
        

        CommentsResult(
            comments = comments,
            nextToken = nextToken,
            totalComments = totalComments,
            topToken = topToken,
            newestToken = newestToken
        )
    }

    suspend fun commentReplies(replyToken: String): Result<Pair<List<com.music.innertube.models.comment.CommentRenderer>, String?>> = runCatching {
        val httpResponse = innerTube.next(YouTubeClient.WEB, null, null, null, null, null, replyToken)
        val rawText = httpResponse.bodyAsText()
        val response = commentJson.decodeFromString<CommentResponse>(rawText)
        val replyTokensByCommentId = extractActionTokensByCommentId(rawText)
        
        val endpoints = response.onResponseReceivedEndpoints.orEmpty()
        val continuationItems = endpoints.flatMap { endpoint ->
            endpoint.reloadContinuationItemsCommand?.continuationItems.orEmpty() +
            endpoint.appendContinuationItemsAction?.continuationItems.orEmpty()
        }

        // 1. Extract Legacy replies & menus
        val legacyReplies = continuationItems.mapNotNull { it.commentRenderer ?: it.commentThreadRenderer?.comment?.commentRenderer }
        val replyMenusByCommentId = mutableMapOf<String, com.music.innertube.models.comment.CommentRenderer.ActionMenu>()
        val replyActionButtonsByCommentId = mutableMapOf<String, com.music.innertube.models.comment.CommentRenderer.ActionButtons>()

        continuationItems.forEach { item ->
            item.commentThreadRenderer?.let { thread ->
                val id = thread.comment?.commentRenderer?.commentId
                    ?: thread.commentViewModel?.commentViewModel?.commentId
                val menu = thread.comment?.commentRenderer?.actionMenu
                    ?: thread.commentViewModel?.commentViewModel?.actionMenu
                    ?: thread.commentViewModel?.commentViewModel?.menu
                    ?: thread.menu
                    ?: thread.actionMenu
                val buttons = thread.comment?.commentRenderer?.actionButtons
                    ?: thread.commentViewModel?.commentViewModel?.actionButtons
                    ?: thread.actionButtons
                if (id != null) {
                    if (menu != null) replyMenusByCommentId[id] = menu
                    if (buttons != null) replyActionButtonsByCommentId[id] = buttons
                }
            }
            item.commentViewModel?.let { vm ->
                val id = vm.commentId
                val menu = vm.actionMenu ?: vm.menu
                val buttons = vm.actionButtons
                if (id != null) {
                    if (menu != null) replyMenusByCommentId[id] = menu
                    if (buttons != null) replyActionButtonsByCommentId[id] = buttons
                }
            }
            item.commentRenderer?.let { cr ->
                val id = cr.commentId
                val menu = cr.actionMenu
                val buttons = cr.actionButtons
                if (id != null) {
                    if (menu != null) replyMenusByCommentId[id] = menu
                    if (buttons != null) replyActionButtonsByCommentId[id] = buttons
                }
            }
        }

        // 2. Extract Framework-based replies
        val mutations = response.frameworkUpdates?.entityBatchUpdate?.mutations.orEmpty()
        
        val toolbarMap = mutations.mapNotNull { it.payload?.engagementToolbarStateEntityPayload }.associateBy { it.key }
        val surfaceMap = mutations.mapNotNull { it.payload?.engagementToolbarSurfaceEntityPayload }.associateBy { it.key }

        val frameworkReplies = mutations.mapNotNull { mutation ->
            mutation.payload?.commentEntityPayload?.let { payload ->
                val toolbarKey = payload.properties?.toolbarStateKey
                val surfaceKey = payload.properties?.toolbarSurfaceKey
                val toolbarState = toolbarMap[toolbarKey]
                val surface = surfaceMap[surfaceKey]
                val likeCount = payload.toolbar?.likeCountNotliked
                    ?: surface?.toolbar?.likeCountNotliked
                    ?: "0"

                val replyId = payload.properties?.commentId ?: "reply-${mutation.hashCode()}"
                val resolvedMenu = replyMenusByCommentId[replyId]
                val resolvedButtons = replyActionButtonsByCommentId[replyId]
                val hasDeleteAction = resolvedMenu?.getDeleteActionToken() != null ||
                    resolvedButtons?.commentActionButtonsRenderer?.deleteButton != null
                val isAuthor = payload.author?.isCurrentUser == true ||
                    legacyReplies.find { it.commentId == replyId }?.isAuthor == true ||
                    hasDeleteAction

                val finalMenu = resolvedMenu ?: if (isAuthor) {
                    val rawActionToken = replyTokensByCommentId[replyId] ?: buildDeleteActionToken(replyId)
                    createSyntheticActionMenu(rawActionToken)
                } else null

                com.music.innertube.models.comment.CommentRenderer(
                    authorText = com.music.innertube.models.Runs(
                        runs = listOf(com.music.innertube.models.Run(text = payload.author?.displayName ?: "Unknown", navigationEndpoint = null))
                    ),
                    authorThumbnail = com.music.innertube.models.Thumbnails(
                        thumbnails = listOf(com.music.innertube.models.Thumbnail(url = payload.author?.avatarThumbnailUrl ?: "", width = 0, height = 0))
                    ),
                    contentText = com.music.innertube.models.Runs(
                        runs = listOf(com.music.innertube.models.Run(text = payload.properties?.content?.content ?: "", navigationEndpoint = null))
                    ),
                    publishedTimeText = com.music.innertube.models.Runs(
                        runs = listOf(com.music.innertube.models.Run(text = payload.properties?.publishedTime ?: "", navigationEndpoint = null))
                    ),
                    commentId = replyId,
                    voteCount = com.music.innertube.models.Runs(
                        runs = listOf(com.music.innertube.models.Run(text = likeCount, navigationEndpoint = null))
                    ),
                    voteStatus = when (toolbarState?.likeState) {
                        "TOOLBAR_LIKE_STATE_LIKE" -> "UPVOTE"
                        "TOOLBAR_LIKE_STATE_INDIFFERENT" -> "INDIFFERENT"
                        else -> "INDIFFERENT"
                    },
                    actionMenu = finalMenu,
                    actionButtons = resolvedButtons,
                    isAuthor = isAuthor
                )
            }
        }

        val allRepliesMap = legacyReplies.associateBy { it.commentId }
        val allFrameworkRepliesMap = frameworkReplies.associateBy { it.commentId }
        val allIds = (allRepliesMap.keys + allFrameworkRepliesMap.keys).filterNotNull().distinct()

        val mergedReplies = allIds.mapNotNull { id ->
            val legacy = allRepliesMap[id]
            val modern = allFrameworkRepliesMap[id]

            if (legacy != null && modern != null) {
                legacy.copy(
                    voteCount = modern.voteCount ?: legacy.voteCount,
                    voteStatus = modern.voteStatus ?: legacy.voteStatus,
                    replyCount = modern.replyCount ?: legacy.replyCount,
                    actionMenu = modern.actionMenu ?: legacy.actionMenu ?: replyMenusByCommentId[id],
                    actionButtons = modern.actionButtons ?: legacy.actionButtons ?: replyActionButtonsByCommentId[id],
                    isAuthor = modern.isAuthor || legacy.isAuthor
                )
            } else {
                val single = modern ?: legacy
                val menu = replyMenusByCommentId[id] ?: single?.actionMenu
                val buttons = replyActionButtonsByCommentId[id] ?: single?.actionButtons
                val hasDelete = menu?.getDeleteActionToken() != null || buttons?.commentActionButtonsRenderer?.deleteButton != null
                single?.copy(
                    actionMenu = menu,
                    actionButtons = buttons,
                    isAuthor = single.isAuthor || hasDelete
                )
            }
        }.distinctBy { it.commentId ?: it.hashCode() }
        
        // 3. Extract Next Token (Exhaustive Search for Replies)
        val nextToken = continuationItems.mapNotNull { item ->
            item.continuationItemRenderer?.let { renderer ->
                renderer.continuationEndpoint?.continuationCommand?.token
                    ?: renderer.button?.buttonRenderer?.command?.continuationCommand?.token
                    ?: renderer.button?.buttonRenderer?.navigationEndpoint?.continuationCommand?.token
            }
        }.firstOrNull()
            ?: endpoints.mapNotNull { endpoint ->
                endpoint.appendContinuationItemsAction?.continuationItems?.mapNotNull { it.continuationItemRenderer?.continuationEndpoint?.continuationCommand?.token }
            }.flatten().firstOrNull()

        Pair(mergedReplies, nextToken)
    }

    suspend fun createComment(
        videoId: String,
        commentText: String,
        createCommentParams: String? = null,
    ): Result<Boolean> = runCatching {
        val params = createCommentParams ?: run {
            val videoBytes = videoId.toByteArray(Charsets.UTF_8)
            val buffer = java.io.ByteArrayOutputStream()
            buffer.write(0x12)
            buffer.write(videoBytes.size)
            buffer.write(videoBytes)
            java.util.Base64.getUrlEncoder().withoutPadding().encodeToString(buffer.toByteArray())
        }
        val response = innerTube.createComment(
            client = YouTubeClient.WEB_REMIX,
            commentText = commentText,
            createCommentParams = params
        )
        val bodyText = response.bodyAsText()
        android.util.Log.d("CommentCreate", "createComment response status=${response.status.value}, body=${bodyText.take(500)}")
        response.status.value in 200..299
    }

    suspend fun createCommentReply(
        commentText: String,
        createReplyParams: String? = null,
        videoId: String? = null,
        commentId: String? = null,
    ): Result<Boolean> = runCatching {
        val params = createReplyParams ?: run {
            require(!videoId.isNullOrBlank() && !commentId.isNullOrBlank()) {
                "Either createReplyParams or both videoId and commentId must be provided"
            }
            buildReplyParams(videoId, commentId)
        }
        val response = innerTube.createCommentReply(
            client = YouTubeClient.WEB_REMIX,
            commentText = commentText,
            createReplyParams = params
        )
        val bodyText = response.bodyAsText()
        android.util.Log.d("CommentCreate", "createCommentReply response status=${response.status.value}, body=${bodyText.take(500)}")
        response.status.value in 200..299
    }

    suspend fun deleteComment(
        actionToken: String,
    ): Result<Boolean> = runCatching {
        android.util.Log.d("CommentDelete", "deleteComment() dispatching with token length: ${actionToken.length}")
        val response = innerTube.performCommentAction(
            client = YouTubeClient.WEB,
            action = actionToken
        )
        val bodyText = response.bodyAsText()
        android.util.Log.d("CommentDelete", "deleteComment() response code: ${response.status.value}, body: $bodyText")
        response.status.value in 200..299
    }
}

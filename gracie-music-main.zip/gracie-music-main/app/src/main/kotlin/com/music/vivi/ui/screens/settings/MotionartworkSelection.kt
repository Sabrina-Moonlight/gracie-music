/**
 * vivimusic Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.music.vivi.ui.screens.settings

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import com.music.vivi.ui.component.AnimatedRadioButton

import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarScrollBehavior
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.music.vivi.LocalPlayerAwareWindowInsets
import com.music.vivi.R
import com.music.vivi.constants.CanvasLoadOnlyWifiKey
import com.music.vivi.constants.MotionartworkSource
import com.music.vivi.constants.MotionartworkSourceKey
import com.music.vivi.constants.CanvasThumbnailAnimationKey
import com.music.vivi.ui.component.IconButton
import com.music.vivi.ui.component.ExpressiveSettingGroup
import com.music.vivi.ui.component.Material3SettingsItem
import com.music.vivi.ui.component.ModernSwitch
import com.music.vivi.ui.utils.backToMain
import com.music.vivi.utils.rememberEnumPreference
import com.music.vivi.utils.rememberPreference

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MotionartworkSelection(
    navController: NavController,
    scrollBehavior: TopAppBarScrollBehavior,
) {
    val (canvasThumbnailAnimation, onCanvasThumbnailAnimationChange) = rememberPreference(
        CanvasThumbnailAnimationKey,
        defaultValue = true
    )
    val (canvasLoadOnlyWifi, onCanvasLoadOnlyWifiChange) = rememberPreference(
        CanvasLoadOnlyWifiKey,
        defaultValue = false
    )
    val (motionartworkSource, onMotionartworkSourceChange) = rememberEnumPreference(
        MotionartworkSourceKey,
        defaultValue = MotionartworkSource.AUTO
    )

    Column(
        Modifier
            .windowInsetsPadding(LocalPlayerAwareWindowInsets.current)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {

        // Description text
        Text(
            text = stringResource(R.string.vivimusic_canvas_desc),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(bottom = 24.dp, top = 16.dp)
        )

        // Large capsule banner for main toggle
        val containerColor by animateColorAsState(
            targetValue = if (canvasThumbnailAnimation) {
                MaterialTheme.colorScheme.primaryContainer
            } else {
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            },
            label = "containerColor"
        )

        val contentColor = if (canvasThumbnailAnimation) {
            MaterialTheme.colorScheme.onPrimaryContainer
        } else {
            MaterialTheme.colorScheme.onSurfaceVariant
        }

        Card(
            onClick = { onCanvasThumbnailAnimationChange(!canvasThumbnailAnimation) },
            shape = RoundedCornerShape(50),
            colors = CardDefaults.cardColors(containerColor = containerColor),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = stringResource(R.string.use_canvas),
                    style = MaterialTheme.typography.titleMedium,
                    color = contentColor
                )
                ModernSwitch(
                    checked = canvasThumbnailAnimation,
                    onCheckedChange = onCanvasThumbnailAnimationChange
                )
            }
        }


        Spacer(modifier = Modifier.height(24.dp))

        // Options settings group
        ExpressiveSettingGroup(
            title = stringResource(R.string.canvas_source),
            items = listOf(
                Material3SettingsItem(
                    leadingContent = {
                        AnimatedRadioButton(
                            selected = motionartworkSource == MotionartworkSource.AUTO,
                            onClick = null,
                            enabled = canvasThumbnailAnimation
                        )
                    },
                    title = { Text(stringResource(R.string.canvas_source_auto)) },
                    description = { Text(stringResource(R.string.canvas_source_auto_desc)) },
                    enabled = canvasThumbnailAnimation,
                    onClick = { onMotionartworkSourceChange(MotionartworkSource.AUTO) }
                ),
                Material3SettingsItem(
                    leadingContent = {
                        AnimatedRadioButton(
                            selected = motionartworkSource == MotionartworkSource.APPLE_MUSIC,
                            onClick = null,
                            enabled = canvasThumbnailAnimation
                        )
                    },
                    title = { Text(stringResource(R.string.canvas_source_apple_music)) },
                    description = { Text(stringResource(R.string.canvas_source_apple_music_desc)) },
                    enabled = canvasThumbnailAnimation,
                    onClick = { onMotionartworkSourceChange(MotionartworkSource.APPLE_MUSIC) }
                ),
                Material3SettingsItem(
                    leadingContent = {
                        AnimatedRadioButton(
                            selected = motionartworkSource == MotionartworkSource.VIVIMUSIC,
                            onClick = null,
                            enabled = canvasThumbnailAnimation
                        )
                    },
                    title = { Text(stringResource(R.string.canvas_source_vivimusic)) },
                    description = { Text(stringResource(R.string.canvas_source_vivimusic_desc)) },
                    enabled = canvasThumbnailAnimation,
                    onClick = { onMotionartworkSourceChange(MotionartworkSource.VIVIMUSIC) }
                ),
                Material3SettingsItem(
                    leadingContent = {
                        AnimatedRadioButton(
                            selected = motionartworkSource == MotionartworkSource.TIDAL,
                            onClick = null,
                            enabled = canvasThumbnailAnimation
                        )
                    },
                    title = { Text(stringResource(R.string.canvas_source_tidal)) },
                    description = { Text(stringResource(R.string.canvas_source_tidal_desc)) },
                    enabled = canvasThumbnailAnimation,
                    onClick = { onMotionartworkSourceChange(MotionartworkSource.TIDAL) }
                )
            )
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Network options group (bottom)
        ExpressiveSettingGroup(
            title = stringResource(R.string.canvas_network),
            items = listOf(
                Material3SettingsItem(
                    title = { Text(stringResource(R.string.canvas_load_only_wifi)) },
                    description = { Text(stringResource(R.string.canvas_load_only_wifi_desc)) },
                    trailingContent = {
                        ModernSwitch(
                            checked = canvasLoadOnlyWifi,
                            onCheckedChange = onCanvasLoadOnlyWifiChange,
                            enabled = canvasThumbnailAnimation
                        )
                    },
                    enabled = canvasThumbnailAnimation,
                    onClick = { if (canvasThumbnailAnimation) onCanvasLoadOnlyWifiChange(!canvasLoadOnlyWifi) }
                )
            )
        )

        Spacer(modifier = Modifier.height(36.dp))
    }


    TopAppBar(
        title = { Text(stringResource(R.string.vivimusic_canvas)) },
        navigationIcon = {
            IconButton(
                onClick = navController::navigateUp,
                onLongClick = navController::backToMain,
            ) {
                Icon(
                    painter = painterResource(R.drawable.arrow_back),
                    contentDescription = null,
                )
            }
        }
    )
}

/**
 * vivimusic Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */
package com.music.innertube.strategy

import com.music.innertube.models.YouTubeClient

data class ContentHints(
    val isExplicit: Boolean? = null,
    val isKidsContent: Boolean? = null,
    val isLive: Boolean? = null,
    val isUploaded: Boolean? = null,
)

class ContentAwareFallbackStrategy {
    fun resolveClients(hints: ContentHints): List<YouTubeClient> =
        when {
            hints.isUploaded == true -> uploadedClients
            hints.isLive == true -> liveClients
            hints.isKidsContent == true -> kidsClients
            hints.isExplicit == true -> explicitClients
            else -> defaultClients
        }

    private companion object {
        val uploadedClients = listOf(
            YouTubeClient.TVHTML5,
            YouTubeClient.WEB_REMIX,
            YouTubeClient.WEB_CREATOR,
            YouTubeClient.IOS,
        )

        val defaultClients = listOf(
            YouTubeClient.IOS,
            YouTubeClient.VISIONOS,
            YouTubeClient.ANDROID_VR_1_65_10,
            YouTubeClient.ANDROID_VR_1_43_32,
            YouTubeClient.WEB_REMIX,
            YouTubeClient.TVHTML5,
            YouTubeClient.TVHTML5_SIMPLY,
        )

        val explicitClients = listOf(
            YouTubeClient.IOS,
            YouTubeClient.VISIONOS,
            YouTubeClient.TVHTML5,
            YouTubeClient.WEB_REMIX,
        )

        val kidsClients = listOf(
            YouTubeClient.IOS,
            YouTubeClient.TVHTML5,
            YouTubeClient.WEB_REMIX,
            YouTubeClient.TVHTML5_SIMPLY,
            YouTubeClient.WEB_CREATOR,
        )

        val liveClients = listOf(
            YouTubeClient.IOS,
            YouTubeClient.TVHTML5,
            YouTubeClient.WEB_REMIX,
            YouTubeClient.WEB_CREATOR,
            YouTubeClient.TVHTML5_SIMPLY,
        )
    }
}

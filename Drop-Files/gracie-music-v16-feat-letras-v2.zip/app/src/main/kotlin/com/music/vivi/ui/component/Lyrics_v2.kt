/**
 * vivimusic Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */
package com.music.vivi.ui.component

import android.annotation.SuppressLint
import android.app.Activity
import android.view.WindowManager
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.material3.ContainedLoadingIndicator
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier

import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import android.widget.Toast
import com.music.vivi.LocalDatabase
import com.music.vivi.LocalPlayerConnection
import com.music.vivi.lyrics.LastLyricsCache
import com.music.vivi.utils.rememberPreference
import com.music.vivi.constants.*
import androidx.compose.foundation.shape.RoundedCornerShape
import com.music.vivi.R
import com.music.vivi.db.entities.LyricsEntity
import com.music.vivi.db.entities.LyricsEntity.Companion.LYRICS_NOT_FOUND
import com.music.vivi.lyrics.LyricsEntry
import com.music.vivi.lyrics.LyricsUtils
import com.music.vivi.models.MediaMetadata
import com.music.vivi.ui.component.MetroLyricsLine
import com.music.vivi.ui.screens.settings.LyricsPosition
import dagger.hilt.android.EntryPointAccessors
import androidx.compose.foundation.interaction.collectIsDraggedAsState
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.zIndex
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import android.content.Intent
import android.text.Layout
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.combinedClickable
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.draw.clip
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import com.music.vivi.utils.ComposeToImage
import com.music.vivi.ui.component.LyricsImageCard
import com.music.vivi.ui.component.LyricsBackgroundStyle

import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.verticalDrag
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.animation.core.exponentialDecay
import androidx.compose.animation.core.AnimationState
import androidx.compose.animation.core.animateDecay
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.Animatable
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.sp
import com.music.vivi.ui.utils.fadingEdge
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.first
import kotlin.math.roundToInt

private const val LYRICS_ANCHOR_RATIO = 0.40f
private const val LYRICS_ANCHOR_RATIO_CONTROLS_VISIBLE = 0.28f
private val LYRICS_ITEM_FALLBACK_HEIGHT_DP = 68.dp
private val LYRICS_ITEM_GAP_DP = 16.dp
private val LYRICS_FADE_TOP_DP = 130.dp
private val LYRICS_FADE_BOTTOM_DP = 160.dp
private const val LYRICS_STAGGER_DELAY_PER_DISTANCE = 20
private const val LYRICS_STAGGER_DELAY_MAX_MS = 200
private val INSTRUMENTAL_REGEX = Regex("^[.\\s…~♪\\-—•*·]+$")

private fun String.isInstrumentalPlaceholder(): Boolean {
    val trimmed = this.trim()
    return trimmed.isEmpty() || INSTRUMENTAL_REGEX.matches(trimmed)
}

sealed class LyricsListItemV2 {
    data class Line(val index: Int, val entry: LyricsEntry) : LyricsListItemV2()
    data class Indicator(
        val afterLineIndex: Int,
        val gapMs: Long,
        val gapStartMs: Long,
        val gapEndMs: Long
    ) : LyricsListItemV2()
}

@OptIn(ExperimentalMaterial3ExpressiveApi::class, ExperimentalMaterial3Api::class)
@SuppressLint("UnusedBoxWithConstraintsScope")
@Composable
fun LyricsV2(
    mediaMetadata: MediaMetadata?,
    showLyrics: Boolean,
    positionProvider: () -> Long,
    sliderPositionProvider: () -> Long? = { null },
    modifier: Modifier = Modifier,
    contentPadding: PaddingValues = PaddingValues(0.dp),
    playerCoordinates: androidx.compose.ui.layout.LayoutCoordinates? = null,
    onControlsVisibilityChange: (Boolean) -> Unit = {},
    controlsVisible: Boolean = false
) {
    if (!showLyrics) return

    val playerConnection = LocalPlayerConnection.current ?: return

    var isSelectionModeActive by remember { mutableStateOf(false) }
    val selectedIndices = remember { mutableStateListOf<Int>() }
    var showShareSheet by remember { mutableStateOf(false) }
    val haptic = LocalHapticFeedback.current

    val toggleSelection: (Int) -> Unit = { index ->
        if (selectedIndices.contains(index)) {
            selectedIndices.remove(index)
            if (selectedIndices.isEmpty()) {
                isSelectionModeActive = false
                onControlsVisibilityChange(true)
            }
        } else {
            selectedIndices.add(index)
        }
    }

    val startSelection: (Int) -> Unit = { index ->
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        if (!isSelectionModeActive) {
            isSelectionModeActive = true
            selectedIndices.clear()
            selectedIndices.add(index)
            onControlsVisibilityChange(false)
        } else {
            toggleSelection(index)
        }
    }

    val exitSelection: () -> Unit = {
        isSelectionModeActive = false
        selectedIndices.clear()
        onControlsVisibilityChange(true)
    }

    BackHandler(enabled = isSelectionModeActive) {
        exitSelection()
    }

    LaunchedEffect(mediaMetadata?.id) {
        if (isSelectionModeActive) {
            exitSelection()
        }
    }
    val appContext = LocalContext.current
    val currentLyrics by playerConnection.currentLyrics.collectAsState(
        initial = LastLyricsCache.lyricsFor(appContext, mediaMetadata?.id)
    )
    // Solo en pantalla (no en la base de datos): la búsqueda de respaldo terminó sin letra
    var searchGaveNothing by remember(mediaMetadata?.id) { mutableStateOf(false) }

    val scrollLyrics by rememberPreference(LyricsScrollKey, true)
    
    val romanizeJapaneseLyrics by rememberPreference(LyricsRomanizeJapaneseKey, true)
    val romanizeKoreanLyrics by rememberPreference(LyricsRomanizeKoreanKey, true)
    val romanizeRussianLyrics by rememberPreference(LyricsRomanizeRussianKey, true)
    val romanizeUkrainianLyrics by rememberPreference(LyricsRomanizeUkrainianKey, true)
    val romanizeSerbianLyrics by rememberPreference(LyricsRomanizeSerbianKey, true)
    val romanizeBulgarianLyrics by rememberPreference(LyricsRomanizeBulgarianKey, true)
    val romanizeBelarusianLyrics by rememberPreference(LyricsRomanizeBelarusianKey, true)
    val romanizeKyrgyzLyrics by rememberPreference(LyricsRomanizeKyrgyzKey, true)
    val romanizeMacedonianLyrics by rememberPreference(LyricsRomanizeMacedonianKey, true)
    val romanizeCyrillicByLine by rememberPreference(LyricsRomanizeCyrillicByLineKey, false)
    val romanizeAsMain by rememberPreference(LyricsRomanizeAsMainKey, false)
    val romanizeChineseLyrics by rememberPreference(LyricsRomanizeChineseKey, true)
    val romanizeHindiLyrics by rememberPreference(LyricsRomanizeHindiKey, true)
    val romanizePunjabiLyrics by rememberPreference(LyricsRomanizePunjabiKey, true)

    val playerBackground by com.music.vivi.utils.rememberEnumPreference(
        key = com.music.vivi.constants.PlayerBackgroundStyleKey,
        defaultValue = com.music.vivi.constants.PlayerBackgroundStyle.LIVE_MESH
    )

    val adaptivePrimary =
        if (playerBackground == com.music.vivi.constants.PlayerBackgroundStyle.DEFAULT) MaterialTheme.colorScheme.onSurface else Color.White
    val lyrics = remember(currentLyrics) { currentLyrics?.lyrics?.trim() }
    val context = LocalContext.current
    val database = LocalDatabase.current
    val coroutineScope = rememberCoroutineScope()
    val currentSong by playerConnection.currentSong.collectAsState(initial = null)
    val lyricsOffset = currentSong.effectiveLyricsOffsetMs().toLong()
    val showRomanized = currentSong?.song?.romanizeLyrics ?: true

    // Keep screen on while lyrics are visible
    DisposableEffect(showLyrics) {
        val activity = context as? Activity
        if (showLyrics) {
            activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        onDispose {
            activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    LaunchedEffect(mediaMetadata?.id, currentLyrics) {
        if (mediaMetadata != null && currentLyrics == null) {
            delay(500)
            coroutineScope.launch(Dispatchers.IO) {
                try {
                    val entryPoint = EntryPointAccessors.fromApplication(
                        context.applicationContext,
                        com.music.vivi.di.LyricsHelperEntryPoint::class.java
                    )
                    val lyricsHelper = entryPoint.lyricsHelper()
                    val fetchedLyricsWithProvider = lyricsHelper.getLyrics(mediaMetadata)
                    val fetched = fetchedLyricsWithProvider.lyrics
                    if (fetched.isBlank() || fetched == LYRICS_NOT_FOUND) {
                        // Puede ser un fallo de red o lentitud: no se graba en la base de datos
                        searchGaveNothing = true
                    } else {
                        database.query {
                            upsert(
                                LyricsEntity(
                                    mediaMetadata.id,
                                    fetched,
                                    fetchedLyricsWithProvider.provider
                                )
                            )
                        }
                    }
                } catch (e: Exception) {
                    // Handle error silently
                }
            }
        }
    }

    LaunchedEffect(currentLyrics, mediaMetadata?.id) {
        val entry = currentLyrics
        val meta = mediaMetadata
        if (entry != null && meta != null && entry.id == meta.id) {
            withContext(Dispatchers.IO) {
                LastLyricsCache.save(appContext, meta.id, entry.lyrics, entry.provider, meta.thumbnailUrl)
            }
        }
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        when {
            lyrics == null && !searchGaveNothing -> {
                ContainedLoadingIndicator()
            }

            lyrics == null || lyrics == LYRICS_NOT_FOUND -> {
                Text(
                    text = "Lyrics not found",
                    style = MaterialTheme.typography.bodyLarge,
                    color = adaptivePrimary.copy(alpha = 0.5f)
                )
            }

            else -> {
                val lines = remember(lyrics) {
                    if (lyrics.startsWith("[")) {
                        val parsedLines = LyricsUtils.parseLyrics(lyrics)
                        listOf(LyricsEntry.HEAD_LYRICS_ENTRY) + parsedLines.map { entry ->
                            val cleanText = if (entry.text.isInstrumentalPlaceholder()) "" else entry.text
                            LyricsEntry(entry.time, cleanText, entry.words, agent = entry.agent, isBackground = entry.isBackground)
                        }
                    } else {
                        lyrics.split("\n").mapIndexed { index, line ->
                            val cleanText = if (line.isInstrumentalPlaceholder()) "" else line
                            LyricsEntry(index * 100L, cleanText, emptyList())
                        }
                    }
                }

                LaunchedEffect(
                    lines,
                    lyrics,
                    romanizeJapaneseLyrics,
                    romanizeKoreanLyrics,
                    romanizeRussianLyrics,
                    romanizeUkrainianLyrics,
                    romanizeSerbianLyrics,
                    romanizeBulgarianLyrics,
                    romanizeBelarusianLyrics,
                    romanizeKyrgyzLyrics,
                    romanizeMacedonianLyrics,
                    romanizeChineseLyrics,
                    romanizeHindiLyrics,
                    romanizePunjabiLyrics,
                    romanizeCyrillicByLine
                ) {
                    if (lines.isEmpty()) return@LaunchedEffect
                    withContext(Dispatchers.Default) {
                        val isRussianLyrics = romanizeRussianLyrics && !romanizeCyrillicByLine && LyricsUtils.isRussian(lyrics)
                        val isUkrainianLyrics = romanizeUkrainianLyrics && !romanizeCyrillicByLine && LyricsUtils.isUkrainian(lyrics)
                        val isSerbianLyrics = romanizeSerbianLyrics && !romanizeCyrillicByLine && LyricsUtils.isSerbian(lyrics)
                        val isBulgarianLyrics = romanizeBulgarianLyrics && !romanizeCyrillicByLine && LyricsUtils.isBulgarian(lyrics)
                        val isBelarusianLyrics = romanizeBelarusianLyrics && !romanizeCyrillicByLine && LyricsUtils.isBelarusian(lyrics)
                        val isKyrgyzLyrics = romanizeKyrgyzLyrics && !romanizeCyrillicByLine && LyricsUtils.isKyrgyz(lyrics)
                        val isMacedonianLyrics = romanizeMacedonianLyrics && !romanizeCyrillicByLine && LyricsUtils.isMacedonian(lyrics)

                        for (entry in lines) {
                            if (!isActive) break
                            val text = entry.text
                            if (text.isBlank()) continue

                            if (romanizeJapaneseLyrics && LyricsUtils.isJapanese(text) && !LyricsUtils.isChinese(text)) {
                                entry.romanizedTextFlow.value = LyricsUtils.romanizeJapanese(text)
                            } else if (romanizeKoreanLyrics && LyricsUtils.isKorean(text)) {
                                entry.romanizedTextFlow.value = LyricsUtils.romanizeKorean(text)
                            } else if (romanizeRussianLyrics && (if (romanizeCyrillicByLine) LyricsUtils.isRussian(text) else isRussianLyrics)) {
                                entry.romanizedTextFlow.value = LyricsUtils.romanizeCyrillic(text)
                            } else if (romanizeUkrainianLyrics && (if (romanizeCyrillicByLine) LyricsUtils.isUkrainian(text) else isUkrainianLyrics)) {
                                entry.romanizedTextFlow.value = LyricsUtils.romanizeCyrillic(text)
                            } else if (romanizeSerbianLyrics && (if (romanizeCyrillicByLine) LyricsUtils.isSerbian(text) else isSerbianLyrics)) {
                                entry.romanizedTextFlow.value = LyricsUtils.romanizeCyrillic(text)
                            } else if (romanizeBulgarianLyrics && (if (romanizeCyrillicByLine) LyricsUtils.isBulgarian(text) else isBulgarianLyrics)) {
                                entry.romanizedTextFlow.value = LyricsUtils.romanizeCyrillic(text)
                            } else if (romanizeBelarusianLyrics && (if (romanizeCyrillicByLine) LyricsUtils.isBelarusian(text) else isBelarusianLyrics)) {
                                entry.romanizedTextFlow.value = LyricsUtils.romanizeCyrillic(text)
                            } else if (romanizeKyrgyzLyrics && (if (romanizeCyrillicByLine) LyricsUtils.isKyrgyz(text) else isKyrgyzLyrics)) {
                                entry.romanizedTextFlow.value = LyricsUtils.romanizeCyrillic(text)
                            } else if (romanizeMacedonianLyrics && (if (romanizeCyrillicByLine) LyricsUtils.isMacedonian(text) else isMacedonianLyrics)) {
                                entry.romanizedTextFlow.value = LyricsUtils.romanizeCyrillic(text)
                            } else if (romanizeChineseLyrics && LyricsUtils.isChinese(text)) {
                                entry.romanizedTextFlow.value = LyricsUtils.romanizeChinese(text)
                            } else if (romanizeHindiLyrics && LyricsUtils.isHindi(text)) {
                                entry.romanizedTextFlow.value = LyricsUtils.romanizeHindi(text)
                            } else if (romanizePunjabiLyrics && LyricsUtils.isPunjabi(text)) {
                                entry.romanizedTextFlow.value = LyricsUtils.romanizePunjabi(text)
                            }
                        }
                    }
                }
                
                val isLyricsProviderShown = currentLyrics?.provider != null && currentLyrics?.provider != "Unknown"

                // If plain text (not synced), render selectable list
                if (lines.isNotEmpty() && lines.all { it.time == 0L }) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(
                                top = 32.dp,
                                bottom = if (isSelectionModeActive) 140.dp else 120.dp,
                                start = 24.dp,
                                end = 24.dp
                            )
                        ) {
                            if (isLyricsProviderShown) {
                                item {
                                    Text(
                                        text = "Lyrics from ${currentLyrics?.provider}",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = adaptivePrimary.copy(alpha = 0.6f),
                                        fontWeight = FontWeight.Medium,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(bottom = 12.dp)
                                    )
                                }
                            }
                            items(lines.size) { index ->
                                val lineText = lines[index].text
                                if (lineText.isBlank() || lineText.isInstrumentalPlaceholder()) return@items
                                val isSelected = selectedIndices.contains(index)
                                Text(
                                    text = lineText,
                                    style = MaterialTheme.typography.headlineSmall,
                                    color = if (isSelected && isSelectionModeActive) MaterialTheme.colorScheme.primary else adaptivePrimary,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .combinedClickable(
                                            onClick = {
                                                if (isSelectionModeActive) {
                                                    toggleSelection(index)
                                                }
                                            },
                                            onLongClick = {
                                                startSelection(index)
                                            }
                                        )
                                        .background(
                                            if (isSelected && isSelectionModeActive)
                                                MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                                            else Color.Transparent
                                        )
                                        .padding(horizontal = 16.dp, vertical = 8.dp),
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Start
                                )
                            }
                        }

                        LyricsSelectionFloatingBox(
                            visible = isSelectionModeActive,
                            selectedCount = selectedIndices.size,
                            onCancel = exitSelection,
                            onShare = {
                                if (selectedIndices.isNotEmpty()) {
                                    showShareSheet = true
                                }
                            },
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(bottom = 24.dp)
                                .zIndex(10f)
                        )
                    }

                    if (showShareSheet && mediaMetadata != null) {
                        val selectedLyricsText = selectedIndices.sorted()
                            .mapNotNull { lines.getOrNull(it)?.text }
                            .joinToString("\n")

                        LyricsShareBottomSheet(
                            mediaMetadata = mediaMetadata,
                            lyrics = selectedLyricsText,
                            onDismissRequest = {
                                showShareSheet = false
                            }
                        )
                    }
                    return
                }

                val initialPos = remember { positionProvider() }
                val initialActiveLine = remember(lines, initialPos, lyricsOffset) {
                    if (lines.isNotEmpty()) {
                        val indices = LyricsUtils.findActiveLineIndices(lines, initialPos + lyricsOffset)
                        indices.maxOrNull() ?: 0
                    } else 0
                }

                var currentPlaybackPosition by remember { mutableLongStateOf(initialPos) }
                var currentLineIndex by remember { mutableIntStateOf(initialActiveLine) }
                var activeLineIndices by remember {
                    mutableStateOf(if (lines.isNotEmpty()) LyricsUtils.findActiveLineIndices(lines, initialPos + lyricsOffset) else emptySet())
                }
                var deferredCurrentLineIndex by rememberSaveable { mutableIntStateOf(initialActiveLine) }
                var scrollTargetIndex by rememberSaveable { mutableIntStateOf(initialActiveLine) }
                var previousScrollActiveIndices by remember { mutableStateOf(emptySet<Int>()) }
                var lastMainMaxSeen by remember(lyrics, lines) { mutableIntStateOf(initialActiveLine) }
                var isSeeking by remember { mutableStateOf(false) }
                var isAutoScrollEnabled by rememberSaveable { mutableStateOf(scrollLyrics) }
                var lastPreviewTime by rememberSaveable { mutableLongStateOf(0L) }

                val mergedLyricsList = remember(lines) {
                    val result = mutableListOf<LyricsListItemV2>()
                    if (lines.isEmpty()) return@remember result

                    lines.forEachIndexed { i, entry ->
                        val isPlaceholder = entry.text.isBlank() || entry.text.isInstrumentalPlaceholder()
                        if (!isPlaceholder) {
                            result.add(LyricsListItemV2.Line(i, entry))
                        }
                        if (i < lines.size - 1) {
                            val nextStart = lines[i + 1].time
                            val currentEnd = if (!entry.words.isNullOrEmpty()) {
                                (entry.words.last().endTime * 1000).toLong()
                            } else if (isPlaceholder) {
                                entry.time
                            } else {
                                val estimatedDuration = (entry.text.length * 200L).coerceIn(2000L, 4500L)
                                if (nextStart - entry.time > estimatedDuration + 4000L) {
                                    entry.time + estimatedDuration
                                } else {
                                    null
                                }
                            }

                            if (currentEnd != null && currentEnd < nextStart) {
                                val gap = nextStart - currentEnd
                                if (gap > 4000L) {
                                    result.add(
                                        LyricsListItemV2.Indicator(
                                            afterLineIndex = i,
                                            gapMs = gap,
                                            gapStartMs = currentEnd,
                                            gapEndMs = nextStart
                                        )
                                    )
                                }
                            }
                        }
                    }
                    result
                }

                val activeListIndex by remember(mergedLyricsList, deferredCurrentLineIndex, currentPlaybackPosition) {
                    derivedStateOf {
                        val activeIndicatorIndex = mergedLyricsList.indexOfFirst {
                            it is LyricsListItemV2.Indicator &&
                                currentPlaybackPosition >= it.gapStartMs &&
                                currentPlaybackPosition <= it.gapEndMs - 650L
                        }
                        if (activeIndicatorIndex != -1) {
                            activeIndicatorIndex
                        } else {
                            mergedLyricsList.indexOfFirst {
                                (it is LyricsListItemV2.Line && it.index == deferredCurrentLineIndex) ||
                                (it is LyricsListItemV2.Indicator && it.afterLineIndex == deferredCurrentLineIndex)
                            }.coerceAtLeast(0)
                        }
                    }
                }

                var userManualOffset by remember { mutableFloatStateOf(0f) }
                var flingJob by remember { mutableStateOf<kotlinx.coroutines.Job?>(null) }
                val velocityTracker = remember { VelocityTracker() }
                val decayAnimSpec = remember { exponentialDecay<Float>(frictionMultiplier = 1.8f) }
                val itemHeights = remember(lyrics, mergedLyricsList) { mutableStateMapOf<Int, Int>() }
                var isInitialLayout by remember(lyrics, mergedLyricsList) { mutableStateOf(true) }
                val contentAlpha by animateFloatAsState(
                    targetValue = if (isInitialLayout) 0f else 1f,
                    animationSpec = tween(durationMillis = 200, easing = FastOutSlowInEasing),
                    label = "lyricContentAlpha"
                )

                LaunchedEffect(showLyrics, lyrics, mergedLyricsList.size) {
                    if (showLyrics && mergedLyricsList.isNotEmpty()) {
                        isInitialLayout = true
                        snapshotFlow {
                            val h = itemHeights.toMap()
                            val windowStart = (activeListIndex - 8).coerceAtLeast(0)
                            val windowEnd = (activeListIndex + 12).coerceAtMost(mergedLyricsList.size - 1)
                            (windowStart..windowEnd).all { h.containsKey(it) }
                        }.first { it }
                        delay(16)
                        isInitialLayout = false
                    }
                }

                LaunchedEffect(activeListIndex) {
                    if (mergedLyricsList.isNotEmpty()) {
                        val h = itemHeights.toMap()
                        val windowStart = (activeListIndex - 3).coerceAtLeast(0)
                        val windowEnd = (activeListIndex + 3).coerceAtMost(mergedLyricsList.size - 1)
                        val needsMeasurement = (windowStart..windowEnd).any { !h.containsKey(it) }
                        if (needsMeasurement) {
                            isInitialLayout = true
                            snapshotFlow {
                                val hh = itemHeights.toMap()
                                (windowStart..windowEnd).all { hh.containsKey(it) }
                            }.first { it }
                            isInitialLayout = false
                        }
                    }
                }

                LaunchedEffect(lyrics, lines) {
                    isAutoScrollEnabled = scrollLyrics
                    val pos = positionProvider()
                    val active = if (lines.isNotEmpty()) {
                        LyricsUtils.findActiveLineIndices(lines, pos + lyricsOffset).maxOrNull() ?: 0
                    } else 0
                    scrollTargetIndex = active
                    currentLineIndex = active
                    deferredCurrentLineIndex = active
                    previousScrollActiveIndices = emptySet()
                    lastMainMaxSeen = active
                    userManualOffset = 0f
                }

                LaunchedEffect(lyrics, lines) {
                    if (lyrics.isNullOrEmpty() || !lyrics.startsWith("[")) {
                        currentLineIndex = -1
                        activeLineIndices = emptySet()
                        return@LaunchedEffect
                    }
                    var lastPlayerPos = playerConnection.player.currentPosition
                    var lastUpdateTime = System.currentTimeMillis()
                    var lastPlaybackPosition = lastPlayerPos
                    val hasWordTimings = lines.any { !it.words.isNullOrEmpty() }

                    while (isActive) {
                        withFrameNanos { _ -> }
                        val now = System.currentTimeMillis()
                        val sliderPos = sliderPositionProvider()
                        isSeeking = sliderPos != null

                        val position = if (isSeeking) {
                            sliderPos!!
                        } else {
                            val providerPos = positionProvider()
                            val playerPos = playerConnection.player.currentPosition
                            val isPlaying = playerConnection.player.isPlaying
                            if (kotlin.math.abs(providerPos - playerPos) > 1000L) {
                                lastPlayerPos = playerPos
                                lastUpdateTime = now
                                providerPos
                            } else {
                                if (playerPos != lastPlayerPos || !isPlaying) {
                                    lastPlayerPos = playerPos
                                    lastUpdateTime = now
                                }
                                val elapsed = now - lastUpdateTime
                                lastPlayerPos + (if (isPlaying) elapsed else 0L)
                            }
                        }

                        currentPlaybackPosition = position
                        val effectivePosition = position + lyricsOffset

                        val initialActiveIndices = LyricsUtils.findActiveLineIndices(lines, effectivePosition)
                        val scrollActiveIndicesRaw = LyricsUtils.findActiveLineIndices(lines, effectivePosition + (if (hasWordTimings) 0L else 250L))

                        val scrollActiveIndices = scrollActiveIndicesRaw.toMutableSet()
                        for (i in scrollActiveIndicesRaw) {
                            if (lines.getOrNull(i)?.isBackground == true) {
                                for (j in i - 1 downTo 0) {
                                    if (lines.getOrNull(j)?.isBackground == false) {
                                        scrollActiveIndices.add(j)
                                        break
                                    }
                                }
                            }
                        }

                        val newActiveIndices = initialActiveIndices.toMutableSet()
                        for (i in initialActiveIndices) {
                            if (lines.getOrNull(i)?.isBackground == true) {
                                for (j in i - 1 downTo 0) {
                                    if (lines.getOrNull(j)?.isBackground == false) {
                                        newActiveIndices.add(j)
                                        break
                                    }
                                }
                            }
                        }

                        val scrollMax = scrollActiveIndices
                            .filter { !it.let { lines[it].isBackground } }
                            .maxOrNull() ?: (scrollActiveIndices.maxOrNull() ?: -1)

                        // Detect seek backwards or slider scrub
                        val isBackwardSeek = position < lastPlaybackPosition - 1500L
                        if (isSeeking || isBackwardSeek) {
                            lastMainMaxSeen = scrollMax
                            if (scrollMax != -1) {
                                scrollTargetIndex = scrollMax
                                deferredCurrentLineIndex = scrollMax
                            }
                        }
                        lastPlaybackPosition = position

                        val isCurrentTargetStillActive = scrollTargetIndex in scrollActiveIndices
                        val anyStillActive = scrollActiveIndices.isNotEmpty()

                        val shouldScroll = when {
                            isSeeking -> true
                            !isCurrentTargetStillActive && anyStillActive && scrollMax > scrollTargetIndex -> true
                            !isCurrentTargetStillActive && !anyStillActive && previousScrollActiveIndices.isNotEmpty() -> true
                            scrollTargetIndex == -1 && anyStillActive -> true
                            previousScrollActiveIndices.isEmpty() && anyStillActive && scrollMax > scrollTargetIndex -> true
                            else -> false
                        }

                        if (shouldScroll) {
                            val targetToScroll = when {
                                isSeeking -> scrollMax
                                !isCurrentTargetStillActive && anyStillActive -> scrollMax
                                !isCurrentTargetStillActive && !anyStillActive -> {
                                    (lastMainMaxSeen + 1 until lines.size).firstOrNull {
                                        !it.let { lines[it].isBackground }
                                    } ?: scrollTargetIndex
                                }
                                else -> scrollMax
                            }
                            if (targetToScroll != -1 && (isSeeking || targetToScroll > scrollTargetIndex || isBackwardSeek)) {
                                scrollTargetIndex = targetToScroll
                                if (isSeeking) {
                                    deferredCurrentLineIndex = targetToScroll
                                }
                            }
                        }

                        if (scrollMax > lastMainMaxSeen && scrollMax != -1) {
                            lastMainMaxSeen = scrollMax
                        }

                        previousScrollActiveIndices = scrollActiveIndices
                        activeLineIndices = newActiveIndices
                        currentLineIndex = scrollMax
                    }
                }

                LaunchedEffect(scrollTargetIndex, isAutoScrollEnabled) {
                    if (isAutoScrollEnabled && scrollTargetIndex != -1) {
                        deferredCurrentLineIndex = scrollTargetIndex
                    }
                }

                // When user is slider-seeking, force auto-scroll immediately.
                LaunchedEffect(isSeeking) {
                    if (isSeeking) {
                        flingJob?.cancel()
                        lastPreviewTime = 0L
                        isAutoScrollEnabled = true
                        userManualOffset = 0f
                    }
                }

                // Auto-resync: after the user stops touching the screen for 4 seconds,
                // re-enable auto-scroll so lyrics automatically move back to the active line.
                // collectLatest ensures each new touch/drag cancels any in-progress 4s countdown.
                LaunchedEffect(isAutoScrollEnabled) {
                    if (!isAutoScrollEnabled) {
                        snapshotFlow { lastPreviewTime }
                            .collectLatest { startTime ->
                                if (startTime != 0L) {
                                    delay(4000L)
                                    lastPreviewTime = 0L
                                    isAutoScrollEnabled = true
                                }
                            }
                    }
                }

                val density = LocalDensity.current

                var zoneTopInPlayerPx by remember { mutableStateOf(0f) }
                var playerHeightPx by remember { mutableStateOf(0f) }
                val isAtLyricsStart = mergedLyricsList.firstOrNull() is LyricsListItemV2.Indicator && activeListIndex <= 0

                BoxWithConstraints(
                    contentAlignment = Alignment.TopCenter,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(bottom = 12.dp)
                        .onGloballyPositioned { zone ->
                            val player = playerCoordinates
                            if (player != null && player.isAttached && zone.isAttached) {
                                zoneTopInPlayerPx = player.localPositionOf(zone, androidx.compose.ui.geometry.Offset.Zero).y
                                playerHeightPx = player.size.height.toFloat()
                            }
                        }
                ) {
                    val maxHeightPx = constraints.maxHeight.toFloat()
                    val anchorRatio = if (controlsVisible || isAtLyricsStart) {
                        LYRICS_ANCHOR_RATIO_CONTROLS_VISIBLE
                    } else {
                        LYRICS_ANCHOR_RATIO
                    }
                    val anchorY = if (playerHeightPx > 0f) {
                        (playerHeightPx * anchorRatio - zoneTopInPlayerPx).coerceIn(0f, maxHeightPx)
                    } else {
                        maxHeightPx * anchorRatio
                    }
                    val lineHeightPx = with(density) { LYRICS_ITEM_FALLBACK_HEIGHT_DP.toPx() }
                    val constraintLineHeightPx = with(density) { 120.dp.toPx() }

                    val positions = remember(itemHeights.toMap(), activeListIndex, mergedLyricsList) {
                        val map = mutableMapOf<Int, Float>()
                        if (mergedLyricsList.isEmpty()) return@remember map

                        val effectiveActiveIndex = if (activeListIndex in mergedLyricsList.indices) activeListIndex else 0
                        map[effectiveActiveIndex] = 0f
                        var currentY = 0f
                        val indicatorHeightPx = with(density) { 72.dp.toPx() }
                        val gapPx = with(density) { LYRICS_ITEM_GAP_DP.toPx() }
                        val avgMeasuredHeight = run {
                            val measured = itemHeights.values
                            if (measured.isEmpty()) lineHeightPx else measured.average().toFloat()
                        }
                        for (i in effectiveActiveIndex - 1 downTo 0) {
                            val item = mergedLyricsList[i]
                            val height = itemHeights[i]?.toFloat() ?: (if (item is LyricsListItemV2.Indicator) indicatorHeightPx else avgMeasuredHeight)
                            val noGap = (item as? LyricsListItemV2.Line)?.entry?.isBackground == true || item is LyricsListItemV2.Indicator
                            currentY -= (height + if (noGap) 0f else gapPx)
                            map[i] = currentY
                        }
                        currentY = 0f
                        for (i in effectiveActiveIndex until mergedLyricsList.size - 1) {
                            val currentItem = mergedLyricsList[i]
                            val nextItem = mergedLyricsList[i + 1]
                            val height = itemHeights[i]?.toFloat() ?: (if (currentItem is LyricsListItemV2.Indicator) indicatorHeightPx else avgMeasuredHeight)
                            val nextNoGap = (nextItem as? LyricsListItemV2.Line)?.entry?.isBackground == true || nextItem is LyricsListItemV2.Indicator
                            currentY += (height + if (nextNoGap) 0f else gapPx)
                            map[i + 1] = currentY
                        }
                        map
                    }

                    // Derive scroll bounds directly from the already-computed positions map.
                    // Each item's screen Y = anchorY + positions[listIndex] + userManualOffset.
                    //
                    // maxOffset (drag DOWN → first item visible near top):
                    //   anchorY + positions[0] + maxOffset = topPad  →  maxOffset = topPad - anchorY - positions[0]
                    //   positions[0] is negative, so maxOffset is positive.
                    //
                    // minOffset (drag UP → last item visible near bottom):
                    //   anchorY + positions[last] + minOffset = maxH - botPad  →  minOffset = maxH - botPad - anchorY - positions[last]
                    //   positions[last] is large positive, so minOffset is negative.
                    val indicatorHeightPx = with(density) { 72.dp.toPx() }
                    val gapPx = with(density) { LYRICS_ITEM_GAP_DP.toPx() }

                    val avgMeasuredHeight: Float = run {
                        val measured = itemHeights.values
                        if (measured.isEmpty()) lineHeightPx else measured.average().toFloat()
                    }

                    fun estimatedPos(targetIndex: Int): Float {
                        var y = 0f
                        val effectiveActive = if (activeListIndex in mergedLyricsList.indices) activeListIndex else 0
                        if (targetIndex >= effectiveActive) {
                            for (i in effectiveActive until targetIndex) {
                                val item = mergedLyricsList[i]
                                val h = itemHeights[i]?.toFloat()
                                    ?: if (item is LyricsListItemV2.Indicator) indicatorHeightPx else avgMeasuredHeight
                                val nextItem = mergedLyricsList.getOrNull(i + 1)
                                val noGap = (nextItem as? LyricsListItemV2.Line)?.entry?.isBackground == true
                                    || nextItem is LyricsListItemV2.Indicator
                                y += h + if (noGap) 0f else gapPx
                            }
                        } else {
                            for (i in effectiveActive - 1 downTo targetIndex) {
                                val item = mergedLyricsList[i]
                                val h = itemHeights[i]?.toFloat()
                                    ?: if (item is LyricsListItemV2.Indicator) indicatorHeightPx else avgMeasuredHeight
                                val noGap = (item as? LyricsListItemV2.Line)?.entry?.isBackground == true
                                    || item is LyricsListItemV2.Indicator
                                y -= h + if (noGap) 0f else gapPx
                            }
                        }
                        return y
                    }

                    val firstPos = if (mergedLyricsList.isEmpty()) 0f
                        else positions.getOrElse(0) { estimatedPos(0) }
                    val lastPos = if (mergedLyricsList.isEmpty()) 0f
                        else positions.getOrElse(mergedLyricsList.size - 1) { estimatedPos(mergedLyricsList.size - 1) }

                    // Exact bounds calculation from Player.kt / Lyrics.kt:
                    // totalAbove is the accumulated height of items above active line (-firstPos)
                    // totalBelow is the accumulated height of items below active line (lastPos)
                    val totalAbove = if (firstPos < 0f) -firstPos else 0f
                    val totalBelow = if (lastPos > 0f) lastPos else 0f
                    val lastItem = mergedLyricsList.lastOrNull()
                    val lastHeight = itemHeights[mergedLyricsList.size - 1]?.toFloat()
                        ?: if (lastItem is LyricsListItemV2.Indicator) indicatorHeightPx else avgMeasuredHeight

                    val minOffset = with(density) { 100.dp.toPx() } - anchorY - totalBelow - lastHeight
                    val maxOffset = maxHeightPx - with(density) { 150.dp.toPx() } - anchorY + totalAbove

                    val scrollClampMin = minOf(minOffset, maxOffset)
                    val scrollClampMax = maxOf(minOffset, maxOffset)

                    LaunchedEffect(isAutoScrollEnabled, mergedLyricsList.size) {
                        if (isAutoScrollEnabled) {
                            val start = userManualOffset
                            if (kotlin.math.abs(start) < 1f) {
                                userManualOffset = 0f
                                return@LaunchedEffect
                            }
                            // Direct assignment so there's no drift from concurrent fling/drag state
                            val durationMs = (kotlin.math.abs(start) / 3f).toInt().coerceIn(300, 700)
                            val anim = Animatable(start)
                            anim.animateTo(
                                targetValue = 0f,
                                animationSpec = tween(durationMs, easing = FastOutSlowInEasing)
                            ) {
                                userManualOffset = value
                            }
                            userManualOffset = 0f
                        }
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .fadingEdge(top = LYRICS_FADE_TOP_DP, bottom = LYRICS_FADE_BOTTOM_DP)
                            .clipToBounds()
                            .pointerInput(Unit) {
                                coroutineScope {
                                    awaitEachGesture {
                                        val down = awaitFirstDown(requireUnconsumed = false)
                                        flingJob?.cancel()
                                        velocityTracker.resetTracking()
                                        velocityTracker.addPosition(down.uptimeMillis, down.position)
                                        isAutoScrollEnabled = false
                                        lastPreviewTime = 0L // Pause auto-scroll timer while touching screen

                                        var dragConsumed = false
                                        var totalDragY = 0f
                                        var hasHiddenControlsForDrag = false
                                        verticalDrag(down.id) { change ->
                                            val dragAmount = change.positionChange().y
                                            totalDragY += dragAmount
                                            if (!hasHiddenControlsForDrag && kotlin.math.abs(totalDragY) > 8f) {
                                                hasHiddenControlsForDrag = true
                                                onControlsVisibilityChange(false)
                                            }
                                            velocityTracker.addPosition(change.uptimeMillis, change.position)

                                            val newOffset = userManualOffset + dragAmount
                                            if (newOffset in scrollClampMin..scrollClampMax) {
                                                userManualOffset = newOffset
                                                dragConsumed = true
                                            } else {
                                                val overscroll = if (newOffset < scrollClampMin) newOffset - scrollClampMin else newOffset - scrollClampMax
                                                val friction = 0.35f / (1f + kotlin.math.abs(overscroll) / 300f)
                                                userManualOffset = (userManualOffset + dragAmount * friction).coerceIn(
                                                    scrollClampMin - 150f,
                                                    scrollClampMax + 150f
                                                )
                                            }
                                            change.consume()
                                            isAutoScrollEnabled = false
                                            lastPreviewTime = 0L // Keep timer paused during active drag
                                        }

                                        if (!dragConsumed && kotlin.math.abs(totalDragY) <= 8f) {
                                            onControlsVisibilityChange(true)
                                        }

                                        if (isAutoScrollEnabled) return@awaitEachGesture

                                        // Finger lifted: start 4-second countdown to auto-scroll
                                        lastPreviewTime = System.currentTimeMillis()

                                        val velocity = velocityTracker.calculateVelocity().y
                                        if (kotlin.math.abs(velocity) > 100f) {
                                            flingJob = launch {
                                                val animState = AnimationState(
                                                    initialValue = userManualOffset,
                                                    initialVelocity = velocity
                                                )
                                                animState.animateDecay(decayAnimSpec) {
                                                    if (!isAutoScrollEnabled && value in scrollClampMin..scrollClampMax) {
                                                        userManualOffset = value
                                                    } else if (!isAutoScrollEnabled) {
                                                        val target = value.coerceIn(scrollClampMin, scrollClampMax)
                                                        cancelAnimation()
                                                        launch {
                                                            Animatable(userManualOffset).animateTo(
                                                                targetValue = target,
                                                                animationSpec = androidx.compose.animation.core.spring(
                                                                    dampingRatio = androidx.compose.animation.core.Spring.DampingRatioLowBouncy,
                                                                    stiffness = androidx.compose.animation.core.Spring.StiffnessMedium
                                                                )
                                                            ) {
                                                                if (!isAutoScrollEnabled) userManualOffset = value
                                                            }
                                                        }
                                                    } else {
                                                        cancelAnimation()
                                                    }
                                                }
                                            }
                                        } else {
                                            if (userManualOffset < scrollClampMin || userManualOffset > scrollClampMax) {
                                                val target = userManualOffset.coerceIn(scrollClampMin, scrollClampMax)
                                                flingJob = launch {
                                                    androidx.compose.animation.core.Animatable(userManualOffset).animateTo(
                                                        targetValue = target,
                                                        animationSpec = tween(300, easing = FastOutSlowInEasing)
                                                    ) {
                                                        userManualOffset = value
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                    ) {
                        if (isLyricsProviderShown) {
                            val targetProviderBase = anchorY + (positions[0] ?: 0f) - with(density) { 32.dp.toPx() }
                            val animatedProviderBase by animateFloatAsState(
                                targetValue = targetProviderBase,
                                animationSpec = if (isInitialLayout || !isAutoScrollEnabled || isSeeking) snap()
                                else {
                                    tween(750, 0, FastOutSlowInEasing)
                                },
                                label = "lyricsProviderOffset"
                            )
                            Text(
                                text = "Lyrics from ${currentLyrics?.provider}",
                                fontSize = 12.sp,
                                color = adaptivePrimary.copy(alpha = 0.6f * contentAlpha),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .offset { IntOffset(0, (animatedProviderBase + userManualOffset).roundToInt()) }
                                    .padding(horizontal = 24.dp, vertical = 4.dp),
                                textAlign = TextAlign.Center
                            )
                        }

                        val visibleTop = -userManualOffset - anchorY - 800f
                        val visibleBottom = maxHeightPx - anchorY - userManualOffset + 800f
                        val measurementWindowStart = (activeListIndex - 8).coerceAtLeast(0)
                        val measurementWindowEnd = (activeListIndex + 12).coerceAtMost(mergedLyricsList.size - 1)

                        mergedLyricsList.forEachIndexed { listIndex, listItem ->
                            val itemPos = positions[listIndex] ?: ((listIndex - activeListIndex) * lineHeightPx)
                            val isWithinViewport = itemPos in visibleTop..visibleBottom
                            val isInMeasurementGate = listIndex in measurementWindowStart..measurementWindowEnd

                            if (isWithinViewport || isInMeasurementGate) {
                                key(listItem) {
                                    val distance = kotlin.math.abs(listIndex - activeListIndex)
                                    val targetOffset = anchorY + itemPos

                                    val animatedOffset by animateFloatAsState(
                                        targetValue = targetOffset,
                                        animationSpec = if (isInitialLayout || !isAutoScrollEnabled || isSeeking) snap()
                                        else {
                                            tween(750, (distance * LYRICS_STAGGER_DELAY_PER_DISTANCE).coerceAtMost(LYRICS_STAGGER_DELAY_MAX_MS), FastOutSlowInEasing)
                                        },
                                        label = "lyricStaggeredOffset_$listIndex"
                                    )

                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .graphicsLayer {
                                                alpha = contentAlpha
                                            }
                                            .layout { measurable, constraints ->
                                                val placeable = measurable.measure(constraints.copy(maxHeight = Constraints.Infinity))
                                                itemHeights[listIndex] = placeable.height
                                                layout(placeable.width, 0) {
                                                    placeable.place(0, 0)
                                                }
                                            }
                                            .offset { IntOffset(0, (animatedOffset + userManualOffset).roundToInt()) }
                                    ) {
                                        when (listItem) {
                                            is LyricsListItemV2.Line -> {
                                                val index = listItem.index
                                                val line = listItem.entry
                                                val isSelected = selectedIndices.contains(index)
                                                val effectivePlaybackPosition = currentPlaybackPosition + lyricsOffset

                                                val pairedMainLineIndex = if (line.isBackground) {
                                                    (index - 1 downTo 0).firstOrNull { lines.getOrNull(it)?.isBackground == false } ?: -1
                                                } else -1
                                                val isInGapWithMain = if (line.isBackground && pairedMainLineIndex != -1) {
                                                    val pairedMainLine = lines[pairedMainLineIndex]
                                                    effectivePlaybackPosition >= pairedMainLine.time && effectivePlaybackPosition <= line.time
                                                } else false
                                                val bgVisible = !line.isBackground || (
                                                    activeLineIndices.contains(pairedMainLineIndex) ||
                                                    activeLineIndices.contains(index) ||
                                                    isInGapWithMain
                                                )

                                                MetroLyricsLine(
                                                    entry = line,
                                                    nextEntryTime = lines.getOrNull(index + 1)?.time,
                                                    effectivePlaybackPosition = effectivePlaybackPosition,
                                                    lyricsOffset = lyricsOffset,
                                                    isSynced = true,
                                                    isActive = activeLineIndices.contains(index),
                                                    distanceFromCurrent = kotlin.math.abs(index - deferredCurrentLineIndex),
                                                    lyricsTextPosition = LyricsPosition.LEFT,
                                                    textColor = adaptivePrimary,
                                                    showRomanized = showRomanized,
                                                    showTranslated = false, // se quita en F4 parte 3 (MetroLyrics)
                                                    isAutoScrollActive = isAutoScrollEnabled,
                                                    isSelectionModeActive = isSelectionModeActive,
                                                    isSelected = isSelected,
                                                    expressiveAccent = adaptivePrimary,
                                                    bgVisible = bgVisible,
                                                    onClick = {
                                                        if (isSelectionModeActive) {
                                                            toggleSelection(index)
                                                        } else {
                                                            playerConnection.seekTo((line.time - lyricsOffset).coerceAtLeast(0))
                                                            scrollTargetIndex = index
                                                            isAutoScrollEnabled = true
                                                            lastPreviewTime = 0L
                                                        }
                                                    },
                                                    onLongClick = {
                                                        startSelection(index)
                                                    }
                                                )
                                            }

                                            is LyricsListItemV2.Indicator -> {
                                                val indicatorVisible = isAutoScrollEnabled &&
                                                    currentPlaybackPosition >= listItem.gapStartMs &&
                                                    currentPlaybackPosition <= listItem.gapEndMs - 650L
                                                IntervalIndicator(
                                                    gapStartMs = listItem.gapStartMs,
                                                    gapEndMs = listItem.gapEndMs - 650L,
                                                    currentPositionMs = currentPlaybackPosition,
                                                    visible = indicatorVisible,
                                                    color = adaptivePrimary,
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(horizontal = 24.dp)
                                                        .wrapContentWidth(Alignment.CenterHorizontally)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                    Box(
                        modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 16.dp)
                    ) {
                        AnimatedVisibility(
                            visible = !isAutoScrollEnabled && !isSelectionModeActive,
                            enter = slideInVertically(tween(300, easing = FastOutSlowInEasing)) { it } + fadeIn(tween(300)),
                            exit = slideOutVertically(tween(250, easing = FastOutSlowInEasing)) { it } + fadeOut(tween(250))
                        ) {
                            FilledTonalButton(onClick = {
                                // Cancel any in-progress fling before starting spring-back;
                                // without this, flingJob keeps writing to userManualOffset
                                // and fights the spring-back animation.
                                flingJob?.cancel()
                                flingJob = null
                                if (currentLineIndex != -1) {
                                    scrollTargetIndex = currentLineIndex
                                    deferredCurrentLineIndex = currentLineIndex
                                    lastMainMaxSeen = currentLineIndex
                                }
                                lastPreviewTime = 0L
                                isAutoScrollEnabled = true
                            }) {
                                Icon(
                                    painter = painterResource(id = R.drawable.sync),
                                    contentDescription = stringResource(R.string.auto_scroll),
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(text = stringResource(R.string.auto_scroll))
                            }
                        }
                    }

                    LyricsSelectionFloatingBox(
                        visible = isSelectionModeActive,
                        selectedCount = selectedIndices.size,
                        onCancel = exitSelection,
                        onShare = {
                            if (selectedIndices.isNotEmpty()) {
                                showShareSheet = true
                            }
                        },
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 24.dp)
                            .zIndex(10f)
                    )
                }
            }
        }

    if (showShareSheet && mediaMetadata != null) {
        val rawLyrics = currentLyrics?.lyrics
        val lines = remember(rawLyrics) {
            rawLyrics?.let { LyricsUtils.parseLyrics(it) } ?: emptyList()
        }
        val selectedLyricsText = selectedIndices.sorted()
            .mapNotNull { lines.getOrNull(it)?.text }
            .joinToString("\n")

        LyricsShareBottomSheet(
            mediaMetadata = mediaMetadata,
            lyrics = selectedLyricsText,
            onDismissRequest = {
                showShareSheet = false
                exitSelection()
            }
        )
    }
}

@Composable
private fun LyricsSelectionFloatingBox(
    visible: Boolean,
    selectedCount: Int,
    onCancel: () -> Unit,
    onShare: () -> Unit,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = visible,
        enter = slideInVertically(tween(350, easing = FastOutSlowInEasing)) { it } + fadeIn(tween(350)),
        exit = slideOutVertically(tween(250, easing = FastOutSlowInEasing)) { it } + fadeOut(tween(250)),
        modifier = modifier
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.95f),
            tonalElevation = 8.dp,
            shadowElevation = 10.dp,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
            modifier = Modifier.wrapContentSize()
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                TextButton(
                    onClick = onCancel,
                    shape = RoundedCornerShape(16.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.close),
                        contentDescription = "Cancel",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Cancel",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Box(
                    modifier = Modifier
                        .width(1.dp)
                        .height(24.dp)
                        .background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
                )

                Button(
                    onClick = onShare,
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.share),
                        contentDescription = "Share",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Share ($selectedCount)",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LyricsShareBottomSheet(
    mediaMetadata: MediaMetadata,
    lyrics: String,
    onDismissRequest: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var isGeneratingImage by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismissRequest,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
        tonalElevation = 6.dp,
        dragHandle = {
            BottomSheetDefaults.DragHandle()
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(bottom = 32.dp, start = 20.dp, end = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = stringResource(R.string.share_lyrics),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            // Blur Card Preview (Dynamic Height: expands as more lyrics lines are selected)
            LyricsImageCard(
                lyricText = lyrics,
                mediaMetadata = mediaMetadata,
                backgroundStyle = LyricsBackgroundStyle.BLUR,
                backgroundColor = Color.Transparent,
                textAlign = TextAlign.Start,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(24.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Save button
                FilledTonalButton(
                    onClick = {
                        if (isGeneratingImage) return@FilledTonalButton
                        isGeneratingImage = true
                        coroutineScope.launch(Dispatchers.IO) {
                            try {
                                val image = ComposeToImage.createLyricsImage(
                                    context = context,
                                    mediaMetadata = mediaMetadata,
                                    lyrics = lyrics,
                                    backgroundStyle = LyricsBackgroundStyle.BLUR,
                                    backgroundColor = android.graphics.Color.TRANSPARENT,
                                    textColor = android.graphics.Color.WHITE,
                                    secondaryTextColor = android.graphics.Color.WHITE,
                                    lyricsAlignment = Layout.Alignment.ALIGN_NORMAL
                                )
                                val timestamp = System.currentTimeMillis()
                                val filename = "lyrics_$timestamp"
                                ComposeToImage.saveBitmapAsFile(context, image, filename)
                                withContext(Dispatchers.Main) {
                                    Toast.makeText(
                                        context,
                                        "Image saved to Pictures/vivimusic",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            } catch (e: Exception) {
                                withContext(Dispatchers.Main) {
                                    Toast.makeText(
                                        context,
                                        context.getString(R.string.failed_to_create_image, e.message),
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            } finally {
                                isGeneratingImage = false
                            }
                        }
                    },
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp),
                    enabled = !isGeneratingImage
                ) {
                    if (isGeneratingImage) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            strokeWidth = 2.5.dp
                        )
                    } else {
                        Icon(
                            painter = painterResource(id = R.drawable.download),
                            contentDescription = stringResource(R.string.save),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = stringResource(R.string.save),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Share button
                Button(
                    onClick = {
                        if (isGeneratingImage) return@Button
                        isGeneratingImage = true
                        coroutineScope.launch(Dispatchers.IO) {
                            try {
                                val image = ComposeToImage.createLyricsImage(
                                    context = context,
                                    mediaMetadata = mediaMetadata,
                                    lyrics = lyrics,
                                    backgroundStyle = LyricsBackgroundStyle.BLUR,
                                    backgroundColor = android.graphics.Color.TRANSPARENT,
                                    textColor = android.graphics.Color.WHITE,
                                    secondaryTextColor = android.graphics.Color.WHITE,
                                    lyricsAlignment = Layout.Alignment.ALIGN_NORMAL
                                )
                                val timestamp = System.currentTimeMillis()
                                val filename = "lyrics_$timestamp"
                                val uri = ComposeToImage.saveBitmapAsFile(context, image, filename)
                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "image/png"
                                    putExtra(Intent.EXTRA_STREAM, uri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(
                                    Intent.createChooser(
                                        shareIntent,
                                        context.getString(R.string.share_lyrics)
                                    )
                                )
                            } catch (e: Exception) {
                                withContext(Dispatchers.Main) {
                                    Toast.makeText(
                                        context,
                                        context.getString(R.string.failed_to_create_image, e.message),
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            } finally {
                                isGeneratingImage = false
                            }
                        }
                    },
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp),
                    enabled = !isGeneratingImage
                ) {
                    if (isGeneratingImage) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            color = MaterialTheme.colorScheme.onPrimary,
                            strokeWidth = 2.5.dp
                        )
                    } else {
                        Icon(
                            painter = painterResource(id = R.drawable.share),
                            contentDescription = stringResource(R.string.share),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = stringResource(R.string.share),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

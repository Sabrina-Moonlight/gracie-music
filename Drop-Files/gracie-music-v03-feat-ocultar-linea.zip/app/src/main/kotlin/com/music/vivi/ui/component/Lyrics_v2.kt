/**
 * vivimusic Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */
package com.music.vivi.ui.component

import android.annotation.SuppressLint
import android.app.Activity
import android.view.WindowManager
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.material3.ContainedLoadingIndicator
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier

import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import android.widget.Toast
import com.music.vivi.LocalDatabase
import com.music.vivi.LocalPlayerConnection
import com.music.vivi.utils.rememberPreference
import com.music.vivi.constants.*
import androidx.compose.foundation.shape.RoundedCornerShape
import com.music.vivi.R
import com.music.vivi.db.entities.LyricsEntity
import com.music.vivi.db.entities.LyricsEntity.Companion.LYRICS_NOT_FOUND
import com.music.vivi.lyrics.LyricsEntry
import com.music.vivi.lyrics.LyricsUtils
import com.music.vivi.models.MediaMetadata
import com.music.vivi.ui.component.MetroLyricsLine
import com.music.vivi.ui.screens.settings.LyricsPosition
import dagger.hilt.android.EntryPointAccessors
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.gestures.awaitVerticalTouchSlopOrCancellation
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.zIndex
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import android.content.Intent
import android.text.Layout
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.combinedClickable
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.draw.clip
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import com.music.vivi.utils.ComposeToImage
import com.music.vivi.ui.component.LyricsImageCard
import com.music.vivi.ui.component.LyricsBackgroundStyle

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.verticalDrag
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.animation.core.exponentialDecay
import androidx.compose.animation.core.AnimationState
import androidx.compose.animation.core.animateDecay
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.Animatable
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.sp
import com.music.vivi.ui.utils.fadingEdge
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.first
import kotlin.math.roundToInt

// Fraction of the player height (from the top) where the active lyric line sits.
private const val LYRICS_ANCHOR_RATIO = 0.40f
// Higher position used while the player controls are visible, so lyrics stay readable.
private const val LYRICS_ANCHOR_RATIO_CONTROLS_VISIBLE = 0.28f
private val LYRICS_ITEM_FALLBACK_HEIGHT_DP = 68.dp
private val LYRICS_ITEM_GAP_DP = 16.dp
// Tiempo que sigue visible una letra secundaria después de que termina (ms).
private const val LYRICS_BG_LINGER_MS = 300L

@Composable
private fun rememberLingerVisible(visible: Boolean, lingerMs: Long): Boolean {
    var shown by remember { mutableStateOf(visible) }
    LaunchedEffect(visible) {
        if (visible) shown = true else {
            kotlinx.coroutines.delay(lingerMs)
            shown = false
        }
    }
    return visible || shown
}
private val LYRICS_FADE_TOP_DP = 130.dp
private val LYRICS_FADE_BOTTOM_DP = 160.dp
private const val LYRICS_STAGGER_DELAY_PER_DISTANCE = 20
private const val LYRICS_STAGGER_DELAY_MAX_MS = 200
private val INSTRUMENTAL_REGEX = Regex("^[.\\s…~♪\\-—•*·]+$")

private fun String.isInstrumentalPlaceholder(): Boolean {
    val trimmed = this.trim()
    return trimmed.isEmpty() || INSTRUMENTAL_REGEX.matches(trimmed)
}

sealed class LyricsListItemV2 {
    data class Line(val index: Int, val entry: LyricsEntry) : LyricsListItemV2()
    data class Indicator(
        val afterLineIndex: Int,
        val gapMs: Long,
        val gapStartMs: Long,
        val gapEndMs: Long
    ) : LyricsListItemV2()
}

@OptIn(ExperimentalMaterial3ExpressiveApi::class, ExperimentalMaterial3Api::class)
@SuppressLint("UnusedBoxWithConstraintsScope")
@Composable
fun LyricsV2(
    mediaMetadata: MediaMetadata?,
    showLyrics: Boolean,
    positionProvider: () -> Long,
    sliderPositionProvider: () -> Long? = { null },
    modifier: Modifier = Modifier,
    contentPadding: PaddingValues = PaddingValues(0.dp),
    playerCoordinates: LayoutCoordinates? = null,
    onControlsVisibilityChange: (Boolean) -> Unit = {},
    controlsVisible: Boolean = false,
    // El reproductor pide ocultar los controles: se ocultan cuando termina la línea que suena
    // (justo al empezar la siguiente o el círculo de espera), no a mitad de la línea.
    hideControlsRequested: Boolean = false
) {
    if (!showLyrics) return

    val playerConnection = LocalPlayerConnection.current ?: return

    var isSelectionModeActive by remember { mutableStateOf(false) }
    val selectedIndices = remember { mutableStateListOf<Int>() }
    var showShareSheet by remember { mutableStateOf(false) }
    val haptic = LocalHapticFeedback.current

    val toggleSelection: (Int) -> Unit = { index ->
        if (selectedIndices.contains(index)) {
            selectedIndices.remove(index)
            if (selectedIndices.isEmpty()) {
                isSelectionModeActive = false
                onControlsVisibilityChange(true)
            }
        } else {
            selectedIndices.add(index)
        }
    }

    val startSelection: (Int) -> Unit = { index ->
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        if (!isSelectionModeActive) {
            isSelectionModeActive = true
            selectedIndices.clear()
            selectedIndices.add(index)
            onControlsVisibilityChange(false)
        } else {
            toggleSelection(index)
        }
    }

    val exitSelection: () -> Unit = {
        isSelectionModeActive = false
        selectedIndices.clear()
        onControlsVisibilityChange(true)
    }

    BackHandler(enabled = isSelectionModeActive) {
        exitSelection()
    }

    LaunchedEffect(mediaMetadata?.id) {
        if (isSelectionModeActive) {
            exitSelection()
        }
    }
    val cacheContext = LocalContext.current
    // Empieza con la letra guardada de la última canción: así no sale el círculo de carga al abrir la app.
    val currentLyrics by playerConnection.currentLyrics.collectAsState(
        initial = remember { com.music.vivi.lyrics.LastLyricsCache.lyricsFor(cacheContext, mediaMetadata?.id) }
    )
    
    val isGuest = false

    val scrollLyrics by rememberPreference(LyricsScrollKey, true)
    
    val romanizeJapaneseLyrics by rememberPreference(LyricsRomanizeJapaneseKey, true)
    val romanizeKoreanLyrics by rememberPreference(LyricsRomanizeKoreanKey, true)
    val romanizeRussianLyrics by rememberPreference(LyricsRomanizeRussianKey, true)
    val romanizeUkrainianLyrics by rememberPreference(LyricsRomanizeUkrainianKey, true)
    val romanizeSerbianLyrics by rememberPreference(LyricsRomanizeSerbianKey, true)
    val romanizeBulgarianLyrics by rememberPreference(LyricsRomanizeBulgarianKey, true)
    val romanizeBelarusianLyrics by rememberPreference(LyricsRomanizeBelarusianKey, true)
    val romanizeKyrgyzLyrics by rememberPreference(LyricsRomanizeKyrgyzKey, true)
    val romanizeMacedonianLyrics by rememberPreference(LyricsRomanizeMacedonianKey, true)
    val romanizeCyrillicByLine by rememberPreference(LyricsRomanizeCyrillicByLineKey, false)
    val romanizeAsMain by rememberPreference(LyricsRomanizeAsMainKey, false)
    val romanizeChineseLyrics by rememberPreference(LyricsRomanizeChineseKey, true)
    val romanizeHindiLyrics by rememberPreference(LyricsRomanizeHindiKey, true)
    val romanizePunjabiLyrics by rememberPreference(LyricsRomanizePunjabiKey, true)

    val playerBackground by com.music.vivi.utils.rememberEnumPreference(
        key = com.music.vivi.constants.PlayerBackgroundStyleKey,
        defaultValue = com.music.vivi.constants.PlayerBackgroundStyle.GRADIENT
    )

    val adaptivePrimary =
        if (playerBackground == com.music.vivi.constants.PlayerBackgroundStyle.DEFAULT) MaterialTheme.colorScheme.onSurface else Color.White
    val lyrics = remember(currentLyrics) { currentLyrics?.lyrics?.trim() }
    val context = LocalContext.current
    val database = LocalDatabase.current
    val coroutineScope = rememberCoroutineScope()
    val currentSong by playerConnection.currentSong.collectAsState(initial = null)
    val lyricsOffset = (currentSong?.song?.lyricsOffset ?: 0).toLong()
    val showRomanized = currentSong?.song?.romanizeLyrics ?: true

    // Keep screen on while lyrics are visible
    DisposableEffect(showLyrics) {
        val activity = context as? Activity
        if (showLyrics) {
            activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        onDispose {
            activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    LaunchedEffect(currentLyrics, mediaMetadata?.id) {
        val entry = currentLyrics
        val meta = mediaMetadata
        if (entry != null && meta != null && entry.id == meta.id) {
            com.music.vivi.lyrics.LastLyricsCache.save(cacheContext, entry.id, entry.lyrics, entry.provider, meta.thumbnailUrl)
        }
    }

    LaunchedEffect(mediaMetadata?.id, currentLyrics) {
        if (mediaMetadata != null && currentLyrics == null) {
            delay(500)
            coroutineScope.launch(Dispatchers.IO) {
                try {
                    val entryPoint = EntryPointAccessors.fromApplication(
                        context.applicationContext,
                        com.music.vivi.di.LyricsHelperEntryPoint::class.java
                    )
                    val lyricsHelper = entryPoint.lyricsHelper()
                    val fetchedLyricsWithProvider = lyricsHelper.getLyrics(mediaMetadata)
                    database.query {
                        upsert(
                            LyricsEntity(
                                mediaMetadata.id,
                                fetchedLyricsWithProvider.lyrics,
                                fetchedLyricsWithProvider.provider
                            )
                        )
                    }
                } catch (e: Exception) {
                    // Handle error silently
                }
            }
        }
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        when {
            lyrics == null -> {
                ContainedLoadingIndicator()
            }

            lyrics == LYRICS_NOT_FOUND -> {
                Text(
                    text = "Lyrics not found",
                    style = MaterialTheme.typography.bodyLarge,
                    color = adaptivePrimary.copy(alpha = 0.5f)
                )
            }

            else -> {
                val lines = remember(lyrics, coroutineScope) {
                  try {
                    if (lyrics.startsWith("[")) {
                        val parsedLines = LyricsUtils.parseLyrics(lyrics)

                        val isRussianLyrics = romanizeRussianLyrics && !romanizeCyrillicByLine && LyricsUtils.isRussian(lyrics)
                        val isUkrainianLyrics = romanizeUkrainianLyrics && !romanizeCyrillicByLine && LyricsUtils.isUkrainian(lyrics)
                        val isSerbianLyrics = romanizeSerbianLyrics && !romanizeCyrillicByLine && LyricsUtils.isSerbian(lyrics)
                        val isBulgarianLyrics = romanizeBulgarianLyrics && !romanizeCyrillicByLine && LyricsUtils.isBulgarian(lyrics)
                        val isBelarusianLyrics = romanizeBelarusianLyrics && !romanizeCyrillicByLine && LyricsUtils.isBelarusian(lyrics)
                        val isKyrgyzLyrics = romanizeKyrgyzLyrics && !romanizeCyrillicByLine && LyricsUtils.isKyrgyz(lyrics)
                        val isMacedonianLyrics = romanizeMacedonianLyrics && !romanizeCyrillicByLine && LyricsUtils.isMacedonian(lyrics)

                        parsedLines.map { entry ->
                            val cleanText = if (entry.text.isInstrumentalPlaceholder()) "" else entry.text
                            val newEntry = LyricsEntry(entry.time, cleanText, entry.words, agent = entry.agent, isBackground = entry.isBackground)

                            if (romanizeJapaneseLyrics && LyricsUtils.isJapanese(entry.text) && !LyricsUtils.isChinese(entry.text)) {
                                coroutineScope.launch(Dispatchers.Default) { newEntry.romanizedTextFlow.value = LyricsUtils.romanizeJapanese(entry.text) }
                            }
                            if (romanizeKoreanLyrics && LyricsUtils.isKorean(entry.text)) {
                                coroutineScope.launch(Dispatchers.Default) { newEntry.romanizedTextFlow.value = LyricsUtils.romanizeKorean(entry.text) }
                            }
                            if (romanizeRussianLyrics && (if (romanizeCyrillicByLine) LyricsUtils.isRussian(entry.text) else isRussianLyrics)) {
                                coroutineScope.launch(Dispatchers.Default) { newEntry.romanizedTextFlow.value = LyricsUtils.romanizeCyrillic(entry.text) }
                            }
                            else if (romanizeUkrainianLyrics && (if (romanizeCyrillicByLine) LyricsUtils.isUkrainian(entry.text) else isUkrainianLyrics)) {
                                coroutineScope.launch(Dispatchers.Default) { newEntry.romanizedTextFlow.value = LyricsUtils.romanizeCyrillic(entry.text) }
                            }
                            else if (romanizeSerbianLyrics && (if (romanizeCyrillicByLine) LyricsUtils.isSerbian(entry.text) else isSerbianLyrics)) {
                                coroutineScope.launch(Dispatchers.Default) { newEntry.romanizedTextFlow.value = LyricsUtils.romanizeCyrillic(entry.text) }
                            }
                            else if (romanizeBulgarianLyrics && (if (romanizeCyrillicByLine) LyricsUtils.isBulgarian(entry.text) else isBulgarianLyrics)) {
                                coroutineScope.launch(Dispatchers.Default) { newEntry.romanizedTextFlow.value = LyricsUtils.romanizeCyrillic(entry.text) }
                            }
                            else if (romanizeBelarusianLyrics && (if (romanizeCyrillicByLine) LyricsUtils.isBelarusian(entry.text) else isBelarusianLyrics)) {
                                coroutineScope.launch(Dispatchers.Default) { newEntry.romanizedTextFlow.value = LyricsUtils.romanizeCyrillic(entry.text) }
                            }
                            else if (romanizeKyrgyzLyrics && (if (romanizeCyrillicByLine) LyricsUtils.isKyrgyz(entry.text) else isKyrgyzLyrics)) {
                                coroutineScope.launch(Dispatchers.Default) { newEntry.romanizedTextFlow.value = LyricsUtils.romanizeCyrillic(entry.text) }
                            }
                            else if (romanizeMacedonianLyrics && (if (romanizeCyrillicByLine) LyricsUtils.isMacedonian(entry.text) else isMacedonianLyrics)) {
                                coroutineScope.launch(Dispatchers.Default) { newEntry.romanizedTextFlow.value = LyricsUtils.romanizeCyrillic(entry.text) }
                            }
                            else if (romanizeChineseLyrics && LyricsUtils.isChinese(entry.text)) {
                                coroutineScope.launch(Dispatchers.Default) { newEntry.romanizedTextFlow.value = LyricsUtils.romanizeChinese(entry.text) }
                            }
                            else if (romanizeHindiLyrics && LyricsUtils.isHindi(entry.text)) {
                                coroutineScope.launch(Dispatchers.Default) { newEntry.romanizedTextFlow.value = LyricsUtils.romanizeHindi(entry.text) }
                            }
                            else if (romanizePunjabiLyrics && LyricsUtils.isPunjabi(entry.text)) {
                                coroutineScope.launch(Dispatchers.Default) { newEntry.romanizedTextFlow.value = LyricsUtils.romanizePunjabi(entry.text) }
                            }
                            newEntry
                        }.let {
                            listOf(LyricsEntry.HEAD_LYRICS_ENTRY) + it
                        }
                    } else {
                        val isRussianLyrics = romanizeRussianLyrics && !romanizeCyrillicByLine && LyricsUtils.isRussian(lyrics)
                        val isUkrainianLyrics = romanizeUkrainianLyrics && !romanizeCyrillicByLine && LyricsUtils.isUkrainian(lyrics)
                        val isSerbianLyrics = romanizeSerbianLyrics && !romanizeCyrillicByLine && LyricsUtils.isSerbian(lyrics)
                        val isBulgarianLyrics = romanizeBulgarianLyrics && !romanizeCyrillicByLine && LyricsUtils.isBulgarian(lyrics)
                        val isBelarusianLyrics = romanizeBelarusianLyrics && !romanizeCyrillicByLine && LyricsUtils.isBelarusian(lyrics)
                        val isKyrgyzLyrics = romanizeKyrgyzLyrics && !romanizeCyrillicByLine && LyricsUtils.isKyrgyz(lyrics)
                        val isMacedonianLyrics = romanizeMacedonianLyrics && !romanizeCyrillicByLine && LyricsUtils.isMacedonian(lyrics)

                        lyrics.split("\n").mapIndexed { index, line ->
                            val cleanText = if (line.isInstrumentalPlaceholder()) "" else line
                            val newEntry = LyricsEntry(index * 100L, cleanText, emptyList())

                            if (romanizeJapaneseLyrics && LyricsUtils.isJapanese(line) && !LyricsUtils.isChinese(line)) {
                                coroutineScope.launch(Dispatchers.Default) { newEntry.romanizedTextFlow.value = LyricsUtils.romanizeJapanese(line) }
                            }
                            if (romanizeKoreanLyrics && LyricsUtils.isKorean(line)) {
                                coroutineScope.launch(Dispatchers.Default) { newEntry.romanizedTextFlow.value = LyricsUtils.romanizeKorean(line) }
                            }
                            if (romanizeRussianLyrics && (if (romanizeCyrillicByLine) LyricsUtils.isRussian(line) else isRussianLyrics)) {
                                coroutineScope.launch(Dispatchers.Default) { newEntry.romanizedTextFlow.value = LyricsUtils.romanizeCyrillic(line) }
                            }
                            else if (romanizeUkrainianLyrics && (if (romanizeCyrillicByLine) LyricsUtils.isUkrainian(line) else isUkrainianLyrics)) {
                                coroutineScope.launch(Dispatchers.Default) { newEntry.romanizedTextFlow.value = LyricsUtils.romanizeCyrillic(line) }
                            }
                            else if (romanizeSerbianLyrics && (if (romanizeCyrillicByLine) LyricsUtils.isSerbian(line) else isSerbianLyrics)) {
                                coroutineScope.launch(Dispatchers.Default) { newEntry.romanizedTextFlow.value = LyricsUtils.romanizeCyrillic(line) }
                            }
                            else if (romanizeBulgarianLyrics && (if (romanizeCyrillicByLine) LyricsUtils.isBulgarian(line) else isBulgarianLyrics)) {
                                coroutineScope.launch(Dispatchers.Default) { newEntry.romanizedTextFlow.value = LyricsUtils.romanizeCyrillic(line) }
                            }
                            else if (romanizeBelarusianLyrics && (if (romanizeCyrillicByLine) LyricsUtils.isBelarusian(line) else isBelarusianLyrics)) {
                                coroutineScope.launch(Dispatchers.Default) { newEntry.romanizedTextFlow.value = LyricsUtils.romanizeCyrillic(line) }
                            }
                            else if (romanizeKyrgyzLyrics && (if (romanizeCyrillicByLine) LyricsUtils.isKyrgyz(line) else isKyrgyzLyrics)) {
                                coroutineScope.launch(Dispatchers.Default) { newEntry.romanizedTextFlow.value = LyricsUtils.romanizeCyrillic(line) }
                            }
                            else if (romanizeMacedonianLyrics && (if (romanizeCyrillicByLine) LyricsUtils.isMacedonian(line) else isMacedonianLyrics)) {
                                coroutineScope.launch(Dispatchers.Default) { newEntry.romanizedTextFlow.value = LyricsUtils.romanizeCyrillic(line) }
                            }
                            else if (romanizeChineseLyrics && LyricsUtils.isChinese(line)) {
                                coroutineScope.launch(Dispatchers.Default) { newEntry.romanizedTextFlow.value = LyricsUtils.romanizeChinese(line) }
                            }
                            else if (romanizeHindiLyrics && LyricsUtils.isHindi(line)) {
                                coroutineScope.launch(Dispatchers.Default) { newEntry.romanizedTextFlow.value = LyricsUtils.romanizeHindi(line) }
                            }
                            else if (romanizePunjabiLyrics && LyricsUtils.isPunjabi(line)) {
                                coroutineScope.launch(Dispatchers.Default) { newEntry.romanizedTextFlow.value = LyricsUtils.romanizePunjabi(line) }
                            }
                            newEntry
                        }
                    }
                  } catch (e: Exception) {
                      com.music.vivi.utils.reportException(e)
                      emptyList()
                  }
                }
                
                val isLyricsProviderShown = currentLyrics?.provider != null && currentLyrics?.provider != "Unknown"

                // If plain text (not synced), render selectable list
                if (lines.isNotEmpty() && lines.all { it.time == 0L }) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(
                                top = 32.dp,
                                bottom = if (isSelectionModeActive) 140.dp else 120.dp,
                                start = 24.dp,
                                end = 24.dp
                            )
                        ) {
                            if (isLyricsProviderShown) {
                                item {
                                    Text(
                                        text = "Lyrics from ${currentLyrics?.provider}",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = adaptivePrimary.copy(alpha = 0.6f),
                                        fontWeight = FontWeight.Medium,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(bottom = 12.dp)
                                    )
                                }
                            }
                            items(lines.size) { index ->
                                val lineText = lines[index].text
                                if (lineText.isBlank() || lineText.isInstrumentalPlaceholder()) return@items
                                val isSelected = selectedIndices.contains(index)
                                Text(
                                    text = lineText,
                                    style = MaterialTheme.typography.headlineSmall,
                                    color = if (isSelected && isSelectionModeActive) MaterialTheme.colorScheme.primary else adaptivePrimary,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .combinedClickable(
                                            onClick = {
                                                if (isSelectionModeActive) {
                                                    toggleSelection(index)
                                                }
                                            },
                                            onLongClick = {
                                                startSelection(index)
                                            }
                                        )
                                        .background(
                                            if (isSelected && isSelectionModeActive)
                                                MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                                            else Color.Transparent
                                        )
                                        .padding(horizontal = 16.dp, vertical = 8.dp),
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Start
                                )
                            }
                        }

                        LyricsSelectionFloatingBox(
                            visible = isSelectionModeActive,
                            selectedCount = selectedIndices.size,
                            onCancel = exitSelection,
                            onShare = {
                                if (selectedIndices.isNotEmpty()) {
                                    showShareSheet = true
                                }
                            },
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(bottom = 24.dp)
                                .zIndex(10f)
                        )
                    }

                    if (showShareSheet && mediaMetadata != null) {
                        val selectedLyricsText = selectedIndices.sorted()
                            .mapNotNull { lines.getOrNull(it)?.text }
                            .joinToString("\n")

                        LyricsShareBottomSheet(
                            mediaMetadata = mediaMetadata,
                            lyrics = selectedLyricsText,
                            onDismissRequest = {
                                showShareSheet = false
                            }
                        )
                    }
                    return
                }

                val initialPos = remember { positionProvider() }
                val initialActiveLine = remember(lines, initialPos, lyricsOffset) {
                    if (lines.isNotEmpty()) {
                        LyricsUtils.findActiveLineIndices(lines, initialPos + lyricsOffset).maxOrNull() ?: 0
                    } else 0
                }
                var currentPlaybackPosition by remember { mutableLongStateOf(initialPos) }
                var currentLineIndex by remember { mutableIntStateOf(initialActiveLine) }
                var activeLineIndices by remember {
                    mutableStateOf(if (lines.isNotEmpty()) LyricsUtils.findActiveLineIndices(lines, initialPos + lyricsOffset) else emptySet())
                }
                // After tapping a lyric line: time of the tap (0 = not waiting) and the
                // position we jumped to. Lines stay unlit until the sound really advances.
                var awaitingSeekSince by remember { mutableLongStateOf(0L) }
                var awaitingSeekTarget by remember { mutableLongStateOf(0L) }
                var deferredCurrentLineIndex by rememberSaveable { mutableIntStateOf(initialActiveLine) }
                var scrollTargetIndex by rememberSaveable { mutableIntStateOf(initialActiveLine) }
                var previousScrollActiveIndices by remember { mutableStateOf(emptySet<Int>()) }
                var lastMainMaxSeen by remember(lyrics, lines) { mutableIntStateOf(initialActiveLine) }
                var isSeeking by remember { mutableStateOf(false) }
                var isAutoScrollEnabled by rememberSaveable { mutableStateOf(scrollLyrics) }
                var lastPreviewTime by rememberSaveable { mutableLongStateOf(0L) }

                val mergedLyricsList = remember(lines) {
                    val result = mutableListOf<LyricsListItemV2>()
                    if (lines.isEmpty()) return@remember result

                    lines.forEachIndexed { i, entry ->
                        val isPlaceholder = entry.text.isBlank() || entry.text.isInstrumentalPlaceholder()
                        if (!isPlaceholder) {
                            result.add(LyricsListItemV2.Line(i, entry))
                        }
                        if (i < lines.size - 1) {
                            val nextStart = lines[i + 1].time
                            val currentEnd = if (!entry.words.isNullOrEmpty()) {
                                (entry.words.last().endTime * 1000).toLong()
                            } else if (isPlaceholder) {
                                entry.time
                            } else {
                                val estimatedDuration = (entry.text.length * 200L).coerceIn(2000L, 4500L)
                                if (nextStart - entry.time > estimatedDuration + 4000L) {
                                    entry.time + estimatedDuration
                                } else {
                                    null
                                }
                            }

                            if (currentEnd != null && currentEnd < nextStart) {
                                val gap = nextStart - currentEnd
                                if (gap > 4000L) {
                                    result.add(
                                        LyricsListItemV2.Indicator(
                                            afterLineIndex = i,
                                            gapMs = gap,
                                            gapStartMs = currentEnd,
                                            gapEndMs = nextStart
                                        )
                                    )
                                }
                            }
                        }
                    }
                    // Intro largo (p. ej. tras quitar créditos): círculo de espera desde el inicio
                    // de la canción hasta la primera letra real.
                    val firstItem = result.firstOrNull() as? LyricsListItemV2.Line
                    if (firstItem != null && firstItem.entry.time > 4000L) {
                        result.add(
                            0,
                            LyricsListItemV2.Indicator(
                                afterLineIndex = -1,
                                gapMs = firstItem.entry.time,
                                gapStartMs = 0L,
                                gapEndMs = firstItem.entry.time
                            )
                        )
                    }
                    result
                }

                val activeListIndex by remember(mergedLyricsList, deferredCurrentLineIndex, currentPlaybackPosition) {
                    derivedStateOf {
                        val activeIndicatorIndex = mergedLyricsList.indexOfFirst {
                            it is LyricsListItemV2.Indicator &&
                                currentPlaybackPosition >= it.gapStartMs &&
                                currentPlaybackPosition <= it.gapEndMs - 650L
                        }
                        if (activeIndicatorIndex != -1) {
                            activeIndicatorIndex
                        } else {
                            mergedLyricsList.indexOfFirst {
                                (it is LyricsListItemV2.Line && it.index == deferredCurrentLineIndex) ||
                                (it is LyricsListItemV2.Indicator && it.afterLineIndex == deferredCurrentLineIndex)
                            }.coerceAtLeast(0)
                        }
                    }
                }

                LaunchedEffect(hideControlsRequested) {
                    if (!hideControlsRequested) return@LaunchedEffect
                    val indexWhenRequested = activeListIndex
                    snapshotFlow { activeListIndex }.first { it != indexWhenRequested }
                    onControlsVisibilityChange(false)
                }

                var userManualOffset by remember { mutableFloatStateOf(0f) }
                var flingJob by remember { mutableStateOf<kotlinx.coroutines.Job?>(null) }
                val velocityTracker = remember { VelocityTracker() }
                val decayAnimSpec = remember { exponentialDecay<Float>(frictionMultiplier = 1.8f) }
                val itemHeights = remember(lyrics, mergedLyricsList) { mutableStateMapOf<Int, Int>() }
                var isInitialLayout by remember(lyrics, mergedLyricsList) { mutableStateOf(true) }
                val contentAlpha by animateFloatAsState(
                    targetValue = if (isInitialLayout) 0f else 1f,
                    animationSpec = tween(durationMillis = 200, easing = FastOutSlowInEasing),
                    label = "lyricContentAlpha"
                )

                LaunchedEffect(showLyrics, lyrics, mergedLyricsList.size) {
                    if (showLyrics && mergedLyricsList.isNotEmpty()) {
                        isInitialLayout = true
                        snapshotFlow {
                            val h = itemHeights.toMap()
                            val windowStart = (activeListIndex - 8).coerceAtLeast(0)
                            val windowEnd = (activeListIndex + 12).coerceAtMost(mergedLyricsList.size - 1)
                            (windowStart..windowEnd).all { h.containsKey(it) }
                        }.first { it }
                        delay(16)
                        isInitialLayout = false
                    }
                }

                LaunchedEffect(activeListIndex) {
                    if (mergedLyricsList.isNotEmpty()) {
                        val h = itemHeights.toMap()
                        val windowStart = (activeListIndex - 3).coerceAtLeast(0)
                        val windowEnd = (activeListIndex + 3).coerceAtMost(mergedLyricsList.size - 1)
                        val needsMeasurement = (windowStart..windowEnd).any { !h.containsKey(it) }
                        if (needsMeasurement) {
                            isInitialLayout = true
                            snapshotFlow {
                                val hh = itemHeights.toMap()
                                (windowStart..windowEnd).all { hh.containsKey(it) }
                            }.first { it }
                            isInitialLayout = false
                        }
                    }
                }

                LaunchedEffect(lyrics, lines) {
                    isAutoScrollEnabled = scrollLyrics
                    val pos = positionProvider()
                    val active = if (lines.isNotEmpty()) {
                        LyricsUtils.findActiveLineIndices(lines, pos + lyricsOffset).maxOrNull() ?: 0
                    } else 0
                    scrollTargetIndex = active
                    currentLineIndex = active
                    deferredCurrentLineIndex = active
                    previousScrollActiveIndices = emptySet()
                    lastMainMaxSeen = active
                    userManualOffset = 0f
                }

                LaunchedEffect(lyrics, lines) {
                    if (lyrics.isNullOrEmpty() || !lyrics.startsWith("[")) {
                        currentLineIndex = -1
                        activeLineIndices = emptySet()
                        return@LaunchedEffect
                    }
                    var lastPlayerPos = playerConnection.player.currentPosition
                    var lastUpdateTime = System.currentTimeMillis()
                    var lastPlaybackPosition = lastPlayerPos
                    val hasWordTimings = lines.any { !it.words.isNullOrEmpty() }

                    while (isActive) {
                        withFrameNanos { _ -> }
                        val now = System.currentTimeMillis()

                        // After tapping a line the player already reports the new position while
                        // it is still loading, which lit lines (sometimes several) before any
                        // sound. Wait until the position moves forward by itself, i.e. the sound
                        // is really coming out. Paused = nothing to wait for. 4 s safety limit.
                        if (awaitingSeekSince != 0L) {
                            val p = playerConnection.player
                            val soundAdvancing = p.isPlaying &&
                                p.currentPosition - awaitingSeekTarget >= 150L
                            if (!p.playWhenReady || soundAdvancing || now - awaitingSeekSince > 4000L) {
                                awaitingSeekSince = 0L
                                lastPlayerPos = p.currentPosition
                                lastUpdateTime = now
                            } else {
                                activeLineIndices = emptySet()
                                continue
                            }
                        }

                        val sliderPos = sliderPositionProvider()
                        isSeeking = sliderPos != null

                        val position = if (isSeeking) {
                            sliderPos!!
                        } else {
                            val providerPos = positionProvider()
                            val playerPos = playerConnection.player.currentPosition
                            val isPlaying = playerConnection.player.isPlaying
                            if (kotlin.math.abs(providerPos - playerPos) > 1000L) {
                                lastPlayerPos = playerPos
                                lastUpdateTime = now
                                providerPos
                            } else {
                                if (playerPos != lastPlayerPos || !isPlaying) {
                                    lastPlayerPos = playerPos
                                    lastUpdateTime = now
                                }
                                val elapsed = now - lastUpdateTime
                                lastPlayerPos + (if (isPlaying) elapsed else 0L)
                            }
                        }

                        currentPlaybackPosition = position
                        val effectivePosition = position + lyricsOffset

                        val initialActiveIndices = LyricsUtils.findActiveLineIndices(lines, effectivePosition)
                        val scrollActiveIndicesRaw = LyricsUtils.findActiveLineIndices(lines, effectivePosition + (if (hasWordTimings) 0L else 250L))

                        // La voz de fondo solo mantiene activa a su línea principal si no hay ya una
                        // línea principal posterior sonando; si no, la letra se queda "pegada" arriba.
                        val scrollMainMax = scrollActiveIndicesRaw
                            .filter { lines.getOrNull(it)?.isBackground == false }
                            .maxOrNull() ?: -1
                        val scrollActiveIndices = scrollActiveIndicesRaw.toMutableSet()
                        for (i in scrollActiveIndicesRaw) {
                            if (lines.getOrNull(i)?.isBackground == true) {
                                for (j in i - 1 downTo 0) {
                                    if (lines.getOrNull(j)?.isBackground == false) {
                                        if (j > scrollMainMax) scrollActiveIndices.add(j)
                                        break
                                    }
                                }
                            }
                        }

                        val activeMainMax = initialActiveIndices
                            .filter { lines.getOrNull(it)?.isBackground == false }
                            .maxOrNull() ?: -1
                        val newActiveIndices = initialActiveIndices.toMutableSet()
                        for (i in initialActiveIndices) {
                            if (lines.getOrNull(i)?.isBackground == true) {
                                for (j in i - 1 downTo 0) {
                                    if (lines.getOrNull(j)?.isBackground == false) {
                                        if (j > activeMainMax) newActiveIndices.add(j)
                                        break
                                    }
                                }
                            }
                        }

                        val scrollMax = scrollActiveIndices
                            .filter { !it.let { lines[it].isBackground } }
                            .maxOrNull() ?: (scrollActiveIndices.maxOrNull() ?: -1)

                        // Detect seek backwards or slider scrub
                        val isBackwardSeek = position < lastPlaybackPosition - 1500L
                        if (isSeeking || isBackwardSeek) {
                            lastMainMaxSeen = scrollMax
                            if (scrollMax != -1) {
                                scrollTargetIndex = scrollMax
                                deferredCurrentLineIndex = scrollMax
                            }
                        }
                        lastPlaybackPosition = position

                        val isCurrentTargetStillActive = scrollTargetIndex in scrollActiveIndices
                        val anyStillActive = scrollActiveIndices.isNotEmpty()

                        // Al abrir las letras en un hueco (nada sonando todavía) no hay ninguna línea
                        // activa y las letras se quedaban arriba. Aquí se baja a la línea que viene
                        // (o a la última si la canción ya terminó de cantarse).
                        if (scrollTargetIndex == -1 && !anyStillActive && !isSeeking && lines.isNotEmpty()) {
                            val passed = lines.indexOfLast { it.time <= effectivePosition }
                            val upcoming = (passed + 1 until lines.size).firstOrNull { i ->
                                val l = lines[i]
                                !l.isBackground && l.text.isNotBlank() && !l.text.isInstrumentalPlaceholder()
                            } ?: passed.takeIf { it >= 0 }
                            if (upcoming != null) {
                                lastMainMaxSeen = passed
                                scrollTargetIndex = upcoming
                                deferredCurrentLineIndex = upcoming
                            }
                        }

                        val shouldScroll = when {
                            isSeeking -> true
                            // Una línea nueva ya suena aunque la anterior siga activa por su voz de fondo: bajar igual.
                            scrollMax > scrollTargetIndex && anyStillActive -> true
                            !isCurrentTargetStillActive && anyStillActive && scrollMax > scrollTargetIndex -> true
                            !isCurrentTargetStillActive && !anyStillActive && previousScrollActiveIndices.isNotEmpty() -> true
                            scrollTargetIndex == -1 && anyStillActive -> true
                            previousScrollActiveIndices.isEmpty() && anyStillActive && scrollMax > scrollTargetIndex -> true
                            else -> false
                        }

                        if (shouldScroll) {
                            val targetToScroll = when {
                                isSeeking -> scrollMax
                                !isCurrentTargetStillActive && anyStillActive -> scrollMax
                                !isCurrentTargetStillActive && !anyStillActive -> {
                                    (lastMainMaxSeen + 1 until lines.size).firstOrNull {
                                        !it.let { lines[it].isBackground }
                                    } ?: scrollTargetIndex
                                }
                                else -> scrollMax
                            }
                            if (targetToScroll != -1 && (isSeeking || targetToScroll > scrollTargetIndex || isBackwardSeek)) {
                                scrollTargetIndex = targetToScroll
                                if (isSeeking) {
                                    deferredCurrentLineIndex = targetToScroll
                                }
                            }
                        }

                        if (scrollMax > lastMainMaxSeen && scrollMax != -1) {
                            lastMainMaxSeen = scrollMax
                        }

                        previousScrollActiveIndices = scrollActiveIndices
                        activeLineIndices = newActiveIndices
                        currentLineIndex = scrollMax
                    }
                }

                LaunchedEffect(scrollTargetIndex, isAutoScrollEnabled) {
                    if (scrollTargetIndex != -1 && isAutoScrollEnabled) {
                        deferredCurrentLineIndex = scrollTargetIndex
                    }
                }

                // When user is slider-seeking, force auto-scroll immediately.
                LaunchedEffect(isSeeking) {
                    if (isSeeking) {
                        lastPreviewTime = 0L
                        isAutoScrollEnabled = true
                    }
                }

                // Auto-resync: after the user stops manually scrolling for 5 seconds,
                // re-enable auto-scroll so lyrics snap back to the current line.
                // collectLatest ensures each new drag cancels any in-progress 5s countdown.
                LaunchedEffect(isAutoScrollEnabled) {
                    if (!isAutoScrollEnabled) {
                        snapshotFlow { lastPreviewTime }
                            .collectLatest { startTime ->
                                if (startTime != 0L) {
                                    delay(5000L)
                                    lastPreviewTime = 0L
                                    isAutoScrollEnabled = true
                                }
                            }
                    }
                }

                val density = LocalDensity.current

                // The lyrics area resizes when the player controls show/hide, so the anchor is
                // measured against the whole player instead, keeping the active line at a fixed height.
                var zoneTopInPlayerPx by remember { mutableFloatStateOf(Float.NaN) }
                var playerHeightPx by remember { mutableFloatStateOf(Float.NaN) }
                // Al inicio de la canción (círculo de espera o primera línea) la letra se queda en la
                // posición alta, con o sin controles, para no dejar un hueco bajo el encabezado.
                // Si la lista empieza con el círculo de espera, "inicio" incluye también la primera letra:
                // así el ancla no cambia cuando termina el círculo y el label no baja.
                val leadingIndicatorFirstLineIdx = if (mergedLyricsList.firstOrNull() is LyricsListItemV2.Indicator) {
                    mergedLyricsList.indexOfFirst { it is LyricsListItemV2.Line }.coerceAtLeast(0)
                } else 0
                val isAtLyricsStart = activeListIndex <= leadingIndicatorFirstLineIdx
                val anchorRatio = if (isAtLyricsStart) LYRICS_ANCHOR_RATIO_CONTROLS_VISIBLE else LYRICS_ANCHOR_RATIO

                BoxWithConstraints(
                    contentAlignment = Alignment.TopCenter,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(bottom = 12.dp)
                        .onGloballyPositioned { zone ->
                            val player = playerCoordinates?.takeIf { it.isAttached }
                                ?: return@onGloballyPositioned
                            val zoneTop = player.localPositionOf(zone, Offset.Zero).y
                            zoneTopInPlayerPx = zoneTop
                            playerHeightPx = player.size.height.toFloat()
                        }
                ) {
                    val maxHeightPx = constraints.maxHeight.toFloat()
                    val lineHeightPx = with(density) { LYRICS_ITEM_FALLBACK_HEIGHT_DP.toPx() }
                    // Con los controles visibles, la zona de letras queda entre el encabezado y la barra
                    // de progreso. La línea activa se centra verticalmente ahí usando su altura real
                    // (1, 2, 3, 4... renglones), para que el bloque quede en el medio y no arriba.
                    val activeItemHeightPx = itemHeights[activeListIndex]?.toFloat()
                        ?: if (mergedLyricsList.getOrNull(activeListIndex) is LyricsListItemV2.Indicator)
                            with(density) { 72.dp.toPx() } else lineHeightPx
                    val centeredAnchorY = (maxHeightPx - activeItemHeightPx) / 2f
                    val hiddenAnchorY = if (zoneTopInPlayerPx.isNaN() || playerHeightPx.isNaN()) maxHeightPx * anchorRatio
                    else playerHeightPx * anchorRatio - zoneTopInPlayerPx
                    // Al mostrar u ocultar los controles, las letras se deslizan de una posición a la otra (antes saltaban de golpe)
                    val controlsBlend by animateFloatAsState(
                        targetValue = if (controlsVisible && !isAtLyricsStart) 1f else 0f,
                        animationSpec = tween(400, easing = FastOutSlowInEasing),
                        label = "lyricsControlsBlend"
                    )
                    val baseAnchorY = hiddenAnchorY + (centeredAnchorY - hiddenAnchorY) * controlsBlend
                    val constraintLineHeightPx = with(density) { 120.dp.toPx() }

                    val positions = remember(itemHeights.toMap(), activeListIndex, mergedLyricsList) {
                        val map = mutableMapOf<Int, Float>()
                        if (activeListIndex == -1 || mergedLyricsList.isEmpty()) return@remember map

                        map[activeListIndex] = 0f
                        var currentY = 0f
                        val indicatorHeightPx = with(density) { 72.dp.toPx() }
                        for (i in activeListIndex - 1 downTo 0) {
                            val item = mergedLyricsList[i]
                            val height = itemHeights[i]?.toFloat() ?: (if (item is LyricsListItemV2.Indicator) indicatorHeightPx else lineHeightPx)
                            val noGap = (item as? LyricsListItemV2.Line)?.entry?.isBackground == true || item is LyricsListItemV2.Indicator
                            currentY -= (height + if (noGap) 0f else with(density) { LYRICS_ITEM_GAP_DP.toPx() })
                            map[i] = currentY
                        }
                        currentY = 0f
                        for (i in activeListIndex until mergedLyricsList.size - 1) {
                            val currentItem = mergedLyricsList[i]
                            val nextItem = mergedLyricsList[i + 1]
                            val height = itemHeights[i]?.toFloat() ?: (if (currentItem is LyricsListItemV2.Indicator) indicatorHeightPx else lineHeightPx)
                            val nextNoGap = (nextItem as? LyricsListItemV2.Line)?.entry?.isBackground == true || nextItem is LyricsListItemV2.Indicator
                            currentY += (height + if (nextNoGap) 0f else with(density) { LYRICS_ITEM_GAP_DP.toPx() })
                            map[i + 1] = currentY
                        }
                        map
                    }

                    // Derive scroll bounds directly from the already-computed positions map.
                    // Each item's screen Y = anchorY + positions[listIndex] + userManualOffset.
                    //
                    // maxOffset (drag DOWN → first item visible near top):
                    //   anchorY + positions[0] + maxOffset = topPad  →  maxOffset = topPad - anchorY - positions[0]
                    //   positions[0] is negative, so maxOffset is positive.
                    //
                    // minOffset (drag UP → last item visible near bottom):
                    //   anchorY + positions[last] + minOffset = maxH - botPad  →  minOffset = maxH - botPad - anchorY - positions[last]
                    //   positions[last] is large positive, so minOffset is negative.
                    val topPad = with(density) { 56.dp.toPx() }
                    val botPad = with(density) { 100.dp.toPx() }
                    val firstPos = if (mergedLyricsList.isEmpty()) 0f
                        else positions.getOrDefault(0, (0 - activeListIndex) * lineHeightPx)
                    val lastPos = if (mergedLyricsList.isEmpty()) 0f
                        else positions.getOrDefault(
                            mergedLyricsList.size - 1,
                            (mergedLyricsList.size - 1 - activeListIndex) * lineHeightPx
                        )

                    // El primer renglón empieza en la zona centrada (el ancla normal), igual que el resto
                    // de la canción. "Lyrics from…" va justo encima del primer renglón y se mueve con las letras.
                    val anchorY = baseAnchorY

                    val scrollClampMax = (topPad - anchorY - firstPos).coerceAtLeast(0f)
                    val scrollClampMin = (maxHeightPx - botPad - anchorY - lastPos).coerceAtMost(0f)


                    LaunchedEffect(scrollClampMin, scrollClampMax) {
                        if (userManualOffset < scrollClampMin || userManualOffset > scrollClampMax) {
                            userManualOffset = userManualOffset.coerceIn(scrollClampMin, scrollClampMax)
                        }
                    }

                    LaunchedEffect(isAutoScrollEnabled, mergedLyricsList.size) {
                        if (isAutoScrollEnabled) {
                            val start = userManualOffset
                            if (kotlin.math.abs(start) < 1f) {
                                userManualOffset = 0f
                                return@LaunchedEffect
                            }
                            // Direct assignment so there's no drift from concurrent fling/drag state
                            val durationMs = (kotlin.math.abs(start) / 3f).toInt().coerceIn(300, 700)
                            val anim = Animatable(start)
                            anim.animateTo(
                                targetValue = 0f,
                                animationSpec = tween(durationMs, easing = FastOutSlowInEasing)
                            ) {
                                userManualOffset = value
                            }
                            userManualOffset = 0f
                        }
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .fadingEdge(top = LYRICS_FADE_TOP_DP, bottom = LYRICS_FADE_BOTTOM_DP)
                            .clipToBounds()
                            .pointerInput(Unit) {
                                coroutineScope {
                                    awaitEachGesture {
                                        val down = awaitFirstDown(requireUnconsumed = false)
                                        flingJob?.cancel()
                                        velocityTracker.resetTracking()
                                        velocityTracker.addPosition(down.uptimeMillis, down.position)

                                        var dragConsumed = false
                                        val applyDrag: (androidx.compose.ui.input.pointer.PointerInputChange, Float) -> Unit = { change, dragAmount ->
                                            velocityTracker.addPosition(change.uptimeMillis, change.position)

                                            val newOffset = userManualOffset + dragAmount
                                            if (newOffset in scrollClampMin..scrollClampMax) {
                                                userManualOffset = newOffset
                                                dragConsumed = true
                                                change.consume()
                                            } else {
                                                val overscroll = if (newOffset < scrollClampMin) newOffset - scrollClampMin else newOffset - scrollClampMax
                                                val friction = 0.35f / (1f + kotlin.math.abs(overscroll) / 300f)
                                                userManualOffset = (userManualOffset + dragAmount * friction).coerceIn(
                                                    scrollClampMin - 150f,
                                                    scrollClampMax + 150f
                                                )
                                                change.consume()
                                            }
                                            isAutoScrollEnabled = false
                                            lastPreviewTime = System.currentTimeMillis()
                                        }

                                        // Solo cuenta como deslizar si el dedo supera el umbral de toque;
                                        // así un toque corto llega a la línea de letra y hace seek.
                                        val slopChange = awaitVerticalTouchSlopOrCancellation(down.id) { change, overSlop ->
                                            applyDrag(change, overSlop)
                                        }
                                        if (slopChange != null) {
                                            verticalDrag(slopChange.id) { change ->
                                                applyDrag(change, change.positionChange().y)
                                            }
                                        }

                                        if (isAutoScrollEnabled) return@awaitEachGesture

                                        val velocity = velocityTracker.calculateVelocity().y
                                        if (kotlin.math.abs(velocity) > 100f) {
                                            flingJob = launch {
                                                val animState = AnimationState(
                                                    initialValue = userManualOffset,
                                                    initialVelocity = velocity
                                                )
                                                animState.animateDecay(decayAnimSpec) {
                                                    if (!isAutoScrollEnabled && value in scrollClampMin..scrollClampMax) {
                                                        userManualOffset = value
                                                    } else if (!isAutoScrollEnabled) {
                                                        val target = value.coerceIn(scrollClampMin, scrollClampMax)
                                                        cancelAnimation()
                                                        launch {
                                                            Animatable(userManualOffset).animateTo(
                                                                targetValue = target,
                                                                animationSpec = androidx.compose.animation.core.spring(
                                                                    dampingRatio = androidx.compose.animation.core.Spring.DampingRatioLowBouncy,
                                                                    stiffness = androidx.compose.animation.core.Spring.StiffnessMedium
                                                                )
                                                            ) {
                                                                if (!isAutoScrollEnabled) userManualOffset = value
                                                            }
                                                        }
                                                    } else {
                                                        cancelAnimation()
                                                    }
                                                }
                                            }
                                        } else {
                                            if (userManualOffset < scrollClampMin || userManualOffset > scrollClampMax) {
                                                val target = userManualOffset.coerceIn(scrollClampMin, scrollClampMax)
                                                flingJob = launch {
                                                    androidx.compose.animation.core.Animatable(userManualOffset).animateTo(
                                                        targetValue = target,
                                                        animationSpec = tween(300, easing = FastOutSlowInEasing)
                                                    ) {
                                                        userManualOffset = value
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                    ) {
                        if (isLyricsProviderShown) {
                            // Con círculo de espera al inicio, el encabezado queda fijo: la primera letra
                            // ocupa el lugar del círculo, igual que si la letra hubiera empezado desde el inicio.
                            // Mientras dura el círculo el encabezado queda fijo encima de él; después
                            // se pega a la primera letra (igual que si no hubiera círculo).
                            val firstLineListIndex = mergedLyricsList.indexOfFirst { it is LyricsListItemV2.Line }.coerceAtLeast(0)
                            val headerItemPos = if (mergedLyricsList.firstOrNull() is LyricsListItemV2.Indicator &&
                                activeListIndex < firstLineListIndex
                            ) 0f else (positions[firstLineListIndex] ?: ((firstLineListIndex - activeListIndex) * lineHeightPx))
                            val targetProviderBase = anchorY + headerItemPos - with(density) { 32.dp.toPx() }
                            val animatedProviderBase by animateFloatAsState(
                                targetValue = targetProviderBase,
                                animationSpec = if (isInitialLayout || !isAutoScrollEnabled || isSeeking) snap()
                                else {
                                    tween(750, 0, FastOutSlowInEasing)
                                },
                                label = "lyricsProviderOffset"
                            )
                            Text(
                                text = "Lyrics from ${currentLyrics?.provider}",
                                fontSize = 12.sp,
                                color = adaptivePrimary.copy(alpha = 0.6f * contentAlpha),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .offset { IntOffset(0, (animatedProviderBase + userManualOffset).roundToInt()) }
                                    .padding(horizontal = 24.dp, vertical = 4.dp),
                                textAlign = TextAlign.Center
                            )
                        }

                        mergedLyricsList.forEachIndexed { listIndex, listItem ->
                            key(listItem) {
                                val distance = kotlin.math.abs(listIndex - activeListIndex)
                                val targetOffset = anchorY + (positions[listIndex] ?: ((listIndex - activeListIndex) * lineHeightPx))

                                val frozenOffset = remember { androidx.compose.runtime.mutableFloatStateOf(targetOffset) }
                                LaunchedEffect(isAutoScrollEnabled, targetOffset, isInitialLayout) {
                                    if (isAutoScrollEnabled || isInitialLayout) {
                                        frozenOffset.floatValue = targetOffset
                                    }
                                }

                                val animatedOffset by animateFloatAsState(
                                    targetValue = if (isAutoScrollEnabled) targetOffset else frozenOffset.floatValue,
                                    animationSpec = if (isInitialLayout || !isAutoScrollEnabled || isSeeking) snap()
                                    else {
                                        tween(
                                            750,
                                            // Solo las líneas de abajo se escalonan; las de arriba salen a la vez
                                            // que la activa para que no se les superponga.
                                            if (listIndex > activeListIndex) (distance * LYRICS_STAGGER_DELAY_PER_DISTANCE).coerceAtMost(LYRICS_STAGGER_DELAY_MAX_MS) else 0,
                                            FastOutSlowInEasing
                                        )
                                    },
                                    label = "lyricStaggeredOffset_$listIndex"
                                )

                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .graphicsLayer {
                                            alpha = contentAlpha
                                        }
                                        .layout { measurable, constraints ->
                                            val placeable = measurable.measure(constraints.copy(maxHeight = Constraints.Infinity))
                                            itemHeights[listIndex] = placeable.height
                                            layout(placeable.width, 0) {
                                                placeable.place(0, 0)
                                            }
                                        }
                                        .offset { IntOffset(0, (animatedOffset + userManualOffset).roundToInt()) }
                                ) {
                                    when (listItem) {
                                        is LyricsListItemV2.Line -> {
                                            val index = listItem.index
                                            val line = listItem.entry
                                            val isSelected = selectedIndices.contains(index)
                                            val effectivePlaybackPosition = currentPlaybackPosition + lyricsOffset

                                            val pairedMainLineIndex = if (line.isBackground) {
                                                (index - 1 downTo 0).firstOrNull { lines.getOrNull(it)?.isBackground == false } ?: -1
                                            } else -1
                                            val isInGapWithMain = if (line.isBackground && pairedMainLineIndex != -1) {
                                                val pairedMainLine = lines[pairedMainLineIndex]
                                                effectivePlaybackPosition >= pairedMainLine.time && effectivePlaybackPosition <= line.time
                                            } else false
                                            val bgVisibleNow = !line.isBackground || (
                                                activeLineIndices.contains(pairedMainLineIndex) ||
                                                activeLineIndices.contains(index) ||
                                                isInGapWithMain
                                            )
                                            // La línea secundaria se queda un momento antes de desaparecer.
                                            val bgVisible = rememberLingerVisible(bgVisibleNow, LYRICS_BG_LINGER_MS)

                                            MetroLyricsLine(
                                                entry = line,
                                                nextEntryTime = lines.getOrNull(index + 1)?.time,
                                                effectivePlaybackPosition = effectivePlaybackPosition,
                                                lyricsOffset = lyricsOffset,
                                                isSynced = true,
                                                isActive = activeLineIndices.contains(index),
                                                distanceFromCurrent = kotlin.math.abs(index - deferredCurrentLineIndex),
                                                lyricsTextPosition = LyricsPosition.LEFT,
                                                textColor = adaptivePrimary,
                                                showRomanized = showRomanized,
                                                isAutoScrollActive = isAutoScrollEnabled,
                                                isSelectionModeActive = isSelectionModeActive,
                                                isSelected = isSelected,
                                                expressiveAccent = adaptivePrimary,
                                                bgVisible = bgVisible,
                                                bgInstantCollapse = false,
                                                onClick = {
                                                    if (isSelectionModeActive) {
                                                        toggleSelection(index)
                                                    } else if (!isGuest) {
                                                        val seekTarget = (line.time - lyricsOffset).coerceAtLeast(0)
                                                        playerConnection.seekTo(seekTarget)
                                                        awaitingSeekTarget = seekTarget
                                                        awaitingSeekSince = System.currentTimeMillis()
                                                        scrollTargetIndex = index
                                                        isAutoScrollEnabled = true
                                                        lastPreviewTime = 0L
                                                    }
                                                },
                                                onLongClick = {
                                                    startSelection(index)
                                                }
                                            )
                                        }

                                        is LyricsListItemV2.Indicator -> {
                                            val indicatorVisible = isAutoScrollEnabled &&
                                                currentPlaybackPosition >= listItem.gapStartMs &&
                                                currentPlaybackPosition <= listItem.gapEndMs - 650L
                                            IntervalIndicator(
                                                gapStartMs = listItem.gapStartMs,
                                                gapEndMs = listItem.gapEndMs - 650L,
                                                currentPositionMs = currentPlaybackPosition,
                                                visible = indicatorVisible,
                                                color = adaptivePrimary,
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(horizontal = 24.dp)
                                                    .wrapContentWidth(Alignment.CenterHorizontally)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                    Box(
                        modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 16.dp)
                    ) {
                        AnimatedVisibility(
                            visible = !isAutoScrollEnabled && !isSelectionModeActive,
                            enter = slideInVertically(tween(300, easing = FastOutSlowInEasing)) { it } + fadeIn(tween(300)),
                            exit = slideOutVertically(tween(250, easing = FastOutSlowInEasing)) { it } + fadeOut(tween(250))
                        ) {
                            FilledTonalButton(onClick = {
                                // Cancel any in-progress fling before starting spring-back;
                                // without this, flingJob keeps writing to userManualOffset
                                // and fights the spring-back animation.
                                flingJob?.cancel()
                                flingJob = null
                                if (currentLineIndex != -1) {
                                    scrollTargetIndex = currentLineIndex
                                    deferredCurrentLineIndex = currentLineIndex
                                    lastMainMaxSeen = currentLineIndex
                                }
                                lastPreviewTime = 0L
                                isAutoScrollEnabled = true
                            }) {
                                Icon(
                                    painter = painterResource(id = R.drawable.sync),
                                    contentDescription = stringResource(R.string.auto_scroll),
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(text = stringResource(R.string.auto_scroll))
                            }
                        }
                    }

                    LyricsSelectionFloatingBox(
                        visible = isSelectionModeActive,
                        selectedCount = selectedIndices.size,
                        onCancel = exitSelection,
                        onShare = {
                            if (selectedIndices.isNotEmpty()) {
                                showShareSheet = true
                            }
                        },
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 24.dp)
                            .zIndex(10f)
                    )
                }
            }
        }

    if (showShareSheet && mediaMetadata != null) {
        val rawLyrics = currentLyrics?.lyrics
        val lines = remember(rawLyrics) {
            rawLyrics?.let { LyricsUtils.parseLyrics(it) } ?: emptyList()
        }
        val selectedLyricsText = selectedIndices.sorted()
            .mapNotNull { lines.getOrNull(it)?.text }
            .joinToString("\n")

        LyricsShareBottomSheet(
            mediaMetadata = mediaMetadata,
            lyrics = selectedLyricsText,
            onDismissRequest = {
                showShareSheet = false
                exitSelection()
            }
        )
    }
}

@Composable
private fun LyricsSelectionFloatingBox(
    visible: Boolean,
    selectedCount: Int,
    onCancel: () -> Unit,
    onShare: () -> Unit,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = visible,
        enter = slideInVertically(tween(350, easing = FastOutSlowInEasing)) { it } + fadeIn(tween(350)),
        exit = slideOutVertically(tween(250, easing = FastOutSlowInEasing)) { it } + fadeOut(tween(250)),
        modifier = modifier
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.95f),
            tonalElevation = 8.dp,
            shadowElevation = 10.dp,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
            modifier = Modifier.wrapContentSize()
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                TextButton(
                    onClick = onCancel,
                    shape = RoundedCornerShape(16.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.close),
                        contentDescription = "Cancel",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Cancel",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Box(
                    modifier = Modifier
                        .width(1.dp)
                        .height(24.dp)
                        .background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
                )

                Button(
                    onClick = onShare,
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.share),
                        contentDescription = "Share",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Share ($selectedCount)",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LyricsShareBottomSheet(
    mediaMetadata: MediaMetadata,
    lyrics: String,
    onDismissRequest: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var isGeneratingImage by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismissRequest,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
        tonalElevation = 6.dp,
        dragHandle = {
            BottomSheetDefaults.DragHandle()
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(bottom = 32.dp, start = 20.dp, end = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = stringResource(R.string.share_lyrics),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            // Blur Card Preview (Dynamic Height: expands as more lyrics lines are selected)
            LyricsImageCard(
                lyricText = lyrics,
                mediaMetadata = mediaMetadata,
                backgroundStyle = LyricsBackgroundStyle.BLUR,
                backgroundColor = Color.Transparent,
                textAlign = TextAlign.Start,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(24.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Save button
                FilledTonalButton(
                    onClick = {
                        if (isGeneratingImage) return@FilledTonalButton
                        isGeneratingImage = true
                        coroutineScope.launch(Dispatchers.IO) {
                            try {
                                val image = ComposeToImage.createLyricsImage(
                                    context = context,
                                    mediaMetadata = mediaMetadata,
                                    lyrics = lyrics,
                                    backgroundStyle = LyricsBackgroundStyle.BLUR,
                                    backgroundColor = android.graphics.Color.TRANSPARENT,
                                    textColor = android.graphics.Color.WHITE,
                                    secondaryTextColor = android.graphics.Color.WHITE,
                                    lyricsAlignment = Layout.Alignment.ALIGN_NORMAL
                                )
                                val timestamp = System.currentTimeMillis()
                                val filename = "lyrics_$timestamp"
                                ComposeToImage.saveBitmapAsFile(context, image, filename)
                                withContext(Dispatchers.Main) {
                                    Toast.makeText(
                                        context,
                                        "Image saved to Pictures/vivimusic",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            } catch (e: Exception) {
                                withContext(Dispatchers.Main) {
                                    Toast.makeText(
                                        context,
                                        context.getString(R.string.failed_to_create_image, e.message),
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            } finally {
                                isGeneratingImage = false
                            }
                        }
                    },
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp),
                    enabled = !isGeneratingImage
                ) {
                    if (isGeneratingImage) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            strokeWidth = 2.5.dp
                        )
                    } else {
                        Icon(
                            painter = painterResource(id = R.drawable.download),
                            contentDescription = stringResource(R.string.save),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = stringResource(R.string.save),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Share button
                Button(
                    onClick = {
                        if (isGeneratingImage) return@Button
                        isGeneratingImage = true
                        coroutineScope.launch(Dispatchers.IO) {
                            try {
                                val image = ComposeToImage.createLyricsImage(
                                    context = context,
                                    mediaMetadata = mediaMetadata,
                                    lyrics = lyrics,
                                    backgroundStyle = LyricsBackgroundStyle.BLUR,
                                    backgroundColor = android.graphics.Color.TRANSPARENT,
                                    textColor = android.graphics.Color.WHITE,
                                    secondaryTextColor = android.graphics.Color.WHITE,
                                    lyricsAlignment = Layout.Alignment.ALIGN_NORMAL
                                )
                                val timestamp = System.currentTimeMillis()
                                val filename = "lyrics_$timestamp"
                                val uri = ComposeToImage.saveBitmapAsFile(context, image, filename)
                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "image/png"
                                    putExtra(Intent.EXTRA_STREAM, uri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(
                                    Intent.createChooser(
                                        shareIntent,
                                        context.getString(R.string.share_lyrics)
                                    )
                                )
                            } catch (e: Exception) {
                                withContext(Dispatchers.Main) {
                                    Toast.makeText(
                                        context,
                                        context.getString(R.string.failed_to_create_image, e.message),
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            } finally {
                                isGeneratingImage = false
                            }
                        }
                    },
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp),
                    enabled = !isGeneratingImage
                ) {
                    if (isGeneratingImage) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            color = MaterialTheme.colorScheme.onPrimary,
                            strokeWidth = 2.5.dp
                        )
                    } else {
                        Icon(
                            painter = painterResource(id = R.drawable.share),
                            contentDescription = stringResource(R.string.share),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = stringResource(R.string.share),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

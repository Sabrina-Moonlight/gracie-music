/**
 * vivimusic Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.music.vivi.lyrics

import com.music.vivi.constants.PreferredLyricsProvider

/**
 * Central registry for all lyrics providers.
 * Maps provider names (used for persistence) to provider objects,
 * and handles serialization/deserialization of the custom priority order.
 */
object LyricsProviderRegistry {
    private val providerMap = mapOf(
        "Paxsenix"        to PaxSenixLyricsProvider,
        "BetterLyrics"    to BetterLyricsProvider,
        "LrcLib"          to LrcLibLyricsProvider,
        "Kugou"           to KuGouLyricsProvider,
        "Unison"          to UnisonLyricsProvider,
        "BiniLyrics"      to BiniLyricsProvider,
        "LrcRed"          to LrcRedLyricsProvider,
        "YouTubeSubtitle" to YouTubeSubtitleLyricsProvider,
        "YouTubeMusic"    to YouTubeLyricsProvider,
    )

    val providerNames = providerMap.keys.toList()

    fun getProviderByName(name: String): LyricsProvider? = providerMap[name]

    fun deserializeProviderOrder(orderString: String): List<String> {
        if (orderString.isBlank()) return getDefaultProviderOrder()
        return orderString.split(",").map { it.trim() }.filter { it in providerNames }
    }

    fun serializeProviderOrder(providers: List<String>): String =
        providers.filter { it in providerNames }.joinToString(",")

    fun getDefaultProviderOrder(): List<String> = listOf(
        "Paxsenix",
        "BetterLyrics",
        "LrcLib",
        "Kugou",
        "Unison",
        "BiniLyrics",
        "LrcRed",
        "YouTubeSubtitle",
        "YouTubeMusic",
    )

    fun getOrderedProviders(orderString: String): List<LyricsProvider> =
        deserializeProviderOrder(orderString).mapNotNull { getProviderByName(it) }

    /** Maps a [PreferredLyricsProvider] enum value to its registry name, used for migration. */
    fun getProviderNameForEnum(enum: PreferredLyricsProvider): String = when (enum) {
        PreferredLyricsProvider.LRCLIB           -> "LrcLib"
        PreferredLyricsProvider.KUGOU            -> "Kugou"
        PreferredLyricsProvider.BETTER_LYRICS    -> "BetterLyrics"
        PreferredLyricsProvider.PAXSENIX         -> "Paxsenix"
        PreferredLyricsProvider.UNISON           -> "Unison"
        PreferredLyricsProvider.SPOTIFY          -> "LrcLib"
        PreferredLyricsProvider.BINI_LYRICS      -> "BiniLyrics"
        PreferredLyricsProvider.LRC_RED          -> "LrcRed"
        PreferredLyricsProvider.YOUTUBE_SUBTITLE -> "YouTubeSubtitle"
        PreferredLyricsProvider.YOUTUBE_MUSIC    -> "YouTubeMusic"
    }

    /** Returns the human-readable display name for a registry provider key. */
    fun getDisplayName(name: String): String = when (name) {
        "Paxsenix"        -> "PaxSenix"
        "BetterLyrics"    -> "Better Lyrics"
        "LrcLib"          -> "LrcLib"
        "Kugou"           -> "KuGou"
        "Unison"          -> "Unison"
        "BiniLyrics"      -> "Bini Lyrics"
        "LrcRed"          -> "lrc.red"
        "YouTubeSubtitle" -> "YouTube Subtitle"
        "YouTubeMusic"    -> "YouTube Music"
        else              -> name
    }
}

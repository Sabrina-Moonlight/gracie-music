/**
 * vivimusic Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.music.vivi.ui.screens

import android.app.Activity
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.TopAppBarScrollBehavior
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.composable
import androidx.navigation.compose.dialog
import androidx.navigation.navArgument
import com.music.vivi.constants.DarkModeKey
import com.music.vivi.constants.PureBlackKey
import com.music.vivi.ui.screens.artist.ArtistAlbumsScreen
import com.music.vivi.ui.screens.artist.ArtistItemsScreen
import com.music.vivi.ui.screens.artist.ArtistScreen
import com.music.vivi.ui.screens.artist.ArtistSongsScreen
import com.music.vivi.ui.screens.equalizer.EqScreen
import com.music.vivi.ui.screens.library.LibraryScreen
import com.music.vivi.ui.screens.library.LocalMusicScreen
import com.music.vivi.ui.screens.playlist.AutoPlaylistScreen
import com.music.vivi.ui.screens.playlist.CachePlaylistScreen
import com.music.vivi.ui.screens.playlist.LocalPlaylistScreen
import com.music.vivi.ui.screens.playlist.OnlinePlaylistScreen
import com.music.vivi.ui.screens.playlist.TopPlaylistScreen
import com.music.vivi.ui.screens.search.OnlineSearchResult
import com.music.vivi.ui.screens.search.SearchScreen
import com.music.vivi.ui.screens.settings.AppearanceSettings
import com.music.vivi.ui.screens.settings.FontSelectionScreen
import com.music.vivi.ui.screens.settings.BackupAndRestore
import com.music.vivi.ui.screens.settings.AutoBackupSettings
import androidx.hilt.navigation.compose.hiltViewModel
import com.music.vivi.ui.screens.settings.ContentSettings
import com.music.vivi.ui.screens.settings.DarkMode
import com.music.vivi.ui.screens.settings.PlayerSettings
import com.music.vivi.ui.screens.settings.JioSettings
import com.music.vivi.ui.screens.settings.SponsorBlockSettings
import com.music.vivi.ui.screens.settings.PrivacySettings
import com.music.vivi.ui.screens.settings.RomanizationSettings
import com.music.vivi.ui.screens.settings.SettingsScreen
import com.music.vivi.ui.screens.settings.AccountSettingsScreen
import com.music.vivi.ui.screens.settings.StorageSettings
import com.music.vivi.ui.screens.settings.ThemeSettings
import com.music.vivi.ui.screens.wrapped.WrappedScreen
import com.music.vivi.vivimusic.updater.UpdateScreen
import com.music.vivi.utils.rememberEnumPreference
import com.music.vivi.utils.rememberPreference
import com.music.vivi.ui.screens.equalizer.axion.AxionEqScreen
import com.music.vivi.viewmodels.HomeViewModel

@OptIn(ExperimentalMaterial3Api::class)
fun NavGraphBuilder.navigationBuilder(
    navController: NavHostController,
    scrollBehavior: TopAppBarScrollBehavior,
    activity: Activity,
    snackbarHostState: SnackbarHostState,
    homeViewModel: HomeViewModel
) {
    composable(Screens.Home.route) {
        HomeScreen(
            navController = navController,
            snackbarHostState = snackbarHostState,
            viewModel = homeViewModel
        )
    }

    composable(Screens.Search.route) {
        val pureBlackEnabled by rememberPreference(PureBlackKey, defaultValue = false)
        val darkTheme by rememberEnumPreference(DarkModeKey, defaultValue = DarkMode.AUTO)
        val isSystemInDarkTheme = isSystemInDarkTheme()
        val useDarkTheme = remember(darkTheme, isSystemInDarkTheme) {
            if (darkTheme == DarkMode.AUTO) isSystemInDarkTheme else darkTheme == DarkMode.ON
        }
        val pureBlack = remember(pureBlackEnabled, useDarkTheme) {
            pureBlackEnabled && useDarkTheme
        }
        SearchScreen(
            navController = navController,
            pureBlack = pureBlack
        )
    }

    composable(Screens.Library.route) {
        LibraryScreen(navController)
    }



    composable(Screens.Local.route) {
        LocalMusicScreen(navController)
    }

    composable("history") {
        HistoryScreen(navController)
    }

    composable("stats") {
        StatsScreen(navController)
    }

    composable("mood_and_genres") {
        MoodAndGenresScreen(navController, scrollBehavior)
    }

    composable("account") {
        AccountScreen(navController, scrollBehavior)
    }

    composable("new_release") {
        NewReleaseScreen(navController, scrollBehavior)
    }

    composable("charts_screen") {
        ChartsScreen(navController)
    }

    composable(
        route = "browse/{browseId}",
        arguments = listOf(
            navArgument("browseId") {
                type = NavType.StringType
            }
        )
    ) {
        BrowseScreen(
            navController,
            scrollBehavior,
            it.arguments?.getString("browseId")
        )
    }

    composable(
        route = "search/{query}",
        arguments = listOf(
            navArgument("query") {
                type = NavType.StringType
            },
        ),
        enterTransition = {
            fadeIn(tween(250))
        },
        exitTransition = {
            if (targetState.destination.route?.startsWith("search/") == true) {
                fadeOut(tween(200))
            } else {
                fadeOut(tween(200)) + slideOutHorizontally { -it / 2 }
            }
        },
        popEnterTransition = {
            if (initialState.destination.route?.startsWith("search/") == true) {
                fadeIn(tween(250))
            } else {
                fadeIn(tween(250)) + slideInHorizontally { -it / 2 }
            }
        },
        popExitTransition = {
            fadeOut(tween(200))
        },
    ) {
        OnlineSearchResult(navController)
    }

    composable(
        route = "album/{albumId}",
        arguments = listOf(
            navArgument("albumId") {
                type = NavType.StringType
            },
        ),
    ) {
        AlbumScreen(navController, scrollBehavior)
    }

    composable(
        route = "artist/{artistId}",
        arguments = listOf(
            navArgument("artistId") {
                type = NavType.StringType
            },
        ),
    ) {
        ArtistScreen(navController, scrollBehavior)
    }

    composable(
        route = "artist/{artistId}/songs",
        arguments = listOf(
            navArgument("artistId") {
                type = NavType.StringType
            },
        ),
    ) {
        ArtistSongsScreen(navController, scrollBehavior)
    }

    composable(
        route = "artist/{artistId}/albums",
        arguments = listOf(
            navArgument("artistId") {
                type = NavType.StringType
            }
        )
    ) {
        ArtistAlbumsScreen(navController, scrollBehavior)
    }

    composable(
        route = "artist/{artistId}/items?browseId={browseId}?params={params}",
        arguments = listOf(
            navArgument("artistId") {
                type = NavType.StringType
            },
            navArgument("browseId") {
                type = NavType.StringType
                nullable = true
            },
            navArgument("params") {
                type = NavType.StringType
                nullable = true
            },
        ),
    ) {
        ArtistItemsScreen(navController, scrollBehavior)
    }

    composable(
        route = "online_playlist/{playlistId}",
        arguments = listOf(
            navArgument("playlistId") {
                type = NavType.StringType
            },
        ),
    ) {
        OnlinePlaylistScreen(navController, scrollBehavior)
    }

    composable(
        route = "local_playlist/{playlistId}",
        arguments = listOf(
            navArgument("playlistId") {
                type = NavType.StringType
            },
        ),
    ) {
        LocalPlaylistScreen(navController, scrollBehavior)
    }

    composable(
        route = "auto_playlist/{playlist}",
        arguments = listOf(
            navArgument("playlist") {
                type = NavType.StringType
            },
        ),
    ) {
        AutoPlaylistScreen(navController, scrollBehavior)
    }

    composable(
        route = "cache_playlist/{playlist}",
        arguments = listOf(
            navArgument("playlist") {
                type = NavType.StringType
            },
        ),
    ) {
        CachePlaylistScreen(navController, scrollBehavior)
    }

    composable(
        route = "top_playlist/{top}",
        arguments = listOf(
            navArgument("top") {
                type = NavType.StringType
            },
        ),
    ) {
        TopPlaylistScreen(navController, scrollBehavior)
    }

    composable(
        route = "youtube_browse/{browseId}?params={params}",
        arguments = listOf(
            navArgument("browseId") {
                type = NavType.StringType
                nullable = true
            },
            navArgument("params") {
                type = NavType.StringType
                nullable = true
            },
        ),
    ) {
        YouTubeBrowseScreen(navController)
    }

    composable("settings") {
        SettingsScreen(navController, scrollBehavior)
    }



    composable("settings/account") {
        AccountSettingsScreen(navController, scrollBehavior, homeViewModel)
    }

    composable("settings/appearance") {
        AppearanceSettings(navController, scrollBehavior, activity, snackbarHostState)
    }

    composable("settings/appearance/theme") {
        ThemeSettings(navController)
    }


    composable("settings/appearance/font") {
        FontSelectionScreen(navController, scrollBehavior)
    }

    composable("settings/content") {
        ContentSettings(navController, scrollBehavior)
    }

    composable("settings/content/romanization") {
        RomanizationSettings(navController, scrollBehavior)
    }

    
    composable("settings/player") {
        PlayerSettings(navController, scrollBehavior)
    }

    composable("settings/player/jio") {
        JioSettings(navController, scrollBehavior)
    }

    composable("settings/player/sponsorblock") {
        SponsorBlockSettings(navController, scrollBehavior)
    }

    composable("settings/storage") {
        StorageSettings(navController, scrollBehavior)
    }

    composable("settings/equalizer") {
        AxionEqScreen(onBackClick = { navController.navigateUp() })
    }

    composable("settings/privacy") {
        PrivacySettings(navController, scrollBehavior)
    }

    composable("settings/backup_restore") {
        BackupAndRestore(navController, scrollBehavior)
    }

    composable("settings/backup_restore/autobackup") {
        AutoBackupSettings(navController, scrollBehavior)
    }











    composable("update") {
        UpdateScreen(navController)
    }

    composable("login") {
        LoginScreen(navController)
    }

    composable("wrapped") {
        WrappedScreen(navController)
    }

    dialog("equalizer") {
        EqScreen(navController = navController)
    }


}
